import { TourPackage } from '../types';

export const INITIAL_PACKAGES: TourPackage[] = [
  {
    id: 'pkg-1',
    title: '3 Days – Discover Sri Lanka',
    subtitle: 'A compact cultural escape through the historic hill kingdom and royal botanical wonders.',
    duration: '3 Days / 2 Nights',
    days: 3,
    basePriceUSD: 390,
    category: 'Classic',
    featured: true,
    image: 'https://images.unsplash.com/photo-1588598198321-9735fd52455f?auto=format&fit=crop&w=1200&q=80',
    highlights: ['Temple of the Sacred Tooth Relic', 'Royal Botanical Gardens Peradeniya', 'Pinnawala Elephant Sanctuary', 'Traditional Kandyan Cultural Dance Show'],
    placesVisited: ['Colombo / Airport', 'Pinnawala', 'Kandy', 'Peradeniya'],
    inclusions: ['Dedicated private chauffeur-guide', 'Luxury air-conditioned sedan', '2 nights 4-star boutique hotel accommodation', 'Daily breakfast', 'Fuel, highway tolls & parking fees', 'Government taxes & 24/7 travel concierge'],
    exclusions: ['International flight tickets', 'Monument entry tickets', 'Lunch & dinners (unless specified)', 'Personal expenses & gratuities'],
    itinerary: [
      { day: 1, title: 'Arrival & Journey to the Sacred City of Kandy', description: 'Warm VIP welcome at Bandaranaike International Airport (CMB) by your private chauffeur-guide. Scenic drive through tropical fruit valleys with a scenic stop at Pinnawala Elephant Care Sanctuary. Check into your Kandy luxury boutique hotel. Evening visit to the revered Temple of the Sacred Tooth Relic followed by an authentic Kandyan cultural drumming & dance performance.' },
      { day: 2, title: 'Peradeniya Royal Flora & Kandy Lake Serenity', description: 'Morning guided stroll through the world-famous Peradeniya Botanical Gardens with over 4,000 plant species and towering royal palms. Afternoon craft tour visiting authentic gem lapidaries and batik ateliers. Sunset stroll around the tranquil Kandy Lake.' },
      { day: 3, title: 'Spice Haven & Departure / Colombo Drop-off', description: 'After breakfast, explore an aromatic organic spice garden in Mawanella learning ancient Ayurvedic herbal remedies. Return comfortably to Colombo or transfer smoothly to CMB Airport for your onward international flight.' }
    ]
  },
  {
    id: 'pkg-2',
    title: '5 Days – Cultural & Nature Escape',
    subtitle: 'The ultimate blend of ancient UNESCO rock citadels, sacred cave shrines, and misty emerald tea hills.',
    duration: '5 Days / 4 Nights',
    days: 5,
    basePriceUSD: 680,
    category: 'Highlights',
    featured: true,
    image: 'https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?auto=format&fit=crop&w=1200&q=80',
    highlights: ['Sigiriya Lion Rock Fortress', 'Dambulla Golden Rock Cave Temples', 'Kandy Cultural Triangle Heart', 'Misty Nuwara Eliya Tea Country', 'Ramboda Waterfall Viewpoint'],
    placesVisited: ['Sigiriya', 'Dambulla', 'Kandy', 'Nuwara Eliya', 'Colombo'],
    inclusions: ['Private English-speaking chauffeur-guide', 'Modern AC SUV / Luxury Van', '4 nights handpicked 4-5 star luxury accommodation', 'Daily buffet breakfasts', 'Tea factory masterclass & tasting', 'All road taxes & 24/7 care'],
    exclusions: ['International flights', 'Site entrance fees (available on request)', 'Alcoholic drinks & personal expenses'],
    itinerary: [
      { day: 1, title: 'Airport to the Ancient Citadel of Sigiriya', description: 'Arrive at Colombo and transfer directly through coconut groves to the Cultural Triangle. Evening relaxation by your tropical resort pool overlooking the Sigiriya silhouette.' },
      { day: 2, title: 'Conquer Sigiriya Rock & Dambulla Golden Temple', description: 'Early morning sunrise ascent of the UNESCO 5th-century Sigiriya Rock Fortress. Marvel at the heavenly frescoes and mirror wall. Afternoon visit to Dambulla Golden Rock Cave Temple, home to 150+ gilded Buddha statues.' },
      { day: 3, title: 'En Route to Kandy with Spice Infusions', description: 'Drive south to Kandy via an organic spice garden. In the afternoon, tour the holy Temple of the Tooth Relic and savor a scenic twilight boat ride across Kandy Lake.' },
      { day: 4, title: 'Scenic Climb to Nuwara Eliya "Little England"', description: 'Ascend past roaring waterfalls and carpeted tea plantations into the mist-crowned Central Highlands. Tour a historic working tea estate, witness orthodox tea plucking, and savor a fine Ceylon Orange Pekoe tasting.' },
      { day: 5, title: 'Gregory Lake Stroll & Return Transfer', description: 'Morning horse ride or brisk lakeside stroll at Gregory Lake. Descend gracefully through the lush mountain passes to Colombo city or airport.' }
    ]
  },
  {
    id: 'pkg-3',
    title: '7 Days – Island Highlights',
    subtitle: 'Our signature Sri Lankan journey: ancient wonder, alpine tea trains, big game safari, and colonial coastal elegance.',
    duration: '7 Days / 6 Nights',
    days: 7,
    basePriceUSD: 980,
    category: 'Most Popular',
    featured: true,
    image: 'https://images.unsplash.com/photo-1546708973-b339540b5162?auto=format&fit=crop&w=1200&q=80',
    highlights: ['Sigiriya Lion Rock', 'Kandy Temple of the Tooth', 'Scenic Blue Train Journey to Ella', 'Nine Arch Bridge & Little Adam\'s Peak', 'Yala Leopard Safari in 4x4 Jeep', 'UNESCO Galle Dutch Fort Walk'],
    placesVisited: ['Sigiriya', 'Kandy', 'Nuwara Eliya', 'Ella', 'Yala National Park', 'Galle Fort', 'Colombo'],
    inclusions: ['Private chauffeur-guide throughout', 'Private air-conditioned luxury vehicle', '6 nights luxury boutique hotels & safari lodges', 'Daily breakfasts & dinner at safari camp', 'Reserved 1st/2nd class scenic train tickets', 'Private Yala 4x4 safari jeep with ranger'],
    exclusions: ['International airfares', 'Optional activities', 'Personal tipping'],
    itinerary: [
      { day: 1, title: 'Arrival & Transfer to Cultural Sigiriya', description: 'VIP Airport meet & greet. Travel in private comfort to your tranquil Sigiriya eco-luxury retreat.' },
      { day: 2, title: 'Sigiriya Rock & Minneriya Wild Elephant Gathering', description: 'Ascend the royal citadel of Sigiriya at dawn. In the late afternoon, embark on an open-top jeep safari in Minneriya National Park to witness hundreds of wild elephants.' },
      { day: 3, title: 'Dambulla Caves & Kandy Heritage', description: 'Journey to Kandy visiting Dambulla Cave Temple. Evening private blessing ceremony at the Temple of the Tooth.' },
      { day: 4, title: 'Iconic Ceylon Blue Train to Ella', description: 'Board the world\'s most scenic highland train ride winding through cloud forests and emerald tea carpets to picturesque Ella.' },
      { day: 5, title: 'Nine Arch Bridge & Descent to Yala Safari Bush', description: 'Morning visit to the magnificent colonial Nine Arch viaduct as the train crosses. Afternoon scenic descent to the wild southern plains of Yala. Settle into your safari eco-lodge.' },
      { day: 6, title: 'Dawn Leopard Safari & Coastal Galle Fort', description: 'Dawn private 4x4 safari in Yala National Park searching for Sri Lankan leopards, sloth bears, and crocodiles. Afternoon drive along the turquoise southern coast to the 17th-century Galle Fort. Sunset walk atop the ramparts.' },
      { day: 7, title: 'Galle Living Heritage & Coastal Highway to Airport', description: 'Explore chic boutiques, artisan cafes, and colonial bastions of Galle before a smooth cruise along the Southern Expressway to Colombo or CMB Airport.' }
    ]
  },
  {
    id: 'pkg-4',
    title: '10 Days – Complete Sri Lanka Experience',
    subtitle: 'An immersive grand expedition discovering sacred ruins, high peaks, wild wildlife, and sun-kissed golden shores.',
    duration: '10 Days / 9 Nights',
    days: 10,
    basePriceUSD: 1450,
    category: 'Grand Journey',
    featured: true,
    image: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=1200&q=80',
    highlights: ['Anuradhapura 2,500-year sacred stupas', 'Sigiriya & Polonnaruwa Ancient Kingdom', 'Kandy & Temple of the Tooth', 'Scenic Highland Train Ride', 'Ella Peak & Rawana Falls', 'Yala National Park Predator Safari', 'Mirissa Whale Watching Cruise', 'Galle UNESCO Dutch Fort'],
    placesVisited: ['Anuradhapura', 'Sigiriya', 'Polonnaruwa', 'Kandy', 'Ella', 'Yala', 'Mirissa', 'Galle', 'Colombo'],
    inclusions: ['Dedicated private chauffeur-guide', 'Premium luxury van/SUV', '9 nights luxury resort & boutique hotel accommodation', 'Daily breakfast & select gourmet dinners', 'Scenic train tickets reserved', 'Private Yala 4x4 jeep safari', 'Whale watching boat reservation', 'All highway tolls & porterage'],
    exclusions: ['International flights', 'National park and cultural site entrance fees (can be pre-packaged)', 'Personal expenses'],
    itinerary: [
      { day: 1, title: 'Arrival & Transfer to Sacred Anuradhapura', description: 'Warm airport welcome. Drive north to Sri Lanka\'s first ancient capital Anuradhapura.' },
      { day: 2, title: 'Anuradhapura Sacred Stupas & Jaya Sri Maha Bodhi', description: 'Cycle or tour the ancient kingdom: the 2,300-year-old sacred Bodhi Tree, Ruwanwelisaya stupa, and monastic gardens.' },
      { day: 3, title: 'Polonnaruwa Royal Palaces & Sigiriya', description: 'Explore medieval Polonnaruwa with its magnificent Gal Vihara rock-cut Buddha statues. Transfer to Sigiriya.' },
      { day: 4, title: 'Sigiriya Rock Fortress & Dambulla Caves', description: 'Morning climb of the 8th Wonder of the World. Afternoon discovery of Dambulla\'s rock cave sanctuaries.' },
      { day: 5, title: 'Kandy Royal Kingdom & Cultural Immersion', description: 'Drive to Kandy. Tour the Temple of the Tooth, Lake, and enjoy an evening traditional music and fire-dancing performance.' },
      { day: 6, title: 'Scenic Hill Country Train Journey to Ella', description: 'Spectacular train ride through pine forests, misty valleys, and tea estates to charming Ella.' },
      { day: 7, title: 'Ella Peak & Transfer to Yala Safari Territory', description: 'Hike Little Adam\'s Peak, capture the Nine Arch Bridge, then descend to the wildlife wilderness of Yala.' },
      { day: 8, title: 'Leopard & Sloth Bear Safari to Mirissa Beach', description: 'Exciting early morning safari in Yala Block 1. Transfer to the golden palm-lined beaches of Mirissa.' },
      { day: 9, title: 'Whale Watching & Galle Fort Sunset', description: 'Morning expedition into the Indian Ocean to observe majestic Blue Whales and playful spinner dolphins. Afternoon drive to Galle Fort for sunset dinner.' },
      { day: 10, title: 'Colombo City Tour & Airport Departure', description: 'Panoramic tour of vibrant Colombo: Independence Square, Gangaramaya Temple, and luxury shopping before your airport farewell.' }
    ]
  },
  {
    id: 'pkg-5',
    title: '12 Days – Ultimate Sri Lankan Adventure',
    subtitle: 'The comprehensive island odyssey: North-Central ruins, hill country splendor, dual safaris, and pristine coastal retreats.',
    duration: '12 Days / 11 Nights',
    days: 12,
    basePriceUSD: 1890,
    category: 'Signature Luxury',
    featured: true,
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80',
    highlights: ['Wilpattu & Yala Dual Safaris', 'Ancient Triangle: Anuradhapura & Sigiriya', 'Nuwara Eliya High Tea & Colonial Mansions', 'Scenic Ella Mountain Hikes & Ravana Falls', 'Hiriketiya Horseshoe Bay & Mirissa Coast', 'Private Galle Fort Walking Tour with Historian', 'Bentota River Lagoon Mangrove Cruise'],
    placesVisited: ['Wilpattu', 'Anuradhapura', 'Sigiriya', 'Kandy', 'Nuwara Eliya', 'Ella', 'Yala', 'Hiriketiya', 'Mirissa', 'Galle', 'Bentota', 'Colombo'],
    inclusions: ['Private luxury chauffeur-guide for 12 days', 'Unlimited Wi-Fi in private luxury vehicle', '11 nights 5-star boutique & heritage accommodations', 'Daily gourmet breakfast & luxury safari dinners', 'All private 4x4 safaris with naturalist', 'Madu River safari boat excursion', 'Comprehensive travel insurance cover within Sri Lanka'],
    exclusions: ['International flights', 'Gratuities for driver and safari rangers', 'Discretionary personal expenses'],
    itinerary: [
      { day: 1, title: 'Colombo VIP Arrival & Wilpattu Gateway', description: 'Bespoke airport arrival greeting. Transfer to luxury tented safari camp near Wilpattu National Park.' },
      { day: 2, title: 'Wilpattu Natural Lakes & Anuradhapura Ancient Citadel', description: 'Morning safari around the natural \'Willus\' lakes. Afternoon exploration of ancient Anuradhapura monuments.' },
      { day: 3, title: 'Sigiriya Rock & Hiriwadunna Village Immersion', description: 'Ascend Sigiriya in crisp morning light. Afternoon catamaran ride and traditional village lunch in Hiriwadunna.' },
      { day: 4, title: 'Dambulla Caves & Kandy Royal Botanical Elegance', description: 'Marvel at Dambulla Cave shrines and stroll the legendary Peradeniya orchid collections.' },
      { day: 5, title: 'Sacred Temple of the Tooth & High Tea in Nuwara Eliya', description: 'Private temple tour then ascend into the cool misty mountains. Experience high tea at The Grand Hotel Nuwara Eliya.' },
      { day: 6, title: 'Horton Plains World’s End & Train to Ella', description: 'Hike to the sheer 880m drop at World\'s End in Horton Plains. Board afternoon scenic train to Ella.' },
      { day: 7, title: 'Ella Highlights & Ravana Waterfall Cascade', description: 'Leisurely morning taking in Nine Arch Bridge. Drive south past Ravana Falls into the Yala wilderness.' },
      { day: 8, title: 'Yala Dawn & Twilight Big-Cat Safaris', description: 'Dual game drives maximizing chances of encountering the Sri Lankan leopard and Asian elephant herds.' },
      { day: 9, title: 'Transfer to Hiriketiya Beach & Coconut Tree Hill', description: 'Arrive at the Southern Coast. Relax on the turquoise crescent of Hiriketiya and catch sunset at Mirissa\'s Coconut Tree Hill.' },
      { day: 10, title: 'Whale Watching Ocean Cruise & Galle Dutch Fort', description: 'Sail into deep waters for blue whale encounters. Afternoon walking tour through Galle Fort with a local heritage guide.' },
      { day: 11, title: 'Bentota Mangrove River Cruise & Turtle Conservation', description: 'Madu River mangrove boat safari through cinnamon islands and visit a sea turtle conservation hatchery in Kosgoda.' },
      { day: 12, title: 'Colombo Elegance & Homeward Departure', description: 'Scenic drive to Colombo. Afternoon artisan tea shopping at Barefoot and Spa Ceylon before your comfortable airport transfer.' }
    ]
  }
];
