import React, { useState } from 'react';
import {
  Search,
  SlidersHorizontal,
  RotateCcw,
  LayoutGrid,
  List,
  Map,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { FilterState } from '../../types';
import { useRealEstate } from '../../context/RealEstateContext';

interface PropertyFilterBarProps {
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  onResetFilters: () => void;
  totalResults: number;
  viewMode: 'grid' | 'list' | 'map';
  onViewModeChange: (mode: 'grid' | 'list' | 'map') => void;
}

const PROPERTY_TYPES: { label: string; value: string }[] = [
  { label: 'All Property Types', value: 'all' },
  { label: 'Luxury Villas', value: 'villa' },
  { label: 'Penthouses', value: 'penthouse' },
  { label: 'Modern Apartments', value: 'apartment' },
  { label: 'Townhouses & Estates', value: 'house' },
  { label: 'Commercial & Flagships', value: 'commercial' },
  { label: 'Development Land', value: 'land' }
];

const AMENITIES_LIST = [
  'Infinity Swimming Pool',
  'Waterfront / Private Beach',
  'Private Spa & Sauna',
  'Wine Cellar',
  'Private Cinema',
  '24-Hour Concierge',
  'Yacht Mooring Berth',
  'Championship Tennis Court',
  'Private Gymnasium',
  'Smart Home Automation'
];

export const PropertyFilterBar: React.FC<PropertyFilterBarProps> = ({
  filters,
  onFilterChange,
  onResetFilters,
  totalResults,
  viewMode,
  onViewModeChange
}) => {
  const { locations } = useRealEstate();
  const [showAdvanced, setShowAdvanced] = useState(false);

  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFilterChange({ ...filters, searchQuery: e.target.value });
  };

  const handlePurposeChange = (purpose: 'all' | 'sale' | 'rent') => {
    onFilterChange({ ...filters, purpose });
  };

  const handleTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFilterChange({ ...filters, type: e.target.value });
  };

  const handleCityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFilterChange({ ...filters, city: e.target.value });
  };

  const handleMinPriceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFilterChange({ ...filters, minPrice: Number(e.target.value) });
  };

  const handleMaxPriceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFilterChange({ ...filters, maxPrice: Number(e.target.value) });
  };

  const handleBedroomsChange = (bedrooms: string) => {
    onFilterChange({ ...filters, bedrooms });
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFilterChange({ ...filters, sortBy: e.target.value as FilterState['sortBy'] });
  };

  const handleAmenityToggle = (amenity: string) => {
    const nextAmenities = filters.amenities.includes(amenity)
      ? filters.amenities.filter(a => a !== amenity)
      : [...filters.amenities, amenity];
    onFilterChange({ ...filters, amenities: nextAmenities });
  };

  return (
    <div className="bg-white border border-cool-200/80 rounded-sm shadow-sm p-4 mb-8">
      {/* Top row: Purpose tabs & Sort & View mode */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-cool-100">
        {/* Purpose switcher tabs */}
        <div className="flex items-center space-x-1 bg-cool-100/80 p-0.5 rounded-sm w-fit">
          <button
            onClick={() => handlePurposeChange('all')}
            className={`px-3 py-1.5 text-[11px] font-medium uppercase tracking-wider rounded-sm transition-all ${
              filters.purpose === 'all'
                ? 'bg-navy text-white font-semibold shadow-sm'
                : 'text-cool-600 hover:text-navy'
            }`}
          >
            All Properties
          </button>
          <button
            onClick={() => handlePurposeChange('sale')}
            className={`px-3 py-1.5 text-[11px] font-medium uppercase tracking-wider rounded-sm transition-all ${
              filters.purpose === 'sale'
                ? 'bg-navy text-white font-semibold shadow-sm'
                : 'text-cool-600 hover:text-navy'
            }`}
          >
            For Sale
          </button>
          <button
            onClick={() => handlePurposeChange('rent')}
            className={`px-3 py-1.5 text-[11px] font-medium uppercase tracking-wider rounded-sm transition-all ${
              filters.purpose === 'rent'
                ? 'bg-navy text-white font-semibold shadow-sm'
                : 'text-cool-600 hover:text-navy'
            }`}
          >
            For Rent
          </button>
        </div>

        {/* View Mode Switcher and Sort */}
        <div className="flex items-center space-x-3">
          {/* Sort dropdown */}
          <div className="flex items-center space-x-1.5 text-[11px] text-cool-500">
            <span className="hidden sm:inline">Sort:</span>
            <select
              value={filters.sortBy}
              onChange={handleSortChange}
              className="bg-cool-50 border border-cool-200 py-1 px-2.5 rounded-sm text-cool-800 text-[11px] font-medium focus:outline-none focus:border-navy"
            >
              <option value="featured">Featured First</option>
              <option value="newest">Recently Listed</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>

          {/* View Mode Buttons (Grid / List / Map) */}
          <div className="flex items-center space-x-0.5 border border-cool-200 rounded-sm p-0.5 bg-cool-50">
            <button
              onClick={() => onViewModeChange('grid')}
              className={`p-1 rounded-sm transition-colors ${
                viewMode === 'grid' ? 'bg-navy text-white' : 'text-cool-500 hover:text-navy'
              }`}
              title="Grid View"
              aria-label="Grid View"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onViewModeChange('list')}
              className={`p-1 rounded-sm transition-colors ${
                viewMode === 'list' ? 'bg-navy text-white' : 'text-cool-500 hover:text-navy'
              }`}
              title="List View"
              aria-label="List View"
            >
              <List className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onViewModeChange('map')}
              className={`p-1 rounded-sm transition-colors ${
                viewMode === 'map' ? 'bg-navy text-white' : 'text-cool-500 hover:text-navy'
              }`}
              title="Map View"
              aria-label="Map View"
            >
              <Map className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Primary Search Inputs Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-3">
        {/* Keyword input */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-cool-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search address, city, or Ref..."
            value={filters.searchQuery}
            onChange={handleTextChange}
            className="w-full bg-cool-50 border border-cool-200 pl-8 pr-3 py-2 text-xs text-cool-800 placeholder-cool-400 rounded-sm focus:outline-none focus:border-navy"
          />
        </div>

        {/* Property Type */}
        <div>
          <select
            value={filters.type}
            onChange={handleTypeChange}
            className="w-full bg-cool-50 border border-cool-200 px-2.5 py-2 text-xs text-cool-800 rounded-sm focus:outline-none focus:border-navy font-medium"
          >
            {PROPERTY_TYPES.map(t => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </div>

        {/* Destination */}
        <div>
          <select
            value={filters.city}
            onChange={handleCityChange}
            className="w-full bg-cool-50 border border-cool-200 px-2.5 py-2 text-xs text-cool-800 rounded-sm focus:outline-none focus:border-navy font-medium"
          >
            <option value="all">All Destinations</option>
            {locations.map(loc => (
              <option key={loc.id} value={loc.name}>
                {loc.name} ({loc.country})
              </option>
            ))}
          </select>
        </div>

        {/* Min & Max Price select */}
        <div className="grid grid-cols-2 gap-1.5">
          <select
            value={filters.minPrice}
            onChange={handleMinPriceChange}
            className="w-full bg-cool-50 border border-cool-200 px-2 py-2 text-xs text-cool-800 rounded-sm focus:outline-none focus:border-navy"
          >
            <option value={0}>Min Price</option>
            <option value={500000}>$500k</option>
            <option value={2000000}>$2M</option>
            <option value={5000000}>$5M</option>
            <option value={10000000}>$10M</option>
            <option value={20000000}>$20M</option>
          </select>

          <select
            value={filters.maxPrice}
            onChange={handleMaxPriceChange}
            className="w-full bg-cool-50 border border-cool-200 px-2 py-2 text-xs text-cool-800 rounded-sm focus:outline-none focus:border-navy"
          >
            <option value={100000000}>Max Price</option>
            <option value={5000000}>$5M</option>
            <option value={10000000}>$10M</option>
            <option value={20000000}>$20M</option>
            <option value={50000000}>$50M</option>
          </select>
        </div>
      </div>

      {/* Advanced Filter Accordion Toggle */}
      <div className="pt-3 flex items-center justify-between">
        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="flex items-center space-x-1 text-[11px] font-medium uppercase tracking-wider text-navy hover:text-black transition-colors"
        >
          <SlidersHorizontal className="w-3 h-3" />
          <span>{showAdvanced ? 'Fewer Criteria' : 'More Search Filters & Amenities'}</span>
          {showAdvanced ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        </button>

        {/* Results Counter & Reset */}
        <div className="flex items-center space-x-3">
          <span className="text-[11px] text-cool-500">
            <strong className="text-cool-900 font-semibold">{totalResults}</strong> matching residences
          </span>
          <button
            onClick={onResetFilters}
            className="flex items-center space-x-1 text-[11px] text-cool-400 hover:text-cool-700 transition-colors"
            title="Reset filters"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Expanded Advanced Criteria */}
      {showAdvanced && (
        <div className="mt-3 pt-3 border-t border-cool-100 space-y-3 animate-in fade-in duration-150">
          {/* Bedrooms Selector */}
          <div>
            <span className="text-[10px] uppercase tracking-wider text-cool-400 font-medium block mb-1.5">
              Bedrooms
            </span>
            <div className="flex flex-wrap gap-1.5">
              {['all', '1', '2', '3', '4', '5+'].map(val => (
                <button
                  key={val}
                  type="button"
                  onClick={() => handleBedroomsChange(val)}
                  className={`px-2.5 py-1 text-[11px] rounded-sm font-medium border transition-colors ${
                    filters.bedrooms === val
                      ? 'bg-navy text-white border-navy'
                      : 'bg-cool-50 text-cool-700 border-cool-200 hover:border-cool-300'
                  }`}
                >
                  {val === 'all' ? 'Any' : `${val} Beds`}
                </button>
              ))}
            </div>
          </div>

          {/* Amenities */}
          <div>
            <span className="text-[10px] uppercase tracking-wider text-cool-400 font-medium block mb-1.5">
              Amenities & Features
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-1.5">
              {AMENITIES_LIST.map((amenity, i) => {
                const checked = filters.amenities.includes(amenity);
                return (
                  <button
                    key={i}
                    type="button"
                    onClick={() => handleAmenityToggle(amenity)}
                    className={`text-left px-2 py-1 text-[11px] rounded-sm border transition-colors flex items-center justify-between ${
                      checked
                        ? 'bg-pink-soft border-pink-muted text-navy font-medium'
                        : 'bg-cool-50 border-cool-200 text-cool-600 hover:border-cool-300'
                    }`}
                  >
                    <span className="truncate mr-1">{amenity}</span>
                    {checked && <span className="text-navy font-bold text-[10px]">✓</span>}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
