import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useRealEstate } from '../context/RealEstateContext';
import { PropertyFilterBar } from '../components/property/PropertyFilterBar';
import { PropertyCard } from '../components/property/PropertyCard';
import { PropertyMap } from '../components/property/PropertyMap';
import { FilterState } from '../types';

export const PropertiesPage: React.FC = () => {
  const { properties } = useRealEstate();
  const [searchParams] = useSearchParams();

  // Initialize filter state from URL query parameters
  const [filters, setFilters] = useState<FilterState>(() => {
    const purposeParam = searchParams.get('purpose');
    const typeParam = searchParams.get('type');
    const cityParam = searchParams.get('city');
    const tagParam = searchParams.get('tag');
    const minPriceParam = searchParams.get('minPrice');
    const maxPriceParam = searchParams.get('maxPrice');
    const bedroomsParam = searchParams.get('bedrooms');

    return {
      searchQuery: '',
      purpose: purposeParam === 'sale' || purposeParam === 'rent' ? purposeParam : 'all',
      type: typeParam || 'all',
      city: cityParam || 'all',
      minPrice: minPriceParam ? Number(minPriceParam) : 0,
      maxPrice: maxPriceParam ? Number(maxPriceParam) : 100000000,
      bedrooms: bedroomsParam || 'all',
      bathrooms: 'all',
      amenities: [],
      furnished: 'all',
      sortBy: 'featured',
      tag: tagParam || undefined
    };
  });

  const [viewMode, setViewMode] = useState<'grid' | 'list' | 'map'>('grid');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 9;

  // Sync URL params
  useEffect(() => {
    const purposeParam = searchParams.get('purpose');
    const typeParam = searchParams.get('type');
    const cityParam = searchParams.get('city');
    const tagParam = searchParams.get('tag');

    setFilters(prev => ({
      ...prev,
      purpose: purposeParam === 'sale' || purposeParam === 'rent' ? purposeParam : prev.purpose,
      type: typeParam || prev.type,
      city: cityParam || prev.city,
      tag: tagParam || prev.tag
    }));
  }, [searchParams]);

  // Dynamic Filtering Logic
  const filteredProperties = useMemo(() => {
    return properties.filter(prop => {
      if (filters.searchQuery.trim()) {
        const q = filters.searchQuery.toLowerCase();
        const matchesQuery =
          prop.title.toLowerCase().includes(q) ||
          prop.referenceId.toLowerCase().includes(q) ||
          prop.description.toLowerCase().includes(q) ||
          prop.location.city.toLowerCase().includes(q) ||
          prop.location.area.toLowerCase().includes(q) ||
          prop.location.address.toLowerCase().includes(q);
        if (!matchesQuery) return false;
      }

      if (filters.purpose !== 'all' && prop.purpose !== filters.purpose) {
        return false;
      }

      if (filters.type !== 'all' && prop.type !== filters.type) {
        return false;
      }

      if (filters.city !== 'all') {
        const cityMatch =
          prop.location.city.toLowerCase() === filters.city.toLowerCase() ||
          prop.location.country.toLowerCase() === filters.city.toLowerCase();
        if (!cityMatch) return false;
      }

      if (prop.price < filters.minPrice || prop.price > filters.maxPrice) {
        return false;
      }

      if (filters.bedrooms !== 'all') {
        const requiredBeds = parseInt(filters.bedrooms, 10);
        if (filters.bedrooms === '5+') {
          if (prop.bedrooms < 5) return false;
        } else if (prop.bedrooms < requiredBeds) {
          return false;
        }
      }

      if (filters.amenities.length > 0) {
        const hasAllAmenities = filters.amenities.every(am =>
          prop.amenities.some(propAm => propAm.toLowerCase().includes(am.toLowerCase()))
        );
        if (!hasAllAmenities) return false;
      }

      if (filters.tag === 'luxury' && !prop.isLuxury) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (filters.sortBy === 'newest') {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
      if (filters.sortBy === 'price-asc') {
        return a.price - b.price;
      }
      if (filters.sortBy === 'price-desc') {
        return b.price - a.price;
      }
      if (a.isFeatured && !b.isFeatured) return -1;
      if (!a.isFeatured && b.isFeatured) return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }, [properties, filters]);

  const handleResetFilters = () => {
    setFilters({
      searchQuery: '',
      purpose: 'all',
      type: 'all',
      city: 'all',
      minPrice: 0,
      maxPrice: 100000000,
      bedrooms: 'all',
      bathrooms: 'all',
      amenities: [],
      furnished: 'all',
      sortBy: 'featured',
      tag: undefined
    });
    setCurrentPage(1);
  };

  const paginatedProperties = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredProperties.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredProperties, currentPage]);

  const totalPages = Math.ceil(filteredProperties.length / itemsPerPage);

  // Refined Page Titles
  let pageTitle = "Curated Property Portfolio";
  let pageSubtitle = "Explore exceptional prime residences, architectural estates, and commercial holdings.";
  if (filters.purpose === 'sale') {
    pageTitle = "Luxury Properties for Sale";
    pageSubtitle = "Browse prime freehold estates, penthouses, and private mansions available for acquisition.";
  } else if (filters.purpose === 'rent') {
    pageTitle = "Prime Residences for Rent";
    pageSubtitle = "Long-term luxury rentals and executive residences in world-class destinations.";
  } else if (filters.tag === 'luxury') {
    pageTitle = "Trophy & Ultra-Luxury Estates";
    pageSubtitle = "Architecturally significant landmark residences curated for high-net-worth collectors.";
  } else if (filters.type === 'commercial') {
    pageTitle = "Commercial Real Estate & Institutional Assets";
    pageSubtitle = "Prime retail flagships, trophy office floors, and institutional investments.";
  } else if (filters.type === 'land') {
    pageTitle = "Prime Development Land & Plots";
    pageSubtitle = "Rare seafront parcels and elevated building plots with approved architectural consents.";
  }

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Refined Page Header - Smaller & More Refined */}
        <div className="mb-8 text-center max-w-2xl mx-auto">
          <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1.5">
            Private Collection
          </span>
          <h1 className="font-serif text-2xl sm:text-4xl font-medium text-cool-900 mb-2">
            {pageTitle}
          </h1>
          <p className="text-cool-500 text-xs font-light leading-relaxed">
            {pageSubtitle}
          </p>
        </div>

        {/* Real-time Filter Bar */}
        <PropertyFilterBar
          filters={filters}
          onFilterChange={(newFilters) => {
            setFilters(newFilters);
            setCurrentPage(1);
          }}
          onResetFilters={handleResetFilters}
          totalResults={filteredProperties.length}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
        />

        {/* Results */}
        {filteredProperties.length === 0 ? (
          <div className="bg-white border border-cool-200/80 rounded-sm p-10 text-center max-w-md mx-auto shadow-sm">
            <h3 className="font-serif text-xl font-medium text-cool-900 mb-1.5">
              No Matching Residences
            </h3>
            <p className="text-cool-500 text-xs font-light mb-4">
              Try adjusting your search criteria or reset filters to view all available listings.
            </p>
            <button
              onClick={handleResetFilters}
              className="bg-navy hover:bg-navy-midnight text-white px-5 py-2 text-xs font-medium uppercase tracking-wider rounded-sm transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : viewMode === 'map' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            <div className="lg:col-span-5 space-y-3.5 max-h-[700px] overflow-y-auto pr-1">
              {filteredProperties.map(prop => (
                <PropertyCard key={prop.id} property={prop} viewMode="list" />
              ))}
            </div>
            <div className="lg:col-span-7 sticky top-28 h-[700px]">
              <PropertyMap properties={filteredProperties} height="100%" />
            </div>
          </div>
        ) : viewMode === 'list' ? (
          <div className="space-y-4">
            {paginatedProperties.map(prop => (
              <PropertyCard key={prop.id} property={prop} viewMode="list" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {paginatedProperties.map(prop => (
              <PropertyCard key={prop.id} property={prop} viewMode="grid" />
            ))}
          </div>
        )}

        {/* Pagination */}
        {viewMode !== 'map' && totalPages > 1 && (
          <div className="mt-12 flex items-center justify-center space-x-1.5">
            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              className="px-3 py-1.5 text-xs uppercase tracking-wider font-medium border border-cool-200 bg-white rounded-sm disabled:opacity-40 disabled:cursor-not-allowed hover:bg-cool-50 text-cool-700"
            >
              Prev
            </button>

            {[...Array(totalPages)].map((_, idx) => {
              const page = idx + 1;
              return (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  className={`w-8 h-8 text-xs font-medium rounded-sm transition-colors ${
                    currentPage === page
                      ? 'bg-navy text-white'
                      : 'bg-white border border-cool-200 text-cool-700 hover:bg-cool-50'
                  }`}
                >
                  {page}
                </button>
              );
            })}

            <button
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              className="px-3 py-1.5 text-xs uppercase tracking-wider font-medium border border-cool-200 bg-white rounded-sm disabled:opacity-40 disabled:cursor-not-allowed hover:bg-cool-50 text-cool-700"
            >
              Next
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
