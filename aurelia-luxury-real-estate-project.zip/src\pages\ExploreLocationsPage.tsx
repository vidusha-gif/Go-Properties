import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { useRealEstate } from '../context/RealEstateContext';

export const ExploreLocationsPage: React.FC = () => {
  const { locations, properties } = useRealEstate();

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1.5">
            Jurisdictions
          </span>
          <h1 className="font-serif text-2xl sm:text-4xl font-medium text-cool-900 mb-2">
            Prime International Destinations
          </h1>
          <p className="text-cool-500 text-xs font-light leading-relaxed">
            Aurelia maintains advisory presence across the world's most dynamic capital markets, financial hubs, and Mediterranean coastal sanctuaries.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {locations.map(loc => {
            const propCount = properties.filter(
              p => p.location.city.toLowerCase() === loc.name.toLowerCase()
            ).length;

            return (
              <div
                key={loc.id}
                className="group bg-white border border-cool-200/80 rounded-sm overflow-hidden shadow-sm hover:shadow-[0_8px_25px_rgba(16,27,51,0.06)] transition-all duration-300 flex flex-col"
              >
                <div className="relative aspect-[16/10] overflow-hidden bg-cool-100">
                  <img
                    src={loc.image}
                    alt={loc.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-deep/85 via-navy-deep/20 to-transparent" />

                  <div className="absolute top-2.5 left-2.5 bg-black/40 backdrop-blur-md px-2 py-0.5 rounded-sm text-[9px] font-medium uppercase tracking-wider text-white">
                    {loc.country}
                  </div>

                  <div className="absolute bottom-2.5 left-2.5 text-white">
                    <span className="text-[10px] uppercase tracking-wider text-pink-muted font-medium block">
                      {loc.region}
                    </span>
                    <h2 className="font-serif text-xl font-medium text-white">
                      {loc.name}
                    </h2>
                  </div>
                </div>

                <div className="p-4 flex-grow flex flex-col justify-between">
                  <p className="text-xs text-cool-500 font-light leading-relaxed mb-4">
                    {loc.description}
                  </p>

                  <div className="border-t border-cool-100 pt-3 flex items-center justify-between">
                    <span className="text-[11px] font-medium text-cool-700">
                      {propCount} Available Residences
                    </span>

                    <Link
                      to={`/properties?city=${loc.name}`}
                      className="bg-navy hover:bg-navy-midnight text-white px-2.5 py-1 rounded-sm text-[10px] uppercase tracking-wider font-medium flex items-center space-x-1 transition-colors"
                    >
                      <span>Explore</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
