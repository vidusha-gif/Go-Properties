import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  MessageCircle,
  CheckCircle2,
  Send,
  Shield
} from 'lucide-react';
import { useRealEstate } from '../context/RealEstateContext';
import { generateWhatsAppLink } from '../utils/helpers';

export const ContactPage: React.FC = () => {
  const { siteSettings, addLead } = useRealEstate();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'General Inquiry',
    message: ''
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addLead({
      type: 'general',
      customerName: formData.name,
      email: formData.email,
      phone: formData.phone,
      message: `[${formData.subject}] ${formData.message}`,
      source: 'Contact Us Page'
    });

    setIsSubmitted(true);
    setFormData({
      name: '',
      email: '',
      phone: '',
      subject: 'General Inquiry',
      message: ''
    });
  };

  const whatsappUrl = generateWhatsAppLink(
    siteSettings.whatsappNumber,
    `Hello, I would like to arrange an appointment with the private advisory team at ${siteSettings.companyName}.`
  );

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1.5">
            Private Communication
          </span>
          <h1 className="font-serif text-2xl sm:text-4xl font-medium text-cool-900 mb-2">
            Connect with Our Private Office
          </h1>
          <p className="text-cool-500 text-xs font-light leading-relaxed">
            Our senior brokers and acquisitions specialists are accessible for confidential consultations, off-market briefings, and private viewings.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Office Details (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white border border-cool-200/80 rounded-sm p-6 shadow-sm">
              <h3 className="font-serif text-xl font-medium text-cool-900 mb-4 border-b border-cool-100 pb-2">
                Headquarters
              </h3>

              <div className="space-y-4 text-xs text-cool-600">
                <div className="flex items-start space-x-3">
                  <MapPin className="w-4 h-4 text-pink-muted flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-cool-900 block text-xs font-medium mb-0.5">
                      London Private Office
                    </strong>
                    <span className="leading-relaxed block">{siteSettings.address}</span>
                    <span className="text-cool-400 block mt-0.5 text-[11px]">Visits by private appointment</span>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <Phone className="w-4 h-4 text-pink-muted flex-shrink-0" />
                  <div>
                    <strong className="text-cool-900 block text-xs font-medium">
                      Direct Telephony
                    </strong>
                    <a
                      href={`tel:${siteSettings.phone.replace(/[^0-9+]/g, '')}`}
                      className="hover:text-navy transition-colors"
                    >
                      {siteSettings.phone}
                    </a>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <Mail className="w-4 h-4 text-pink-muted flex-shrink-0" />
                  <div>
                    <strong className="text-cool-900 block text-xs font-medium">
                      Client Email
                    </strong>
                    <a
                      href={`mailto:${siteSettings.email}`}
                      className="hover:text-navy transition-colors"
                    >
                      {siteSettings.email}
                    </a>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <Clock className="w-4 h-4 text-cool-400 flex-shrink-0" />
                  <div>
                    <strong className="text-cool-900 block text-xs font-medium">
                      Operating Hours
                    </strong>
                    <span>{siteSettings.businessHours}</span>
                  </div>
                </div>
              </div>

              {/* Direct WhatsApp Action */}
              <div className="mt-6 pt-4 border-t border-cool-100">
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-navy hover:bg-navy-midnight text-white py-2 px-3 rounded-sm text-xs font-medium uppercase tracking-wider flex items-center justify-center space-x-2 transition-colors shadow-sm"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-pink-muted" />
                  <span>Start Confidential WhatsApp Chat</span>
                </a>
              </div>
            </div>

            {/* Global Desks */}
            <div className="bg-white border border-cool-200/80 rounded-sm p-5 text-xs text-cool-600 shadow-sm">
              <h4 className="font-serif text-base font-medium text-cool-900 mb-2">
                Regional Partner Desks
              </h4>
              <ul className="space-y-1.5 text-xs">
                <li>• <strong>Dubai Desk:</strong> Gate Village, DIFC, Dubai, UAE</li>
                <li>• <strong>Côte d'Azur Desk:</strong> Boulevard de la Croisette, Cannes, France</li>
                <li>• <strong>Zurich Desk:</strong> Rue du Rhône, Geneva / Zurich, Switzerland</li>
                <li>• <strong>Los Angeles Desk:</strong> Wilshire Boulevard, Beverly Hills, CA</li>
              </ul>
            </div>
          </div>

          {/* Message Form (7 cols) */}
          <div className="lg:col-span-7">
            <div className="bg-white border border-cool-200/80 rounded-sm p-6 sm:p-8 shadow-sm">
              <div className="border-b border-cool-100 pb-3 mb-4">
                <h3 className="font-serif text-xl font-medium text-cool-900 mb-0.5">
                  Transmit Secure Message
                </h3>
                <p className="text-xs text-cool-500 font-light">
                  All communications are routed directly to our private client partner on duty.
                </p>
              </div>

              {isSubmitted ? (
                <div className="bg-emerald-50 border border-emerald-200 p-6 rounded-sm text-center animate-in fade-in">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
                  <h4 className="font-serif text-xl font-medium text-emerald-900 mb-1">
                    Message Safely Delivered
                  </h4>
                  <p className="text-xs text-emerald-700 font-light max-w-sm mx-auto mb-4">
                    Thank you. Your inquiry has been registered. An advisor will contact you promptly.
                  </p>
                  <button
                    onClick={() => setIsSubmitted(false)}
                    className="bg-navy text-white px-4 py-1.5 text-xs uppercase tracking-wider font-medium rounded-sm"
                  >
                    Send Another Note
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Lady Evelyn Montgomery"
                        value={formData.name}
                        onChange={e => setFormData({ ...formData, name: e.target.value })}
                        className="w-full bg-cool-50 border border-cool-200 px-3 py-2 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="client@advisory.com"
                        value={formData.email}
                        onChange={e => setFormData({ ...formData, email: e.target.value })}
                        className="w-full bg-cool-50 border border-cool-200 px-3 py-2 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                        Phone *
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="+44 20..."
                        value={formData.phone}
                        onChange={e => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full bg-cool-50 border border-cool-200 px-3 py-2 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                        Mandate Focus
                      </label>
                      <select
                        value={formData.subject}
                        onChange={e => setFormData({ ...formData, subject: e.target.value })}
                        className="w-full bg-cool-50 border border-cool-200 px-3 py-2 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                      >
                        <option value="Acquisitions / Buying">Acquisitions / Buying</option>
                        <option value="Property Disposal / Selling">Property Disposal / Selling</option>
                        <option value="Luxury Lettings">Luxury Lettings / Rentals</option>
                        <option value="Commercial & Institutional">Commercial Assets</option>
                        <option value="Off-Market Confidentiality">Off-Market NDA Search</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                      Message *
                    </label>
                    <textarea
                      rows={4}
                      required
                      placeholder="Please outline your target location, budget parameters, or property specifications..."
                      value={formData.message}
                      onChange={e => setFormData({ ...formData, message: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 p-2.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none font-light"
                    />
                  </div>

                  <div className="pt-1 flex items-center justify-between">
                    <span className="text-[10px] text-cool-400 font-light flex items-center">
                      <Shield className="w-3 h-3 mr-1 text-pink-muted" />
                      Strict client confidentiality
                    </span>
                    <button
                      type="submit"
                      className="bg-navy hover:bg-navy-midnight text-white px-6 py-2.5 text-xs uppercase tracking-wider font-medium rounded-sm transition-colors flex items-center space-x-1.5"
                    >
                      <span>Transmit Message</span>
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
