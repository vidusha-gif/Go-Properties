import { Vehicle } from '../types';

export const OFFICIAL_FLEET: Vehicle[] = [
  {
    id: 'fleet-bmw-x1',
    category: 'Luxury SUV',
    models: 'BMW X1',
    image: 'https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=1200&q=80',
    capacity: '3 - 4 Passengers',
    luggage: '2 - 3 Large Suitcases + Hand Luggage',
    ac: 'Dual-Zone Automatic Climate Control',
    transmission: '7-Speed Steptronic Automatic',
    driver: 'Executive VIP English-Speaking Chauffeur',
    features: [
      'German executive comfort & whisper-quiet cabin',
      'Panoramic glass sunroof & ambient lighting',
      'Complimentary high-speed 4G Wi-Fi onboard',
      'Bottled mineral water & chilled refreshing towels',
      'Full comprehensive passenger insurance coverage'
    ],
    bestFor: 'Couples, executive travelers, VIP delegations, and honeymooners seeking supreme luxury across Sri Lanka.'
  },
  {
    id: 'fleet-byd-atto5',
    category: 'Electric SUV (Eco-Luxury)',
    models: 'BYD Atto 5',
    image: '', // Dedicated placeholder ensuring verified model accuracy
    capacity: '3 - 4 Passengers',
    luggage: '3 Large Bags + 180L Front Frunk Storage',
    ac: 'Intelligent Multi-Zone Heat Pump AC & Air Purifier',
    transmission: 'Single-Speed Automatic Electric Drive',
    driver: 'Certified Eco-Touring Chauffeur-Guide',
    features: [
      'Zero-emission whisper-silent electric touring',
      'Advanced 800V Blade Battery architecture',
      'High-tech panoramic cabin with rotating touchscreen',
      'Twin smartphone wireless charging pads',
      'Zero tailpipe emissions through national parks & tea hills'
    ],
    bestFor: 'Eco-conscious international travelers, modern couples, and silent scenic touring through nature reserves.'
  },
  {
    id: 'fleet-honda-vezel',
    category: 'Compact SUV',
    models: 'Honda Vezel',
    image: '', // Dedicated placeholder ensuring verified model accuracy
    capacity: '3 - 4 Passengers',
    luggage: '2 - 3 Medium Suitcases',
    ac: 'Dual-Zone Automatic Climate Control',
    transmission: 'Automatic / e:HEV Intelligent Drive',
    driver: 'Experienced English-Speaking Chauffeur-Guide',
    features: [
      'Elevated ride height for smooth scenic sightseeing',
      'Honda Magic Seats for flexible luggage configurations',
      'Smooth, fuel-efficient hybrid mountain cruising',
      'Onboard USB charging ports & complimentary bottled water',
      'Comprehensive tourist vehicle passenger cover'
    ],
    bestFor: 'Small families, photography enthusiasts, solo adventurers, and hill country scenic tours.'
  },
  {
    id: 'fleet-toyota-kdh',
    category: 'Passenger Van',
    models: 'Toyota KDH Van (High-Roof Commuter)',
    image: 'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?auto=format&fit=crop&w=1200&q=80',
    capacity: '6 - 9 Passengers',
    luggage: '6 - 8 Large Suitcases',
    ac: 'Dual Multi-Vent Roof Air Conditioning',
    transmission: 'Automatic',
    driver: 'Licensed National Tourist Guide Chauffeur',
    features: [
      'Spacious high-roof headroom with wide center aisle',
      'Ergonomic reclining captain armchairs with ample legroom',
      'Generous rear luggage cargo capacity',
      'Individual AC blower vents & reading lamps for each seat',
      'PA audio system for guided cultural commentary'
    ],
    bestFor: 'Families with children, small tour groups, and multi-day round-island journeys in total comfort.'
  },
  {
    id: 'fleet-buses',
    category: 'Large Group Transportation',
    models: 'Air-Conditioned Tourist Coach (2 Vehicles)',
    image: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=1200&q=80',
    capacity: '28 - 45 Passengers (2 Vehicles Available)',
    luggage: '35 - 45 Large Luggage Bags (Underfloor Bays)',
    ac: 'Heavy-Duty Central Climate Automation',
    transmission: 'Air-Braked Manual / Automatic',
    driver: 'Two Senior Drivers & Dedicated National Tour Guide Team',
    features: [
      'Pneumatic luxury air suspension ride for smooth highway cruising',
      'Ergonomic high-back reclining seats with meal trays',
      'Dual LCD multimedia entertainment & microphone PA system',
      'Spacious underfloor luggage bays for large tour groups',
      'First aid, fire safety, and emergency response equipped'
    ],
    bestFor: 'Large international travel groups, incentive charters, universities, and wedding party delegations.'
  }
];
