export function formatCurrency(amount: number, currencySymbol: string = '$'): string {
  if (amount === undefined || amount === null) return '';
  return `${currencySymbol}${amount.toLocaleString('en-US')}`;
}

export function formatPrice(price: number, currencySymbol: string = '$', rentalPeriod?: string): string {
  const formatted = formatCurrency(price, currencySymbol);
  if (rentalPeriod) {
    return `${formatted} / ${rentalPeriod}`;
  }
  return formatted;
}

export function formatArea(sqFt: number): string {
  if (!sqFt) return 'N/A';
  const sqM = Math.round(sqFt * 0.092903);
  return `${sqFt.toLocaleString('en-US')} sq ft (${sqM.toLocaleString('en-US')} m²)`;
}

export function generateWhatsAppLink(phone: string, text: string): string {
  // Clean phone number: remove +, spaces, dashes, parentheses
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const encodedText = encodeURIComponent(text);
  return `https://wa.me/${cleanPhone}?text=${encodedText}`;
}

export function truncateText(text: string, maxLength: number): string {
  if (!text) return '';
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength).trim() + '...';
}

export function formatDate(dateString: string): string {
  try {
    const d = new Date(dateString);
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  } catch {
    return dateString;
  }
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w ]+/g, '')
    .replace(/ +/g, '-');
}
