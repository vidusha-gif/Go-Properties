import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Property,
  LocationItem,
  BlogPost,
  Testimonial,
  TeamMember,
  FAQItem,
  SiteSettings,
  InquiryLead,
  PropertySubmission,
  LeadStatus
} from '../types';
import {
  initialProperties,
  initialLocations,
  initialTestimonials,
  initialBlogPosts,
  initialTeamMembers,
  initialFAQs,
  initialSiteSettings,
  initialLeads
} from '../data/initialData';

interface RealEstateContextType {
  // Properties
  properties: Property[];
  addProperty: (property: Omit<Property, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateProperty: (id: string, property: Partial<Property>) => void;
  deleteProperty: (id: string) => void;
  toggleFeatured: (id: string) => void;
  updatePropertyStatus: (id: string, status: Property['status']) => void;
  getPropertyById: (id: string) => Property | undefined;
  getPropertyByReference: (ref: string) => Property | undefined;

  // Favorites
  favorites: string[]; // Property IDs
  toggleFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;
  clearFavorites: () => void;

  // Comparison (max 4)
  compareList: string[]; // Property IDs
  toggleCompare: (id: string) => { added: boolean; maxReached?: boolean };
  isInCompare: (id: string) => boolean;
  removeFromCompare: (id: string) => void;
  clearCompare: () => void;

  // Leads / CRM
  leads: InquiryLead[];
  addLead: (lead: Omit<InquiryLead, 'id' | 'createdAt' | 'status'>) => void;
  updateLeadStatus: (id: string, status: LeadStatus) => void;
  addLeadNote: (id: string, note: string) => void;
  deleteLead: (id: string) => void;

  // Property Owner Submissions ("Sell Your Property")
  submissions: PropertySubmission[];
  addSubmission: (submission: Omit<PropertySubmission, 'id' | 'createdAt' | 'status'>) => void;
  updateSubmissionStatus: (id: string, status: PropertySubmission['status']) => void;

  // Locations
  locations: LocationItem[];
  addLocation: (loc: Omit<LocationItem, 'id'>) => void;
  updateLocation: (id: string, loc: Partial<LocationItem>) => void;
  deleteLocation: (id: string) => void;

  // Blog
  blogPosts: BlogPost[];
  addBlogPost: (post: Omit<BlogPost, 'id' | 'publishedAt'>) => void;
  updateBlogPost: (id: string, post: Partial<BlogPost>) => void;
  deleteBlogPost: (id: string) => void;

  // Testimonials
  testimonials: Testimonial[];
  addTestimonial: (test: Omit<Testimonial, 'id' | 'date'>) => void;
  deleteTestimonial: (id: string) => void;

  // Team & FAQs
  teamMembers: TeamMember[];
  faqs: FAQItem[];

  // Settings
  siteSettings: SiteSettings;
  updateSiteSettings: (settings: Partial<SiteSettings>) => void;

  // Quick View Modal
  quickViewProperty: Property | null;
  openQuickView: (prop: Property) => void;
  closeQuickView: () => void;
}

const RealEstateContext = createContext<RealEstateContextType | undefined>(undefined);

// Storage Keys
const STORAGE_PREFIX = 'aurelia_';
const KEYS = {
  PROPERTIES: `${STORAGE_PREFIX}properties`,
  FAVORITES: `${STORAGE_PREFIX}favorites`,
  COMPARE: `${STORAGE_PREFIX}compare`,
  LEADS: `${STORAGE_PREFIX}leads`,
  SUBMISSIONS: `${STORAGE_PREFIX}submissions`,
  LOCATIONS: `${STORAGE_PREFIX}locations`,
  BLOG: `${STORAGE_PREFIX}blog`,
  TESTIMONIALS: `${STORAGE_PREFIX}testimonials`,
  SETTINGS: `${STORAGE_PREFIX}settings`
};

export const RealEstateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Properties
  const [properties, setProperties] = useState<Property[]>(() => {
    try {
      const stored = localStorage.getItem(KEYS.PROPERTIES);
      return stored ? JSON.parse(stored) : initialProperties;
    } catch {
      return initialProperties;
    }
  });

  // 2. Favorites
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(KEYS.FAVORITES);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // 3. Compare List
  const [compareList, setCompareList] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(KEYS.COMPARE);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // 4. Leads / CRM
  const [leads, setLeads] = useState<InquiryLead[]>(() => {
    try {
      const stored = localStorage.getItem(KEYS.LEADS);
      return stored ? JSON.parse(stored) : initialLeads;
    } catch {
      return initialLeads;
    }
  });

  // 5. Submissions
  const [submissions, setSubmissions] = useState<PropertySubmission[]>(() => {
    try {
      const stored = localStorage.getItem(KEYS.SUBMISSIONS);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // 6. Locations
  const [locations, setLocations] = useState<LocationItem[]>(() => {
    try {
      const stored = localStorage.getItem(KEYS.LOCATIONS);
      return stored ? JSON.parse(stored) : initialLocations;
    } catch {
      return initialLocations;
    }
  });

  // 7. Blog
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>(() => {
    try {
      const stored = localStorage.getItem(KEYS.BLOG);
      return stored ? JSON.parse(stored) : initialBlogPosts;
    } catch {
      return initialBlogPosts;
    }
  });

  // 8. Testimonials
  const [testimonials, setTestimonials] = useState<Testimonial[]>(() => {
    try {
      const stored = localStorage.getItem(KEYS.TESTIMONIALS);
      return stored ? JSON.parse(stored) : initialTestimonials;
    } catch {
      return initialTestimonials;
    }
  });

  // 9. Site Settings
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(() => {
    try {
      const stored = localStorage.getItem(KEYS.SETTINGS);
      return stored ? JSON.parse(stored) : initialSiteSettings;
    } catch {
      return initialSiteSettings;
    }
  });

  // Quick View state
  const [quickViewProperty, setQuickViewProperty] = useState<Property | null>(null);

  // Sync state changes to localStorage
  useEffect(() => {
    localStorage.setItem(KEYS.PROPERTIES, JSON.stringify(properties));
  }, [properties]);

  useEffect(() => {
    localStorage.setItem(KEYS.FAVORITES, JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem(KEYS.COMPARE, JSON.stringify(compareList));
  }, [compareList]);

  useEffect(() => {
    localStorage.setItem(KEYS.LEADS, JSON.stringify(leads));
  }, [leads]);

  useEffect(() => {
    localStorage.setItem(KEYS.SUBMISSIONS, JSON.stringify(submissions));
  }, [submissions]);

  useEffect(() => {
    localStorage.setItem(KEYS.LOCATIONS, JSON.stringify(locations));
  }, [locations]);

  useEffect(() => {
    localStorage.setItem(KEYS.BLOG, JSON.stringify(blogPosts));
  }, [blogPosts]);

  useEffect(() => {
    localStorage.setItem(KEYS.TESTIMONIALS, JSON.stringify(testimonials));
  }, [testimonials]);

  useEffect(() => {
    localStorage.setItem(KEYS.SETTINGS, JSON.stringify(siteSettings));
  }, [siteSettings]);

  // Property Actions
  const addProperty = (newProp: Omit<Property, 'id' | 'createdAt' | 'updatedAt'>) => {
    const timestamp = new Date().toISOString();
    const created: Property = {
      ...newProp,
      id: `prop-${Date.now()}`,
      createdAt: timestamp,
      updatedAt: timestamp,
      viewsCount: 0
    };
    setProperties(prev => [created, ...prev]);
  };

  const updateProperty = (id: string, updatedFields: Partial<Property>) => {
    setProperties(prev =>
      prev.map(p =>
        p.id === id
          ? { ...p, ...updatedFields, updatedAt: new Date().toISOString() }
          : p
      )
    );
  };

  const deleteProperty = (id: string) => {
    setProperties(prev => prev.filter(p => p.id !== id));
    setFavorites(prev => prev.filter(fId => fId !== id));
    setCompareList(prev => prev.filter(cId => cId !== id));
  };

  const toggleFeatured = (id: string) => {
    setProperties(prev =>
      prev.map(p => (p.id === id ? { ...p, isFeatured: !p.isFeatured } : p))
    );
  };

  const updatePropertyStatus = (id: string, status: Property['status']) => {
    setProperties(prev =>
      prev.map(p => (p.id === id ? { ...p, status } : p))
    );
  };

  const getPropertyById = (id: string) => properties.find(p => p.id === id);
  const getPropertyByReference = (ref: string) => properties.find(p => p.referenceId.toLowerCase() === ref.toLowerCase());

  // Favorites Actions
  const toggleFavorite = (id: string) => {
    setFavorites(prev =>
      prev.includes(id) ? prev.filter(fId => fId !== id) : [...prev, id]
    );
  };

  const isFavorite = (id: string) => favorites.includes(id);

  const clearFavorites = () => setFavorites([]);

  // Comparison Actions (up to 4 items)
  const toggleCompare = (id: string): { added: boolean; maxReached?: boolean } => {
    if (compareList.includes(id)) {
      setCompareList(prev => prev.filter(cId => cId !== id));
      return { added: false };
    }
    if (compareList.length >= 4) {
      return { added: false, maxReached: true };
    }
    setCompareList(prev => [...prev, id]);
    return { added: true };
  };

  const isInCompare = (id: string) => compareList.includes(id);
  const removeFromCompare = (id: string) => setCompareList(prev => prev.filter(cId => cId !== id));
  const clearCompare = () => setCompareList([]);

  // Leads & CRM Actions
  const addLead = (leadData: Omit<InquiryLead, 'id' | 'createdAt' | 'status'>) => {
    const newLead: InquiryLead = {
      ...leadData,
      id: `lead-${Date.now()}`,
      status: 'New',
      createdAt: new Date().toISOString()
    };
    setLeads(prev => [newLead, ...prev]);
  };

  const updateLeadStatus = (id: string, status: LeadStatus) => {
    setLeads(prev =>
      prev.map(l => (l.id === id ? { ...l, status } : l))
    );
  };

  const addLeadNote = (id: string, note: string) => {
    setLeads(prev =>
      prev.map(l => (l.id === id ? { ...l, notes: l.notes ? `${l.notes}\n${note}` : note } : l))
    );
  };

  const deleteLead = (id: string) => {
    setLeads(prev => prev.filter(l => l.id !== id));
  };

  // Submissions Actions
  const addSubmission = (subData: Omit<PropertySubmission, 'id' | 'createdAt' | 'status'>) => {
    const newSub: PropertySubmission = {
      ...subData,
      id: `sub-${Date.now()}`,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    setSubmissions(prev => [newSub, ...prev]);
  };

  const updateSubmissionStatus = (id: string, status: PropertySubmission['status']) => {
    setSubmissions(prev =>
      prev.map(s => (s.id === id ? { ...s, status } : s))
    );
  };

  // Locations Actions
  const addLocation = (loc: Omit<LocationItem, 'id'>) => {
    setLocations(prev => [...prev, { ...loc, id: `loc-${Date.now()}` }]);
  };

  const updateLocation = (id: string, loc: Partial<LocationItem>) => {
    setLocations(prev =>
      prev.map(l => (l.id === id ? { ...l, ...loc } : l))
    );
  };

  const deleteLocation = (id: string) => {
    setLocations(prev => prev.filter(l => l.id !== id));
  };

  // Blog Actions
  const addBlogPost = (post: Omit<BlogPost, 'id' | 'publishedAt'>) => {
    setBlogPosts(prev => [
      {
        ...post,
        id: `blog-${Date.now()}`,
        publishedAt: new Date().toISOString().split('T')[0]
      },
      ...prev
    ]);
  };

  const updateBlogPost = (id: string, post: Partial<BlogPost>) => {
    setBlogPosts(prev =>
      prev.map(p => (p.id === id ? { ...p, ...post } : p))
    );
  };

  const deleteBlogPost = (id: string) => {
    setBlogPosts(prev => prev.filter(p => p.id !== id));
  };

  // Testimonials Actions
  const addTestimonial = (test: Omit<Testimonial, 'id' | 'date'>) => {
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const d = new Date();
    const dateFormatted = `${monthNames[d.getMonth()]} ${d.getFullYear()}`;
    setTestimonials(prev => [
      {
        ...test,
        id: `test-${Date.now()}`,
        date: dateFormatted
      },
      ...prev
    ]);
  };

  const deleteTestimonial = (id: string) => {
    setTestimonials(prev => prev.filter(t => t.id !== id));
  };

  // Settings Action
  const updateSiteSettings = (settings: Partial<SiteSettings>) => {
    setSiteSettings(prev => ({ ...prev, ...settings }));
  };

  // Quick View Actions
  const openQuickView = (prop: Property) => setQuickViewProperty(prop);
  const closeQuickView = () => setQuickViewProperty(null);

  return (
    <RealEstateContext.Provider
      value={{
        properties,
        addProperty,
        updateProperty,
        deleteProperty,
        toggleFeatured,
        updatePropertyStatus,
        getPropertyById,
        getPropertyByReference,

        favorites,
        toggleFavorite,
        isFavorite,
        clearFavorites,

        compareList,
        toggleCompare,
        isInCompare,
        removeFromCompare,
        clearCompare,

        leads,
        addLead,
        updateLeadStatus,
        addLeadNote,
        deleteLead,

        submissions,
        addSubmission,
        updateSubmissionStatus,

        locations,
        addLocation,
        updateLocation,
        deleteLocation,

        blogPosts,
        addBlogPost,
        updateBlogPost,
        deleteBlogPost,

        testimonials,
        addTestimonial,
        deleteTestimonial,

        teamMembers: initialTeamMembers,
        faqs: initialFAQs,

        siteSettings,
        updateSiteSettings,

        quickViewProperty,
        openQuickView,
        closeQuickView
      }}
    >
      {children}
    </RealEstateContext.Provider>
  );
};

export const useRealEstate = () => {
  const ctx = useContext(RealEstateContext);
  if (!ctx) throw new Error('useRealEstate must be used within a RealEstateProvider');
  return ctx;
};
