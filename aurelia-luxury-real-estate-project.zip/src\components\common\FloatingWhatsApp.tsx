import React, { useState } from 'react';
import { MessageCircle, X, ArrowRight } from 'lucide-react';
import { useRealEstate } from '../../context/RealEstateContext';
import { generateWhatsAppLink } from '../../utils/helpers';

export const FloatingWhatsApp: React.FC = () => {
  const { siteSettings } = useRealEstate();
  const [isOpen, setIsOpen] = useState(false);

  const defaultMessage = `Hello, I am interested in inquiring about exclusive luxury properties with ${siteSettings.companyName}.`;
  const whatsappUrl = generateWhatsAppLink(siteSettings.whatsappNumber, defaultMessage);

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end">
      {/* Popover Card */}
      {isOpen && (
        <div className="mb-2.5 w-72 bg-navy text-white rounded-sm shadow-2xl border border-white/10 p-4 animate-in fade-in slide-in-from-bottom-2 duration-150">
          <div className="flex items-start justify-between pb-2.5 border-b border-white/10">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-full bg-pink-soft flex items-center justify-center text-navy">
                <MessageCircle className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-semibold text-white">Private Desk Concierge</h4>
                <div className="flex items-center space-x-1 text-[10px] text-pink-muted">
                  <span className="w-1.5 h-1.5 rounded-full bg-pink-muted animate-pulse"></span>
                  <span>Online & Ready</span>
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-cool-400 hover:text-white p-0.5"
              aria-label="Close"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="py-3 text-[11px] text-cool-300 font-light leading-relaxed">
            Welcome to <strong className="text-white font-medium">{siteSettings.companyName}</strong>. Our advisors are standing by for private viewing requests or valuation consultations.
          </div>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setIsOpen(false)}
            className="w-full bg-white hover:bg-pink-soft text-navy py-2 px-3 rounded-sm font-medium text-[11px] uppercase tracking-wider flex items-center justify-center space-x-1.5 transition-colors shadow-sm"
          >
            <span>Start WhatsApp Chat</span>
            <ArrowRight className="w-3 h-3" />
          </a>
        </div>
      )}

      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-12 h-12 rounded-full bg-navy hover:bg-navy-midnight text-white flex items-center justify-center shadow-xl hover:scale-105 transition-all duration-200 border border-white/20 relative"
        aria-label="Contact on WhatsApp"
        title="Chat on WhatsApp"
      >
        <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-pink-muted rounded-full border-2 border-navy"></span>
        {isOpen ? (
          <X className="w-5 h-5" />
        ) : (
          <MessageCircle className="w-5 h-5" />
        )}
      </button>
    </div>
  );
};
