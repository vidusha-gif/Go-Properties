import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, Clock } from 'lucide-react';
import { useRealEstate } from '../context/RealEstateContext';

export const BlogPostPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const { blogPosts } = useRealEstate();

  const post = blogPosts.find(p => p.slug === slug);

  if (!post) {
    return (
      <div className="min-h-screen bg-cool-50 pt-36 pb-20 px-4 text-center">
        <h2 className="font-serif text-2xl font-medium text-cool-900 mb-2">
          Article Not Found
        </h2>
        <Link
          to="/blog"
          className="bg-navy text-white px-5 py-2 text-xs uppercase tracking-wider font-medium rounded-sm inline-block"
        >
          Return to Journal
        </Link>
      </div>
    );
  }

  const relatedPosts = blogPosts.filter(p => p.id !== post.id).slice(0, 2);

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      <article className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Link */}
        <div className="mb-5">
          <Link
            to="/blog"
            className="inline-flex items-center space-x-1 text-xs uppercase tracking-wider font-medium text-cool-500 hover:text-navy transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Journal</span>
          </Link>
        </div>

        {/* Category & Title */}
        <div className="mb-6">
          <span className="text-[10px] uppercase tracking-[0.2em] text-pink-muted font-semibold block mb-2">
            {post.category}
          </span>
          <h1 className="font-serif text-2xl sm:text-4xl font-medium text-cool-900 mb-4 leading-tight">
            {post.title}
          </h1>

          {/* Author & Meta Header */}
          <div className="flex flex-wrap items-center justify-between py-3 border-t border-b border-cool-200 text-xs text-cool-500 gap-3">
            <div className="flex items-center space-x-2.5">
              <img
                src={post.author.avatar}
                alt={post.author.name}
                className="w-8 h-8 rounded-full object-cover border border-cool-200"
              />
              <div>
                <span className="font-medium text-cool-900 block text-xs">{post.author.name}</span>
                <span className="text-[10px] text-cool-400">{post.author.role}</span>
              </div>
            </div>

            <div className="flex items-center space-x-3 text-[11px]">
              <span className="flex items-center space-x-1">
                <Calendar className="w-3 h-3" />
                <span>{post.publishedAt}</span>
              </span>
              <span>•</span>
              <span className="flex items-center space-x-1">
                <Clock className="w-3 h-3" />
                <span>{post.readTime}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Featured Image */}
        <div className="aspect-[16/9] rounded-sm overflow-hidden shadow-sm mb-8 bg-cool-100">
          <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
        </div>

        {/* Article Body Content */}
        <div className="prose prose-stone max-w-none font-light leading-relaxed text-cool-700 text-sm space-y-4">
          <p className="font-serif italic text-lg text-cool-900 leading-relaxed border-l border-pink-muted pl-4 py-0.5">
            {post.excerpt}
          </p>

          <div className="whitespace-pre-line text-xs sm:text-sm leading-relaxed space-y-3">
            {post.content}
          </div>
        </div>

        {/* Tags */}
        {post.tags && post.tags.length > 0 && (
          <div className="mt-10 pt-4 border-t border-cool-200 flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] uppercase tracking-wider text-cool-400 font-medium mr-1.5">
              Tags:
            </span>
            {post.tags.map((tag, i) => (
              <span key={i} className="bg-white border border-cool-200 text-cool-600 text-[11px] px-2.5 py-0.5 rounded-sm">
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* Related Articles */}
        {relatedPosts.length > 0 && (
          <div className="mt-12 pt-8 border-t border-cool-200">
            <h3 className="font-serif text-xl font-medium text-cool-900 mb-4">
              Related Publications
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {relatedPosts.map(rel => (
                <Link
                  key={rel.id}
                  to={`/blog/${rel.slug}`}
                  className="bg-white border border-cool-200/80 p-4 rounded-sm hover:border-navy transition-colors flex space-x-3 items-center group"
                >
                  <img
                    src={rel.image}
                    alt={rel.title}
                    className="w-16 h-16 object-cover rounded-sm flex-shrink-0"
                  />
                  <div>
                    <span className="text-[9px] uppercase font-bold text-cool-400 tracking-wider block">
                      {rel.category}
                    </span>
                    <h4 className="font-serif text-sm font-medium text-cool-900 group-hover:text-navy transition-colors line-clamp-2">
                      {rel.title}
                    </h4>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </article>
    </div>
  );
};
