import { Testimonial } from '../types';

export const INITIAL_TESTIMONIALS: Testimonial[] = [
  {
    id: 't-1',
    name: 'David & Sarah Jenkins',
    country: 'United Kingdom',
    flag: '🇬🇧',
    tour: '10 Days – Complete Sri Lanka Experience',
    rating: 5,
    date: 'October 2025',
    comment: 'Traveling with Serendib Journeys made our dream trip effortless. Our chauffeur-guide was exceptionally knowledgeable, courteous, and introduced us to authentic local food spots we would never have found on our own. The scenic train ride and Yala leopard safari were highlights of our lifetime!'
  },
  {
    id: 't-2',
    name: 'Dr. Rajesh & Priya Sharma',
    country: 'India (Mumbai)',
    flag: '🇮🇳',
    tour: '7 Days – Island Highlights',
    rating: 5,
    date: 'January 2026',
    comment: 'We visited with our elderly parents and young children. The vehicle was immaculately clean, comfortable, and the driving was exceptionally safe. Serendib Journeys tailored every stop so the family never felt rushed. The Temple of the Tooth and Nuwara Eliya tea hills were magnificent.'
  },
  {
    id: 't-3',
    name: 'Maximilian & Clara Weber',
    country: 'Germany (Munich)',
    flag: '🇩🇪',
    tour: '12 Days – Ultimate Sri Lankan Adventure',
    rating: 5,
    date: 'December 2025',
    comment: 'Outstanding organization from the very first inquiry. Sigiriya at dawn was magical, and relaxing in Galle Fort in the evenings was pure luxury. Truly authentic hospitality without any pushy tourist traps. We will definitely recommend Serendib Journeys to our friends in Europe.'
  },
  {
    id: 't-4',
    name: 'Liam & Chloe Taylor',
    country: 'Australia (Sydney)',
    flag: '🇦🇺',
    tour: '5 Days – Cultural & Nature Escape',
    rating: 5,
    date: 'February 2026',
    comment: 'The responsiveness over WhatsApp was world-class. From airport pickup to final drop-off, every detail was handled with precision and warmth. Sigiriya and Ella were breathtaking. Five stars all the way!'
  }
];
