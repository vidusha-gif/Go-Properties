import { GalleryItem } from '../types';

export const INITIAL_GALLERY: GalleryItem[] = [
  { id: 'g-1', category: 'Cultural', title: 'Sigiriya Sky Citadel', location: 'Sigiriya, Cultural Triangle', image: 'https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?auto=format&fit=crop&w=1200&q=85' },
  { id: 'g-2', category: 'Mountains', title: 'Nine Arch Colonial Viaduct', location: 'Ella, Central Highlands', image: 'https://images.unsplash.com/photo-1546708973-b339540b5162?auto=format&fit=crop&w=1200&q=85' },
  { id: 'g-3', category: 'Cultural', title: 'Temple of the Sacred Tooth', location: 'Kandy, Hill Capital', image: 'https://images.unsplash.com/photo-1588598198321-9735fd52455f?auto=format&fit=crop&w=1200&q=85' },
  { id: 'g-4', category: 'Mountains', title: 'Emerald Ceylon Tea Estates', location: 'Nuwara Eliya', image: 'https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=1200&q=85' },
  { id: 'g-5', category: 'Cultural', title: 'Historic Galle Fort Lighthouse', location: 'Galle, Southern Province', image: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=1200&q=85' },
  { id: 'g-6', category: 'Beaches', title: 'Coconut Tree Hill Sunset', location: 'Mirissa, Southern Coast', image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=85' },
  { id: 'g-7', category: 'Wildlife', title: 'Sri Lankan Leopard on Granite Rock', location: 'Yala National Park', image: 'https://images.unsplash.com/photo-1534177616072-ef7dc120449d?auto=format&fit=crop&w=1200&q=85' },
  { id: 'g-8', category: 'Wildlife', title: 'Elephants by the Waterhole', location: 'Udawalawe National Park', image: 'https://images.unsplash.com/photo-1557050543-4d5f4e07ef46?auto=format&fit=crop&w=1200&q=85' },
  { id: 'g-9', category: 'Waterfalls', title: 'Cascading Mountain Rapids', location: 'Ravana Falls, Ella', image: 'https://images.unsplash.com/photo-1432405972618-c60b0225b8f9?auto=format&fit=crop&w=1200&q=85' },
  { id: 'g-10', category: 'Beaches', title: 'Turquoise Waters of Pigeon Island', location: 'Trincomalee, Eastern Coast', image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=85' },
  { id: 'g-11', category: 'Resorts', title: 'Luxury Eco Villa with Infinity Pool', location: 'Southern Coast Sanctuary', image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=85' },
  { id: 'g-12', category: 'Experiences', title: 'Historic Ceylon Tea Plucking', location: 'Dambatenne, Haputale', image: 'https://images.unsplash.com/photo-1531747056595-07f6cbbe10ad?auto=format&fit=crop&w=1200&q=85' }
];
