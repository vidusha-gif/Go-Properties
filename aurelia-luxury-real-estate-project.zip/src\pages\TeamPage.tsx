import React from 'react';
import { Mail, Phone, MessageCircle } from 'lucide-react';
import { useRealEstate } from '../context/RealEstateContext';
import { generateWhatsAppLink } from '../utils/helpers';

export const TeamPage: React.FC = () => {
  const { teamMembers, siteSettings } = useRealEstate();

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1.5">
            Advisory Team
          </span>
          <h1 className="font-serif text-2xl sm:text-4xl font-medium text-cool-900 mb-2">
            Our Senior Brokers & Partners
          </h1>
          <p className="text-cool-500 text-xs font-light leading-relaxed">
            Our partners bring decades of institutional expertise, forensic market knowledge, and unyielding dedication to our private clients.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {teamMembers.map(member => {
            const brokerWhatsApp = generateWhatsAppLink(
              member.phone.replace(/[^0-9]/g, '') || siteSettings.whatsappNumber,
              `Hello ${member.name}, I would like to connect regarding property advisory.`
            );

            return (
              <div
                key={member.id}
                className="bg-white border border-cool-200/80 rounded-sm overflow-hidden shadow-sm hover:shadow-[0_8px_25px_rgba(16,27,51,0.05)] transition-all duration-300 flex flex-col sm:flex-row"
              >
                <div className="sm:w-2/5 aspect-[4/5] sm:aspect-auto overflow-hidden bg-cool-100 flex-shrink-0">
                  <img
                    src={member.photo}
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="p-5 sm:w-3/5 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] uppercase tracking-wider text-pink-muted font-semibold block mb-0.5">
                      {member.role}
                    </span>
                    <h2 className="font-serif text-xl font-medium text-cool-900 mb-2">
                      {member.name}
                    </h2>
                    <p className="text-cool-500 text-xs font-light leading-relaxed mb-3">
                      {member.bio}
                    </p>

                    <div className="border-t border-cool-100 pt-2.5 mb-3 space-y-1 text-xs text-cool-500">
                      <div>
                        <strong className="text-cool-700 font-medium text-[11px]">Specialty:</strong>{' '}
                        <span className="text-[11px]">{member.specialty}</span>
                      </div>
                      <div>
                        <strong className="text-cool-700 font-medium text-[11px]">Languages:</strong>{' '}
                        <span className="text-[11px]">{member.languages.join(', ')}</span>
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-cool-100 pt-3 flex flex-wrap gap-1.5 text-xs">
                    <a
                      href={`mailto:${member.email}`}
                      className="px-2.5 py-1 border border-cool-200 hover:border-navy text-cool-700 rounded-sm flex items-center space-x-1 transition-colors text-[11px]"
                      title="Email Broker"
                    >
                      <Mail className="w-3 h-3 text-cool-400" />
                      <span>Email</span>
                    </a>
                    <a
                      href={`tel:${member.phone.replace(/[^0-9+]/g, '')}`}
                      className="px-2.5 py-1 border border-cool-200 hover:border-navy text-cool-700 rounded-sm flex items-center space-x-1 transition-colors text-[11px]"
                      title="Call Broker"
                    >
                      <Phone className="w-3 h-3 text-cool-400" />
                      <span>{member.phone}</span>
                    </a>
                    <a
                      href={brokerWhatsApp}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1 border border-cool-200 text-cool-700 hover:border-navy rounded-sm flex items-center space-x-1 transition-colors text-[11px]"
                      title="WhatsApp Broker"
                    >
                      <MessageCircle className="w-3 h-3 text-pink-muted" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
