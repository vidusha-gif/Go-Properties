import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Trash2, ArrowRight } from 'lucide-react';
import { useRealEstate } from '../context/RealEstateContext';
import { PropertyCard } from '../components/property/PropertyCard';

export const FavoritesPage: React.FC = () => {
  const { favorites, clearFavorites, properties } = useRealEstate();

  const savedProperties = properties.filter(p => favorites.includes(p.id));

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between border-b border-cool-200/60 pb-4 mb-6 gap-3">
          <div>
            <div className="flex items-center space-x-1.5 text-pink-muted text-[10px] uppercase tracking-[0.25em] font-semibold mb-1">
              <Heart className="w-3.5 h-3.5 fill-current" />
              <span>Saved Portfolio</span>
            </div>
            <h1 className="font-serif text-2xl sm:text-4xl font-medium text-cool-900">
              Saved Residences
            </h1>
          </div>

          {savedProperties.length > 0 && (
            <div className="flex items-center space-x-3">
              <span className="text-xs text-cool-500">
                <strong className="text-cool-900 font-semibold">{savedProperties.length}</strong> saved listings
              </span>
              <button
                onClick={clearFavorites}
                className="flex items-center space-x-1 text-xs font-medium uppercase tracking-wider text-cool-400 hover:text-rose-600 transition-colors"
              >
                <Trash2 className="w-3 h-3" />
                <span>Clear All</span>
              </button>
            </div>
          )}
        </div>

        {savedProperties.length === 0 ? (
          <div className="bg-white border border-cool-200/80 rounded-sm p-12 text-center max-w-md mx-auto shadow-sm">
            <h3 className="font-serif text-xl font-medium text-cool-900 mb-1.5">
              Your Saved Portfolio is Empty
            </h3>
            <p className="text-cool-500 text-xs font-light mb-5 max-w-sm mx-auto">
              Save your preferred residences by clicking the heart icon on any property card to revisit, compare, or arrange viewings at your convenience.
            </p>
            <Link
              to="/properties"
              className="bg-navy hover:bg-navy-midnight text-white px-5 py-2 text-xs uppercase tracking-wider font-medium rounded-sm inline-flex items-center space-x-1.5 transition-colors"
            >
              <span>Explore Collection</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {savedProperties.map(prop => (
              <PropertyCard key={prop.id} property={prop} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
