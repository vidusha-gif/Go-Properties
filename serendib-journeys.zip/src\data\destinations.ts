import { Destination } from '../types';

export const INITIAL_DESTINATIONS: Destination[] = [
  // Cultural Triangle
  {
    id: 'sigiriya',
    name: 'Sigiriya',
    region: 'Cultural Triangle',
    tagline: 'The Legendary 5th-Century Fortress in the Sky',
    image: 'https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?auto=format&fit=crop&w=1200&q=80',
    description: 'Rising dramatically 200 meters above lush emerald plains, Sigiriya is an ancient citadel constructed by King Kashyapa in the 5th century. Adorned with delicate frescoes, a colossal lion gateway, and sophisticated water gardens, it is celebrated worldwide as the 8th Wonder of the World.',
    attractions: ['Lion Rock Citadel summit & palace ruins', 'Ancient fresco paintings of celestial maidens', 'Mirror Wall with 8th-century graffiti', 'Royal Water Gardens & landscaped moats', 'Pidurangala Rock panoramic viewpoint'],
    experiences: ['Dawn climb avoiding heat & crowds', 'Pidurangala sunrise photography', 'Traditional bullock cart & catamaran village tour', 'Wild elephant spotting at neighbouring Minneriya'],
    bestSeason: 'Year-Round (Best: December to April)',
    weatherInfo: 'Warm & tropical (27°C - 33°C). Morning climbs are recommended.'
  },
  {
    id: 'dambulla',
    name: 'Dambulla',
    region: 'Cultural Triangle',
    tagline: 'Sacred Gilded Cave Shrines & Timeless Buddhist Murals',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
    description: 'The largest and best-preserved cave temple complex in Sri Lanka, Dambulla comprises five magnificent sanctuaries carved beneath an immense overhanging granite rock, containing 153 Buddha statues and 2,100 square meters of vivid Buddhist murals.',
    attractions: ['Five sacred rock cave shrines', '14-meter reclining Buddha carved in granite', 'Golden Temple & monumental modern pagoda', 'Cave ceiling murals depicting ancient battles', 'Panoramic views toward Sigiriya Rock'],
    experiences: ['Quiet morning meditative walk', 'Local wholesale tropical vegetable market visit', 'Sunset view over the dry-zone plains'],
    bestSeason: 'December to April',
    weatherInfo: 'Sunny & dry mostly (26°C - 32°C).'
  },
  {
    id: 'polonnaruwa',
    name: 'Polonnaruwa',
    region: 'Cultural Triangle',
    tagline: 'The Medieval Royal Capital of Magnificent Stonework',
    image: 'https://images.unsplash.com/photo-1566836610593-61a3c727b592?auto=format&fit=crop&w=1200&q=80',
    description: 'The second ancient capital of Sri Lanka, Polonnaruwa showcases remarkable 12th-century engineering, vast man-made reservoirs known as the Parakrama Samudra, and the Gal Vihara—masterpieces of rock-cut sculpture depicting the Buddha in four postures.',
    attractions: ['Gal Vihara granite rock sculptures', 'Royal Palace of King Parakramabahu', 'Vatadage circular relic house', 'Rankoth Vehera grand stupa', 'Sea of Parakrama reservoir'],
    experiences: ['Bicycle tour along shady ruins', 'Archaeological museum guided walkthrough', 'Sunset birdwatching by the reservoir'],
    bestSeason: 'November to April',
    weatherInfo: 'Warm tropical sunshine with pleasant evening breezes.'
  },
  {
    id: 'anuradhapura',
    name: 'Anuradhapura',
    region: 'Cultural Triangle',
    tagline: 'Cradle of Sinhalese Civilization & Sacred Monastic Ruins',
    image: 'https://images.unsplash.com/photo-1609137144813-7d9921338f24?auto=format&fit=crop&w=1200&q=80',
    description: 'Dating back to the 4th century BCE, Anuradhapura was the spiritual and political capital for over a millennium. It is home to the sacred Jaya Sri Maha Bodhi—the oldest historically documented tree in the world—and colossal brick stupas that rivaled Egypt\'s Pyramids in scale.',
    attractions: ['Jaya Sri Maha Bodhi Sacred Tree', 'Ruwanweli Seya Great Stupa', 'Jetavanaramaya (once 3rd tallest structure on Earth)', 'Twin Ponds (Kuttam Pokuna)', 'Samadhi Buddha meditative statue'],
    experiences: ['White-clad pilgrim evening procession', 'E-bike tour of the ancient monastic city', 'Heritage meditation with local monks'],
    bestSeason: 'December to April',
    weatherInfo: 'Pleasant mornings, dry and warm afternoons.'
  },

  // Hill Country
  {
    id: 'ella',
    name: 'Ella',
    region: 'Hill Country',
    tagline: 'Mist-Veiled Mountain Gap, Tea Valleys & Iconic Viaducts',
    image: 'https://images.unsplash.com/photo-1546708973-b339540b5162?auto=format&fit=crop&w=1200&q=80',
    description: 'Nestled deep in the central highlands, Ella is a paradise for nature lovers, hikers, and dreamers. Framed by dramatic peaks, cascading waterfalls, and emerald tea bushes, it is famous for the colonial-era Nine Arch Bridge and refreshing cool climate.',
    attractions: ['Nine Arch Bridge colonial viaduct', 'Little Adam’s Peak hiking trail', 'Ella Rock dramatic viewpoint', 'Ravana Falls waterfall & cave', 'Halpewatte Tea Factory'],
    experiences: ['Riding the iconic highland blue train', 'Watching the colonial train cross the Nine Arch Bridge', 'Sip artisan Ceylon tea overlooking the Ella Gap', 'Zip-lining across tea valleys at Flying Ravana'],
    bestSeason: 'January to May (Clear skies & perfect hiking)',
    weatherInfo: 'Crisp, temperate mountain climate (18°C - 24°C).'
  },
  {
    id: 'kandy',
    name: 'Kandy',
    region: 'Hill Country',
    tagline: 'Sacred Hill Capital, Temple of the Tooth & Royal Heritage',
    image: 'https://images.unsplash.com/photo-1588598198321-9735fd52455f?auto=format&fit=crop&w=1200&q=80',
    description: 'Encircled by mountain ranges and tranquil lakes, Kandy was the last royal stronghold before British rule. Today, it remains the spiritual soul of Sri Lanka, sheltering the revered Buddha Tooth Relic inside its grand lakeside palace.',
    attractions: ['Sri Dalada Maligawa (Temple of the Sacred Tooth Relic)', 'Royal Botanical Gardens Peradeniya', 'Kandy Lake & scenic lake drive', 'Bahirawakanda giant Buddha statue', 'Kandy cultural dance theatre'],
    experiences: ['Evening Puja offering ceremony with drumbeats', 'Strolling the Royal Palm avenues of Peradeniya', 'Handmade batik and natural gem workshops', 'Ceylon tea tasting in the hills'],
    bestSeason: 'December to April (and August for Esala Perahera festival)',
    weatherInfo: 'Mild & pleasant (20°C - 28°C).'
  },
  {
    id: 'nuwara-eliya',
    name: 'Nuwara Eliya',
    region: 'Hill Country',
    tagline: 'Little England, Highland Tea Estates & Crisp Mountain Air',
    image: 'https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=1200&q=80',
    description: 'Perched 1,868 meters above sea level beneath Mount Pidurutalagala, Nuwara Eliya retains its charming British colonial character with tudor-style cottages, manicured golf courses, strawberry farms, and world-renowned high-grown Ceylon tea estates.',
    attractions: ['Historic Pedro Tea Estate & factory', 'Gregory Lake & recreational park', 'Victoria Park floral garden', 'The Grand Hotel colonial high tea', 'Horton Plains & World’s End cliff'],
    experiences: ['Colonial Afternoon High Tea with freshly baked scones', 'Tea plucking with local plantation experts', 'Boating on Gregory Lake', 'Trekking through misty Horton Plains'],
    bestSeason: 'February to May (Dry, sunny, and vibrant blooms)',
    weatherInfo: 'Cool highland weather (10°C - 19°C). Warm jackets recommended in evenings.'
  },
  {
    id: 'haputale',
    name: 'Haputale',
    region: 'Hill Country',
    tagline: 'Endless Horizons & Sir Thomas Lipton’s Tea Seat',
    image: 'https://images.unsplash.com/photo-1531747056595-07f6cbbe10ad?auto=format&fit=crop&w=1200&q=80',
    description: 'Perched dramatically along the southern cliff edge of the hill country, Haputale offers breathtaking views that stretch to the southern coast on clear days. It is home to Lipton’s Seat, where tea magnate Sir Thomas Lipton surveyed his vast empire.',
    attractions: ['Lipton’s Seat panoramic viewpoint', 'Dambatenne 19th-century Tea Factory', 'Adisham Benedictine Monastery', 'Bambaragala & Diyaluma Falls nearby'],
    experiences: ['Dawn tuk-tuk ascent to Lipton\'s Seat', 'Walk through century-old tea factory halls', 'Quiet heritage stroll at Adisham bungalow'],
    bestSeason: 'January to April',
    weatherInfo: 'Cool & breezy with picturesque afternoon mists.'
  },

  // Southern Coast
  {
    id: 'galle',
    name: 'Galle',
    region: 'Southern Coast',
    tagline: '17th-Century UNESCO Dutch Fort & Living Ocean Bastions',
    image: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=1200&q=80',
    description: 'Galle Fort is a living UNESCO World Heritage marvel. Built by the Portuguese in 1588 and fortified extensively by the Dutch, its cobblestone streets are lined with chic designer boutiques, colonial mansions, gem ateliers, and ramparts kissed by the turquoise ocean.',
    attractions: ['Galle Fort ramparts & sunset flag rock', 'Galle Lighthouse & white-sand beach', 'Dutch Reformed Church (Groote Kerk)', 'National Maritime Museum', 'Pedlar Street artisan galleries'],
    experiences: ['Sunset cocktail overlooking the ocean ramparts', 'Walking heritage tour with an architectural historian', 'Artisanal cinnamon and culinary masterclass', 'Gem appraisal and jewelry tailoring'],
    bestSeason: 'November to April (Warm sea breeze & clear sunsets)',
    weatherInfo: 'Tropical coastal warmth (26°C - 30°C).'
  },
  {
    id: 'mirissa',
    name: 'Mirissa',
    region: 'Southern Coast',
    tagline: 'Whale Watching Capital & Iconic Coconut Palm Bluff',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80',
    description: 'Famous worldwide for sightings of the colossal Blue Whale and playful acrobatic spinner dolphins, Mirissa also features golden crescent beaches, surf breaks, and the famous Instagram landmark Coconut Tree Hill.',
    attractions: ['Coconut Tree Hill iconic viewpoint', 'Parrot Rock natural ocean outcrop', 'Mirissa Harbour for marine safaris', 'Secret Beach hidden cove'],
    experiences: ['Ethical ocean yacht cruise to view Blue Whales', 'Surfing gentle reef breaks', 'Candlelit fresh seafood dining directly on the beach sand', 'Sunset drone photography at Coconut Tree Hill'],
    bestSeason: 'November to April (Prime whale migration season)',
    weatherInfo: 'Sunny beach weather (27°C - 31°C).'
  },
  {
    id: 'unawatuna',
    name: 'Unawatuna',
    region: 'Southern Coast',
    tagline: 'Calm Turquoise Horseshoe Bay & Coral Reef Lagoons',
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=1200&q=80',
    description: 'A sheltered banana-shaped bay renowned for safe calm swimming, Unawatuna offers vibrant beachside cafes, yoga sanctuaries, and water sports, protected by a tranquil offshore coral reef.',
    attractions: ['Unawatuna Main Beach bay', 'Japanese Peace Pagoda on Rumassala hill', 'Jungle Beach secluded snorkel cove', 'Rumassala sanctuary nature trail'],
    experiences: ['Snorkeling with sea turtles in shallow lagoons', 'Morning beachfront yoga session', 'Sunset hike to the Japanese Peace Pagoda'],
    bestSeason: 'November to April',
    weatherInfo: 'Tropical and balmy (27°C - 31°C).'
  },
  {
    id: 'hiriketiya',
    name: 'Hiriketiya',
    region: 'Southern Coast',
    tagline: 'The Bohemian Horseshoe Cove & Year-Round Surf Haven',
    image: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=1200&q=80',
    description: 'Tucked away on the southern tip, Hiriketiya is a secluded horseshoe-shaped bay where lush jungle slopes meet turquoise water. It is a stylish bohemian hotspot for surfers, digital nomads, and luxury boutique retreat seekers.',
    attractions: ['Horseshoe Bay protected surf break', 'Pehebbiya quiet neighboring beach', 'Blow Hole (Hummanaya) in Kudawella', 'Boutique surf cafes & beach huts'],
    experiences: ['Surf lessons for beginners and intermediates', 'Specialty coffee and sourdough brunch under coconut trees', 'Live acoustic music beach sessions at sunset'],
    bestSeason: 'Year-Round (Best swell: November to April)',
    weatherInfo: 'Tropical warmth, gentle offshore breezes.'
  },

  // Wildlife
  {
    id: 'yala',
    name: 'Yala National Park',
    region: 'Wildlife',
    tagline: 'World’s Highest Leopard Density & Wild Safari Thrills',
    image: 'https://images.unsplash.com/photo-1534177616072-ef7dc120449d?auto=format&fit=crop&w=1200&q=80',
    description: 'Spanning across semi-arid scrub, coastal lagoons, and open plains, Yala is Sri Lanka’s premier national park, home to the world’s densest population of leopards (Panthera pardus kotiya), majestic Asian elephants, sloth bears, and 215 bird species.',
    attractions: ['Yala Block 1 & Block 5 game reserves', 'Manik Ganga riverbanks & giant trees', 'Scenic coastal sand dunes & Indian Ocean borders', 'Patanangala historic rock formation'],
    experiences: ['Dawn private 4x4 game safari with expert tracker', 'Twilight search for elusive sloth bears', 'Luxury glamping in wild eco-lodges with campfire dinners', 'Birdwatching near waterhole lagoons'],
    bestSeason: 'February to June (Animals congregate around waterholes)',
    weatherInfo: 'Dry-zone climate (28°C - 34°C).'
  },
  {
    id: 'udawalawe',
    name: 'Udawalawe',
    region: 'Wildlife',
    tagline: 'Year-Round Elephant Sanctuary & Open African-Style Savannah',
    image: 'https://images.unsplash.com/photo-1557050543-4d5f4e07ef46?auto=format&fit=crop&w=1200&q=80',
    description: 'Often compared to the savannahs of East Africa, Udawalawe revolves around a massive reservoir. It guarantees elephant sightings year-round, with over 500 elephants freely roaming in large family herds alongside wild water buffalo and water birds.',
    attractions: ['Udawalawe Reservoir scenic backdrops', 'Elephant Transit Home rehabilitation center', 'Vast open grasslands & teak forests', 'Bird colonies of eagles, storks & kingfishers'],
    experiences: ['Watching orphaned baby elephants fed milk at Transit Home', 'Sunset 4x4 open safari tracking baby elephant herds', 'Panoramic photography of elephants bathed in golden dusk light'],
    bestSeason: 'Year-Round (Consistent wildlife sightings every month)',
    weatherInfo: 'Warm & sunny (27°C - 33°C).'
  },
  {
    id: 'minneriya',
    name: 'Minneriya',
    region: 'Wildlife',
    tagline: 'The Famous "Great Elephant Gathering" of Asia',
    image: 'https://images.unsplash.com/photo-1564760055775-d63b17a55c44?auto=format&fit=crop&w=1200&q=80',
    description: 'Centered around an ancient reservoir commissioned in the 3rd century, Minneriya hosts "The Gathering"—ranked by Lonely Planet as one of the world\'s 10 greatest wildlife spectacles, where up to 300 Asian elephants congregate on the lush receding lake bed.',
    attractions: ['Minneriya Ancient Tank (Reservoir)', 'Receding grassland plains', 'Gathering of hundreds of wild elephants', 'Flocks of painted storks and cormorants'],
    experiences: ['Witnessing the Great Elephant Gathering (July - October)', '4x4 safari with certified naturalist', 'Combined cultural tour with neighboring Sigiriya'],
    bestSeason: 'July to October (Peak Gathering), Good all year',
    weatherInfo: 'Dry and sunny afternoons.'
  },

  // Eastern Coast
  {
    id: 'trincomalee',
    name: 'Trincomalee',
    region: 'Eastern Coast',
    tagline: 'Natural Deep Harbor, Pigeon Island Corals & Koneswaram Temple',
    image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
    description: 'Boasting one of the finest natural deep-water harbors in the world, Trincomalee features powdery white sands at Nilaveli and Uppuveli, thrilling coral reef snorkeling at Pigeon Island, and the dramatic clifftop Koneswaram Hindu Temple.',
    attractions: ['Koneswaram Temple atop Swami Rock cliff', 'Pigeon Island National Marine Park', 'Nilaveli & Uppuveli white sandy beaches', 'Fort Frederick colonial citadel', 'Kanniya natural hot water springs'],
    experiences: ['Snorkeling with blacktip reef sharks & marine turtles at Pigeon Island', 'Whale watching cruises (May to September)', 'Clifftop views of the Indian Ocean from Lover\'s Leap', 'Relaxing in luxury beachfront private villas'],
    bestSeason: 'May to September (Opposite monsoon: calm glass-like waters & sunshine)',
    weatherInfo: 'Hot and dry beach weather (29°C - 34°C).'
  },
  {
    id: 'arugam-bay',
    name: 'Arugam Bay',
    region: 'Eastern Coast',
    tagline: 'World-Class Point Breaks, Surf Culture & Wildlife Lagoons',
    image: 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&w=1200&q=80',
    description: 'Recognized on the international surf circuit as one of the world\'s top 10 surf points, Arugam Bay combines laid-back surf culture with proximity to wild elephant lagoons and ancient jungle shrines at Kudumbigala.',
    attractions: ['Main Point legendary right-hand reef break', 'Whiskey Point & Peanut Farm surf spots', 'Pottuvil Lagoon eco-mangrove safari', 'Kudumbigala Monastery ancient forest sanctuary'],
    experiences: ['Surfing legendary point breaks', 'Silent canoe lagoon safari spotting elephants & crocodiles', 'Sunset yoga over the Indian Ocean waves', 'Fresh seafood barbecue under starry skies'],
    bestSeason: 'May to September (Prime swell & offshore winds)',
    weatherInfo: 'Sunny, warm, and breezy.'
  },
  {
    id: 'pasikudah',
    name: 'Pasikudah',
    region: 'Eastern Coast',
    tagline: 'Shallow Glass Lagoons & Pristine Luxury Beach Resorts',
    image: 'https://images.unsplash.com/photo-1519046904884-53103b34b206?auto=format&fit=crop&w=1200&q=80',
    description: 'Pasikudah Bay is celebrated for having one of the longest shallow coastline stretches in the world, allowing swimmers to walk hundreds of meters out into crystal-clear turquoise waters that remain waist-deep.',
    attractions: ['Pasikudah shallow reef lagoon', 'Kalkudah pristine untouched beach', 'Luxury 5-star beachfront resorts', 'Marine coral gardens'],
    experiences: ['Safe shallow sea walking and paddleboarding', 'Jet skiing and catamaran sailing', 'Private beachfront candlelit champagne dinners'],
    bestSeason: 'May to September',
    weatherInfo: 'Calm, calm waters, sunny tropical warmth.'
  }
];
