import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Search,
  ArrowRight,
  Shield,
  Key,
  Compass,
  Award,
  ChevronRight,
  ArrowUpRight,
  MessageCircle
} from 'lucide-react';
import { useRealEstate } from '../context/RealEstateContext';
import { PropertyCard } from '../components/property/PropertyCard';
import { formatPrice, generateWhatsAppLink } from '../utils/helpers';

export const HomePage: React.FC = () => {
  const { properties, locations, testimonials, blogPosts, siteSettings } = useRealEstate();
  const navigate = useNavigate();

  // Search State
  const [searchPurpose, setSearchPurpose] = useState<'sale' | 'rent'>('sale');
  const [searchLocation, setSearchLocation] = useState('all');
  const [searchType, setSearchType] = useState('all');
  const [searchPrice, setSearchPrice] = useState('all');
  const [searchBedrooms, setSearchBedrooms] = useState('all');

  // Featured Properties Tab
  const [activeTab, setActiveTab] = useState<'all' | 'sale' | 'rent' | 'luxury' | 'reduced'>('all');

  // Filter properties for the featured section
  const filteredFeatured = properties.filter(p => {
    if (activeTab === 'sale') return p.purpose === 'sale';
    if (activeTab === 'rent') return p.purpose === 'rent';
    if (activeTab === 'luxury') return p.isLuxury;
    if (activeTab === 'reduced') return p.isPriceReduced;
    return p.isFeatured;
  });

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (searchPurpose) params.set('purpose', searchPurpose);
    if (searchLocation !== 'all') params.set('city', searchLocation);
    if (searchType !== 'all') params.set('type', searchType);
    if (searchBedrooms !== 'all') params.set('bedrooms', searchBedrooms);
    if (searchPrice === 'under-5m') params.set('maxPrice', '5000000');
    if (searchPrice === '5m-15m') {
      params.set('minPrice', '5000000');
      params.set('maxPrice', '15000000');
    }
    if (searchPrice === 'over-15m') params.set('minPrice', '15000000');
    navigate(`/properties?${params.toString()}`);
  };

  const categories = [
    {
      title: "Waterfront Villas",
      count: properties.filter(p => p.type === 'villa').length,
      image: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=800&q=80",
      link: "/properties?type=villa"
    },
    {
      title: "Skyline Penthouses",
      count: properties.filter(p => p.type === 'penthouse').length,
      image: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=800&q=80",
      link: "/properties?type=penthouse"
    },
    {
      title: "Modern Apartments",
      count: properties.filter(p => p.type === 'apartment').length,
      image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=800&q=80",
      link: "/properties?type=apartment"
    },
    {
      title: "Historic Townhouses",
      count: properties.filter(p => p.type === 'house').length,
      image: "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=800&q=80",
      link: "/properties?type=house"
    },
    {
      title: "Commercial Assets",
      count: properties.filter(p => p.type === 'commercial').length,
      image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80",
      link: "/properties?type=commercial"
    },
    {
      title: "Development Land",
      count: properties.filter(p => p.type === 'land').length,
      image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=800&q=80",
      link: "/properties?type=land"
    }
  ];

  return (
    <div className="min-h-screen bg-cool-50 text-cool-900">
      {/* 1. HERO SECTION - Cinematic, Modern & Minimal with seamlessly integrated search */}
      <section className="relative min-h-[90vh] flex flex-col justify-center pt-32 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden bg-navy-deep">
        {/* Background Image with Natural Architecture & Deep Navy Gradient */}
        <div className="absolute inset-0 z-0">
          <img
            src={siteSettings.heroImages[0] || "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=2400&q=85"}
            alt="Luxury Architecture"
            className="w-full h-full object-cover object-center"
          />
          {/* Balanced cinematic deep navy/black overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-navy-deep via-navy/60 to-black/50" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-4xl mx-auto text-center text-white my-auto">
          {/* Eyebrow Label - Discreet, refined letter spacing */}
          <div className="inline-flex items-center space-x-2 text-[10px] uppercase tracking-[0.25em] text-pink-muted font-medium mb-3">
            <span className="w-1.5 h-1.5 rounded-full bg-pink-muted"></span>
            <span>Curated International Real Estate</span>
          </div>

          {/* Refined Headline - Not oversized or awkward */}
          <h1 className="font-serif text-3xl sm:text-5xl md:text-6xl font-normal tracking-tight text-white leading-tight">
            Find a Property That Feels Like Home.
          </h1>

          {/* Compact Subheading */}
          <p className="max-w-xl mx-auto text-xs sm:text-sm text-stone-300 font-light leading-relaxed mt-3 mb-8">
            Discover exceptional properties, prime international investments, and bespoke residences designed around how you aspire to live.
          </p>

          {/* REFINED MINIMAL SEARCH INTERFACE (No bulky box, no heavy white rectangle) */}
          <div className="bg-navy/85 backdrop-blur-xl border border-white/10 rounded-sm p-3 sm:p-4 text-left shadow-[0_20px_45px_rgba(0,0,0,0.35)] max-w-3xl mx-auto">
            {/* Small Elegant Tabs for Buy / Rent */}
            <div className="flex items-center space-x-1 mb-3 pb-2.5 border-b border-white/10">
              <button
                type="button"
                onClick={() => setSearchPurpose('sale')}
                className={`px-3.5 py-1 text-[11px] font-medium tracking-wider uppercase rounded-sm transition-all ${
                  searchPurpose === 'sale'
                    ? 'bg-white text-navy font-semibold shadow-sm'
                    : 'text-stone-300 hover:text-white'
                }`}
              >
                Buy
              </button>
              <button
                type="button"
                onClick={() => setSearchPurpose('rent')}
                className={`px-3.5 py-1 text-[11px] font-medium tracking-wider uppercase rounded-sm transition-all ${
                  searchPurpose === 'rent'
                    ? 'bg-white text-navy font-semibold shadow-sm'
                    : 'text-stone-300 hover:text-white'
                }`}
              >
                Rent
              </button>
              <span className="text-[10px] text-stone-400 font-light pl-3 hidden sm:inline">
                Exclusive off-market and private mandates
              </span>
            </div>

            {/* Compact Search Form Fields with subtle separators */}
            <form onSubmit={handleHeroSearch} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2 sm:gap-2.5 items-end">
              {/* Destination */}
              <div>
                <label className="block text-[9.5px] uppercase tracking-wider text-cool-400 font-medium mb-1">
                  Destination
                </label>
                <select
                  value={searchLocation}
                  onChange={(e) => setSearchLocation(e.target.value)}
                  className="w-full bg-white/10 hover:bg-white/15 border border-white/10 py-1.5 px-2.5 text-xs rounded-sm text-white focus:outline-none focus:border-pink-muted transition-colors font-light"
                >
                  <option value="all" className="bg-navy text-white">All Locations</option>
                  {locations.map(loc => (
                    <option key={loc.id} value={loc.name} className="bg-navy text-white">
                      {loc.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Property Type */}
              <div>
                <label className="block text-[9.5px] uppercase tracking-wider text-cool-400 font-medium mb-1">
                  Property Type
                </label>
                <select
                  value={searchType}
                  onChange={(e) => setSearchType(e.target.value)}
                  className="w-full bg-white/10 hover:bg-white/15 border border-white/10 py-1.5 px-2.5 text-xs rounded-sm text-white focus:outline-none focus:border-pink-muted transition-colors font-light"
                >
                  <option value="all" className="bg-navy text-white">All Types</option>
                  <option value="villa" className="bg-navy text-white">Villas</option>
                  <option value="penthouse" className="bg-navy text-white">Penthouses</option>
                  <option value="apartment" className="bg-navy text-white">Apartments</option>
                  <option value="house" className="bg-navy text-white">Townhouses</option>
                  <option value="commercial" className="bg-navy text-white">Commercial</option>
                  <option value="land" className="bg-navy text-white">Land</option>
                </select>
              </div>

              {/* Budget */}
              <div>
                <label className="block text-[9.5px] uppercase tracking-wider text-cool-400 font-medium mb-1">
                  Budget
                </label>
                <select
                  value={searchPrice}
                  onChange={(e) => setSearchPrice(e.target.value)}
                  className="w-full bg-white/10 hover:bg-white/15 border border-white/10 py-1.5 px-2.5 text-xs rounded-sm text-white focus:outline-none focus:border-pink-muted transition-colors font-light"
                >
                  <option value="all" className="bg-navy text-white">Any Price</option>
                  <option value="under-5m" className="bg-navy text-white">Up to $5M</option>
                  <option value="5m-15m" className="bg-navy text-white">$5M – $15M</option>
                  <option value="over-15m" className="bg-navy text-white">$15M+</option>
                </select>
              </div>

              {/* Bedrooms */}
              <div>
                <label className="block text-[9.5px] uppercase tracking-wider text-cool-400 font-medium mb-1">
                  Bedrooms
                </label>
                <select
                  value={searchBedrooms}
                  onChange={(e) => setSearchBedrooms(e.target.value)}
                  className="w-full bg-white/10 hover:bg-white/15 border border-white/10 py-1.5 px-2.5 text-xs rounded-sm text-white focus:outline-none focus:border-pink-muted transition-colors font-light"
                >
                  <option value="all" className="bg-navy text-white">Any Beds</option>
                  <option value="2" className="bg-navy text-white">2+ Beds</option>
                  <option value="3" className="bg-navy text-white">3+ Beds</option>
                  <option value="4" className="bg-navy text-white">4+ Beds</option>
                  <option value="5" className="bg-navy text-white">5+ Beds</option>
                </select>
              </div>

              {/* Refined Search Button */}
              <div>
                <button
                  type="submit"
                  className="w-full bg-white hover:bg-pink-soft text-navy hover:text-black py-1.5 px-4 font-medium text-xs uppercase tracking-wider rounded-sm transition-colors flex items-center justify-center space-x-1.5"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>Search</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* 2. FEATURED PROPERTIES SECTION - Flowing seamlessly from hero with soft white background */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-4 border-b border-cool-200/60">
          <div>
            <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1.5">
              Portfolio
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-medium text-cool-900">
              Featured Properties
            </h2>
          </div>

          {/* Minimal Filter Tabs */}
          <div className="mt-4 md:mt-0 flex flex-wrap gap-1.5">
            {[
              { id: 'all', label: 'All' },
              { id: 'sale', label: 'For Sale' },
              { id: 'rent', label: 'For Rent' },
              { id: 'luxury', label: 'Trophy' },
              { id: 'reduced', label: 'Price Reduced' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-1 text-[11px] font-medium tracking-wider uppercase rounded-sm transition-colors ${
                  activeTab === tab.id
                    ? 'bg-navy text-white font-semibold'
                    : 'text-cool-500 hover:text-navy hover:bg-cool-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Minimal Property Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {filteredFeatured.slice(0, 6).map(prop => (
            <PropertyCard key={prop.id} property={prop} />
          ))}
        </div>

        {/* Refined View All CTA */}
        <div className="text-center">
          <Link
            to="/properties"
            className="inline-flex items-center space-x-1.5 border border-cool-300 hover:border-navy hover:bg-navy hover:text-white text-cool-800 px-6 py-2.5 text-[11px] uppercase tracking-wider font-medium rounded-sm transition-all duration-200"
          >
            <span>View All Properties ({properties.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </section>

      {/* 3. PROPERTY CATEGORIES - Minimal image cards with light hover effects */}
      <section className="py-20 bg-white border-t border-b border-cool-200/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-xl mx-auto mb-14">
            <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1.5">
              Disciplines
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-medium text-cool-900 mb-2.5">
              Explore by Property Type
            </h2>
            <p className="text-cool-500 text-xs font-light leading-relaxed">
              From waterfront architectural masterworks to private island holdings and institutional commercial flagships.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {categories.map((cat, i) => (
              <Link
                key={i}
                to={cat.link}
                className="group relative h-72 rounded-sm overflow-hidden block shadow-sm"
              >
                <img
                  src={cat.image}
                  alt={cat.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-deep/90 via-navy-deep/30 to-transparent group-hover:from-navy-deep/95 transition-colors" />

                <div className="absolute inset-0 p-5 flex flex-col justify-end text-white">
                  <span className="text-[10px] uppercase tracking-wider text-pink-muted font-medium mb-1">
                    {cat.count} Available
                  </span>
                  <h3 className="font-serif text-xl font-medium text-white group-hover:text-pink-soft transition-colors">
                    {cat.title}
                  </h3>
                  <div className="mt-2 flex items-center space-x-1 text-[11px] text-stone-300 font-light group-hover:text-white transition-colors">
                    <span>Browse Collection</span>
                    <ArrowRight className="w-3 h-3 transform group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* 4. EXPLORE BY LOCATION - Prime Destinations */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-4 border-b border-cool-200/60">
          <div>
            <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1.5">
              Destinations
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-medium text-cool-900">
              Prime Operating Markets
            </h2>
          </div>
          <Link
            to="/locations"
            className="mt-3 md:mt-0 text-[11px] font-medium uppercase tracking-wider text-navy hover:text-black flex items-center space-x-1"
          >
            <span>All Destinations</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {locations.map(loc => {
            const count = properties.filter(p => p.location.city.toLowerCase() === loc.name.toLowerCase()).length;
            return (
              <Link
                key={loc.id}
                to={`/properties?city=${loc.name}`}
                className="group relative h-80 rounded-sm overflow-hidden shadow-sm"
              >
                <img
                  src={loc.image}
                  alt={loc.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-deep via-navy-deep/30 to-transparent" />

                <div className="absolute inset-0 p-5 flex flex-col justify-between text-white">
                  <div className="flex justify-between items-start">
                    <span className="bg-black/40 backdrop-blur-md px-2.5 py-0.5 rounded-sm text-[10px] font-medium uppercase tracking-wider text-stone-200">
                      {loc.country}
                    </span>
                    <span className="w-7 h-7 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center group-hover:bg-pink-muted group-hover:text-navy transition-colors">
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </span>
                  </div>

                  <div>
                    <h3 className="font-serif text-2xl font-medium mb-1 text-white group-hover:text-pink-soft transition-colors">
                      {loc.name}
                    </h3>
                    <p className="text-[11px] text-stone-300 font-light line-clamp-2 mb-2">
                      {loc.description}
                    </p>
                    <span className="text-[11px] font-medium text-pink-muted">
                      {count} Available Residences
                    </span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* 5. WHY CHOOSE OUR COMPANY - Deep Navy Section with Minimal Hairline Cards */}
      <section className="py-20 bg-navy text-white relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-xl mx-auto mb-14">
            <span className="text-[10px] uppercase tracking-[0.25em] text-pink-muted font-semibold block mb-1.5">
              Representation
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-medium text-white mb-2.5">
              Why Discerning Clients Entrust Aurelia
            </h2>
            <p className="text-cool-400 text-xs font-light leading-relaxed">
              We operate not as high-volume transactional brokers, but as trusted fiduciaries curating long-term property wealth.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            <div className="border border-white/10 bg-white/[0.03] p-6 rounded-sm hover:border-pink-muted/40 transition-colors">
              <div className="w-9 h-9 rounded-sm border border-white/20 flex items-center justify-center text-pink-muted mb-4">
                <Key className="w-4 h-4" />
              </div>
              <h3 className="font-serif text-lg font-medium mb-2 text-white">
                Off-Market Access
              </h3>
              <p className="text-cool-400 text-xs leading-relaxed font-light">
                Direct access to confidential estates and private mandates never circulated on public portals, protected under strict NDAs.
              </p>
            </div>

            <div className="border border-white/10 bg-white/[0.03] p-6 rounded-sm hover:border-pink-muted/40 transition-colors">
              <div className="w-9 h-9 rounded-sm border border-white/20 flex items-center justify-center text-pink-muted mb-4">
                <Shield className="w-4 h-4" />
              </div>
              <h3 className="font-serif text-lg font-medium mb-2 text-white">
                Forensic Due Diligence
              </h3>
              <p className="text-cool-400 text-xs leading-relaxed font-light">
                Rigorous structural, legal, and planning inspections coordinated with premier international legal counsels before committing capital.
              </p>
            </div>

            <div className="border border-white/10 bg-white/[0.03] p-6 rounded-sm hover:border-pink-muted/40 transition-colors">
              <div className="w-9 h-9 rounded-sm border border-white/20 flex items-center justify-center text-pink-muted mb-4">
                <Compass className="w-4 h-4" />
              </div>
              <h3 className="font-serif text-lg font-medium mb-2 text-white">
                Cross-Border Structuring
              </h3>
              <p className="text-cool-400 text-xs leading-relaxed font-light">
                Strategic alignment between London freehold, Dubai Golden Visa frameworks, and French Riviera SCI structures.
              </p>
            </div>

            <div className="border border-white/10 bg-white/[0.03] p-6 rounded-sm hover:border-pink-muted/40 transition-colors">
              <div className="w-9 h-9 rounded-sm border border-white/20 flex items-center justify-center text-pink-muted mb-4">
                <Award className="w-4 h-4" />
              </div>
              <h3 className="font-serif text-lg font-medium mb-2 text-white">
                End-to-End Concierge
              </h3>
              <p className="text-cool-400 text-xs leading-relaxed font-light">
                From private aviation viewing itineraries and yacht mooring logistics to post-completion architectural management.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. SELL OR LIST YOUR PROPERTY - High-converting Owner Section */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-navy text-white rounded-sm p-8 sm:p-12 lg:p-14 relative overflow-hidden border border-white/5">
          <div className="max-w-2xl relative z-10">
            <span className="text-[10px] uppercase tracking-[0.25em] text-pink-muted font-semibold block mb-2">
              Seller & Landlord Advisory
            </span>
            <h2 className="font-serif text-2xl sm:text-4xl font-medium mb-4 leading-tight">
              Thinking of Selling or Renting Your Property?
            </h2>
            <p className="text-cool-300 text-xs sm:text-sm font-light leading-relaxed mb-6">
              Connect with our team to discover how we can help you market your property and reach the right qualified buyers or tenants across premier international capitals.
            </p>

            <div className="flex flex-wrap gap-3">
              <Link
                to="/sell"
                className="bg-white hover:bg-pink-soft text-navy px-5 py-2.5 text-xs uppercase tracking-wider font-semibold rounded-sm transition-colors flex items-center space-x-1.5"
              >
                <span>List My Property</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
              <Link
                to="/sell#valuation"
                className="border border-white/25 hover:border-white text-white px-5 py-2.5 text-xs uppercase tracking-wider font-medium rounded-sm transition-colors"
              >
                <span>Request a Valuation</span>
              </Link>
              <Link
                to="/contact"
                className="text-cool-400 hover:text-white px-3 py-2.5 text-xs uppercase tracking-wider font-medium transition-colors flex items-center space-x-1"
              >
                <span>Talk to Our Team</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 7. EDITORIAL & LIFESTYLE SECTION - Clean Split Layout */}
      <section className="py-20 bg-white border-t border-b border-cool-200/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-6">
              <div className="aspect-[4/3] rounded-sm overflow-hidden shadow-sm">
                <img
                  src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80"
                  alt="Architectural Masterwork"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div className="lg:col-span-6 space-y-4">
              <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block">
                The Architecture of Living
              </span>
              <h2 className="font-serif text-2xl sm:text-3xl font-medium text-cool-900 leading-tight">
                Where Contemporary Design Meets Natural Topography
              </h2>
              <p className="text-cool-600 text-xs sm:text-sm leading-relaxed font-light">
                True luxury is defined not by ornamentation, but by the thoughtful harmonization of volumetric space, daylight, and acoustic serenity. Our portfolio highlights residences that marry structural daring with absolute privacy.
              </p>
              <div className="border-l border-pink-muted pl-4 py-1">
                <p className="italic text-cool-700 font-serif text-base">
                  "A home is not merely an investment asset; it is the physical framework of your family's future memories."
                </p>
                <span className="text-[10px] uppercase tracking-wider text-cool-400 font-medium mt-1.5 block">
                  — Julian St. Claire, Founding Principal
                </span>
              </div>
              <div className="pt-2">
                <Link
                  to="/about"
                  className="inline-flex items-center space-x-1.5 text-xs font-medium uppercase tracking-wider text-navy hover:text-black transition-colors"
                >
                  <span>Explore Our Architectural Philosophy</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 8. AUTHENTIC CLIENT TESTIMONIALS - Lightweight Cards */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-xl mx-auto mb-14">
          <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1.5">
            Testimonials
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-medium text-cool-900 mb-2">
            Private Client Experiences
          </h2>
          <p className="text-cool-500 text-xs font-light">
            Reflections from clients who have partnered with our advisory across acquisitions, sales, and off-market mandates.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map(item => (
            <div
              key={item.id}
              className="bg-white border border-cool-200/70 p-6 rounded-sm shadow-sm flex flex-col justify-between"
            >
              <div>
                <div className="flex text-pink-muted mb-3 text-sm">
                  {[...Array(item.rating)].map((_, i) => (
                    <span key={i}>★</span>
                  ))}
                </div>
                <p className="font-serif italic text-cool-800 text-base leading-relaxed mb-5">
                  "{item.quote}"
                </p>
              </div>

              <div className="border-t border-cool-100 pt-3.5">
                <span className="font-medium text-xs text-cool-900 block">
                  {item.clientName}
                </span>
                <span className="text-[11px] text-cool-400 block">
                  {item.clientTitle} • {item.location}
                </span>
                <span className="text-[10px] text-navy mt-0.5 block font-medium">
                  {item.propertyType}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 9. LATEST PROPERTY NEWS & GUIDES */}
      <section className="py-20 bg-white border-t border-cool-200/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-4 border-b border-cool-200/60">
            <div>
              <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1.5">
                Editorial
              </span>
              <h2 className="font-serif text-2xl sm:text-3xl font-medium text-cool-900">
                Latest Insights & Guides
              </h2>
            </div>
            <Link
              to="/blog"
              className="mt-3 md:mt-0 text-[11px] font-medium uppercase tracking-wider text-navy hover:text-black flex items-center space-x-1"
            >
              <span>View All Articles</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {blogPosts.slice(0, 3).map(post => (
              <article
                key={post.id}
                className="bg-cool-50 border border-cool-200/60 rounded-sm overflow-hidden shadow-sm hover:shadow-[0_8px_25px_rgba(16,27,51,0.05)] transition-all group flex flex-col"
              >
                <div className="aspect-[16/10] overflow-hidden bg-cool-100">
                  <Link to={`/blog/${post.slug}`}>
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </Link>
                </div>

                <div className="p-5 flex-grow flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between text-[10px] text-cool-400 uppercase tracking-wider mb-1.5 font-medium">
                      <span className="text-navy">{post.category}</span>
                      <span>{post.readTime}</span>
                    </div>

                    <Link to={`/blog/${post.slug}`}>
                      <h3 className="font-serif text-lg font-medium text-cool-900 group-hover:text-navy transition-colors mb-2 line-clamp-2">
                        {post.title}
                      </h3>
                    </Link>

                    <p className="text-[11px] text-cool-500 font-light line-clamp-2 leading-relaxed mb-4">
                      {post.excerpt}
                    </p>
                  </div>

                  <div className="border-t border-cool-200/60 pt-3 flex items-center justify-between text-xs text-cool-500">
                    <span className="text-[11px] font-medium text-cool-700">{post.author.name}</span>
                    <Link
                      to={`/blog/${post.slug}`}
                      className="text-navy hover:text-black font-medium text-[11px] flex items-center space-x-1"
                    >
                      <span>Read Guide</span>
                      <ArrowRight className="w-3 h-3" />
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* 10. CONTACT OFFICE BANNER - Minimal Hairline Columns */}
      <section className="py-16 bg-cool-50 border-t border-cool-200/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center md:text-left">
            <div className="p-4 border-r border-cool-200/60 last:border-none">
              <span className="text-[10px] uppercase tracking-wider text-cool-400 font-semibold block mb-1">
                Private Head Office
              </span>
              <p className="font-serif text-lg font-medium text-cool-900 mb-0.5">
                Mayfair, London W1J 5AT
              </p>
              <p className="text-[11px] text-cool-500 font-light">
                48 Berkeley Square • Visits by private appointment
              </p>
            </div>

            <div className="p-4 border-r border-cool-200/60 last:border-none">
              <span className="text-[10px] uppercase tracking-wider text-cool-400 font-semibold block mb-1">
                Direct Telephony
              </span>
              <p className="font-serif text-lg font-medium text-cool-900 mb-0.5">
                {siteSettings.phone}
              </p>
              <p className="text-[11px] text-cool-500 font-light">
                Active 6 days a week • 08:30 – 19:30 GMT
              </p>
            </div>

            <div className="p-4">
              <span className="text-[10px] uppercase tracking-wider text-cool-400 font-semibold block mb-1">
                Direct Digital Desks
              </span>
              <p className="font-serif text-lg font-medium text-cool-900 mb-0.5">
                {siteSettings.email}
              </p>
              <p className="text-[11px] text-cool-500 font-light">
                WhatsApp Concierge Active
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
