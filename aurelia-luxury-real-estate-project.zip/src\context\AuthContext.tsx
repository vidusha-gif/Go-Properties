import React, { createContext, useContext, useState, useEffect } from 'react';

interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: 'superadmin' | 'broker' | 'editor';
}

interface AuthContextType {
  user: AuthUser | null;
  isAuthenticated: boolean;
  login: (email: string, pass: string) => Promise<{ success: boolean; message?: string }>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_STORAGE_KEY = 'aurelia_auth_session';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(() => {
    try {
      const stored = localStorage.getItem(ADMIN_STORAGE_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  const login = async (email: string, pass: string): Promise<{ success: boolean; message?: string }> => {
    // Standard mock admin credentials for evaluation
    if (
      (email.trim().toLowerCase() === 'admin@aurelia.com' && pass === 'aurelia2027') ||
      (email.trim().toLowerCase() === 'admin' && pass === 'admin')
    ) {
      const authUser: AuthUser = {
        id: 'adm-01',
        name: 'Julian St. Claire (Executive Principal)',
        email: 'admin@aurelia.com',
        role: 'superadmin'
      };
      setUser(authUser);
      localStorage.setItem(ADMIN_STORAGE_KEY, JSON.stringify(authUser));
      return { success: true };
    }
    return { success: false, message: 'Invalid administrative credentials. Use admin@aurelia.com / aurelia2027' };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem(ADMIN_STORAGE_KEY);
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};
