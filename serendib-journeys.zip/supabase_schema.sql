-- =========================================================================
-- SERENDIB JOURNEYS – OFFICIAL SUPABASE DATABASE & STORAGE SCHEMA
-- Production-Ready PostgreSQL Schema with Row Level Security (RLS)
-- =========================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- -------------------------------------------------------------------------
-- 1. PROFILES & ROLES (Admin Authentication & Authorization)
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    full_name TEXT,
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.admin_roles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('super_admin', 'editor', 'concierge')),
    granted_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, role)
);

-- Function to check if authenticated user is admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.admin_roles 
        WHERE user_id = auth.uid() AND role IN ('super_admin', 'editor')
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- -------------------------------------------------------------------------
-- 2. WEBSITE SETTINGS & OFFICIAL CONTACT DETAILS
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.website_settings (
    id TEXT PRIMARY KEY DEFAULT 'primary',
    company_name TEXT NOT NULL DEFAULT 'SERENDIB JOURNEYS',
    whatsapp_number TEXT NOT NULL DEFAULT '+94 70 232 4216',
    whatsapp_display TEXT NOT NULL DEFAULT '+94 70 232 4216',
    email TEXT NOT NULL DEFAULT 'a.journeys.serendib@gmail.com',
    phone TEXT NOT NULL DEFAULT '+94 70 232 4216',
    address TEXT NOT NULL DEFAULT 'No. 45/2, Galle Road, Colombo 03, Sri Lanka',
    business_hours TEXT NOT NULL DEFAULT '24/7 Dedicated International Concierge',
    hero_heading TEXT DEFAULT 'Discover the Magic of Sri Lanka',
    hero_subheading TEXT DEFAULT 'From golden beaches and misty mountains to ancient kingdoms and unforgettable wildlife encounters, explore Sri Lanka with journeys designed around you.',
    slogan TEXT DEFAULT 'Discover Sri Lanka. Experience the Extraordinary.',
    tagline TEXT DEFAULT 'Your Journey, Our Passion.',
    currency_default TEXT DEFAULT 'USD',
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- -------------------------------------------------------------------------
-- 3. DESTINATIONS & DESTINATION IMAGES
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.destinations (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    region TEXT NOT NULL,
    tagline TEXT,
    description TEXT NOT NULL,
    best_season TEXT,
    weather_info TEXT,
    attractions JSONB DEFAULT '[]'::jsonb,
    experiences JSONB DEFAULT '[]'::jsonb,
    display_order INT DEFAULT 0,
    is_published BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.destination_images (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    destination_id TEXT NOT NULL REFERENCES public.destinations(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    alt_text TEXT NOT NULL,
    url TEXT NOT NULL,
    is_cover BOOLEAN DEFAULT false,
    display_order INT DEFAULT 0,
    object_position TEXT DEFAULT 'center center',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -------------------------------------------------------------------------
-- 4. OFFICIAL VEHICLE FLEET & VEHICLE IMAGES
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.vehicles (
    id TEXT PRIMARY KEY,
    models TEXT NOT NULL,
    category TEXT NOT NULL,
    capacity TEXT NOT NULL,
    luggage TEXT NOT NULL,
    ac TEXT NOT NULL,
    transmission TEXT NOT NULL,
    driver_tier TEXT NOT NULL,
    features JSONB DEFAULT '[]'::jsonb,
    best_for TEXT,
    daily_rate_usd NUMERIC(10,2) DEFAULT 0,
    is_available BOOLEAN DEFAULT true,
    display_order INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.vehicle_images (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vehicle_id TEXT NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    url TEXT NOT NULL,
    image_type TEXT DEFAULT 'exterior' CHECK (image_type IN ('exterior', 'interior', 'dashboard', 'feature')),
    is_cover BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -------------------------------------------------------------------------
-- 5. TOUR PACKAGES & ITINERARIES
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.tour_packages (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    subtitle TEXT,
    duration TEXT NOT NULL,
    days INT NOT NULL,
    base_price_usd NUMERIC(10,2) NOT NULL,
    category TEXT NOT NULL,
    featured BOOLEAN DEFAULT false,
    image_key TEXT,
    highlights JSONB DEFAULT '[]'::jsonb,
    places_visited JSONB DEFAULT '[]'::jsonb,
    inclusions JSONB DEFAULT '[]'::jsonb,
    exclusions JSONB DEFAULT '[]'::jsonb,
    itinerary JSONB DEFAULT '[]'::jsonb,
    is_published BOOLEAN DEFAULT true,
    display_order INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- -------------------------------------------------------------------------
-- 6. GALLERY IMAGES & TESTIMONIALS
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.gallery_images (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    location TEXT NOT NULL,
    category TEXT NOT NULL,
    url TEXT NOT NULL,
    display_order INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.testimonials (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    country TEXT NOT NULL,
    flag TEXT NOT NULL,
    rating INT DEFAULT 5 CHECK (rating >= 1 AND rating <= 5),
    comment TEXT NOT NULL,
    tour TEXT,
    is_approved BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -------------------------------------------------------------------------
-- 7. CUSTOMER INQUIRIES & BOOKING LEADS
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.customer_inquiries (
    id TEXT PRIMARY KEY DEFAULT ('SJ-' || TO_CHAR(NOW(), 'YYMM') || '-' || LPAD(FLOOR(RANDOM()*10000)::TEXT, 4, '0')),
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    country TEXT,
    travel_date DATE,
    travelers TEXT,
    package_interested TEXT,
    vehicle_requested TEXT,
    budget_tier TEXT,
    special_requests TEXT,
    status TEXT DEFAULT 'New' CHECK (status IN ('New', 'Contacted', 'Quoted', 'Confirmed', 'Cancelled')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- -------------------------------------------------------------------------
-- 8. ROW LEVEL SECURITY (RLS) POLICIES
-- -------------------------------------------------------------------------
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.website_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.destination_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicle_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tour_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gallery_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.testimonials ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_inquiries ENABLE ROW LEVEL SECURITY;

-- PUBLIC READ POLICIES (Anyone can view published tourism content)
CREATE POLICY "Public can view website settings" ON public.website_settings FOR SELECT USING (true);
CREATE POLICY "Public can view published destinations" ON public.destinations FOR SELECT USING (is_published = true);
CREATE POLICY "Public can view destination images" ON public.destination_images FOR SELECT USING (true);
CREATE POLICY "Public can view vehicles" ON public.vehicles FOR SELECT USING (is_available = true);
CREATE POLICY "Public can view vehicle images" ON public.vehicle_images FOR SELECT USING (true);
CREATE POLICY "Public can view published packages" ON public.tour_packages FOR SELECT USING (is_published = true);
CREATE POLICY "Public can view gallery" ON public.gallery_images FOR SELECT USING (true);
CREATE POLICY "Public can view approved testimonials" ON public.testimonials FOR SELECT USING (is_approved = true);

-- PUBLIC WRITE POLICIES (Tourists can submit inquiries)
CREATE POLICY "Public can submit inquiries" ON public.customer_inquiries FOR INSERT WITH CHECK (true);

-- ADMIN FULL ACCESS POLICIES (Only authorized admins can modify website content)
CREATE POLICY "Admins full access website_settings" ON public.website_settings FOR ALL USING (public.is_admin());
CREATE POLICY "Admins full access destinations" ON public.destinations FOR ALL USING (public.is_admin());
CREATE POLICY "Admins full access destination_images" ON public.destination_images FOR ALL USING (public.is_admin());
CREATE POLICY "Admins full access vehicles" ON public.vehicles FOR ALL USING (public.is_admin());
CREATE POLICY "Admins full access vehicle_images" ON public.vehicle_images FOR ALL USING (public.is_admin());
CREATE POLICY "Admins full access tour_packages" ON public.tour_packages FOR ALL USING (public.is_admin());
CREATE POLICY "Admins full access gallery_images" ON public.gallery_images FOR ALL USING (public.is_admin());
CREATE POLICY "Admins full access testimonials" ON public.testimonials FOR ALL USING (public.is_admin());
CREATE POLICY "Admins full access customer_inquiries" ON public.customer_inquiries FOR ALL USING (public.is_admin());

-- -------------------------------------------------------------------------
-- 9. SUPABASE STORAGE BUCKET & POLICIES
-- -------------------------------------------------------------------------
INSERT INTO storage.buckets (id, name, public) 
VALUES ('serendib-journeys-images', 'serendib-journeys-images', true)
ON CONFLICT (id) DO NOTHING;

-- Public can view images in storage
CREATE POLICY "Public Access Serendib Images"
ON storage.objects FOR SELECT
USING (bucket_id = 'serendib-journeys-images');

-- Only admins can upload, update, and delete images in storage
CREATE POLICY "Admins Upload Serendib Images"
ON storage.objects FOR INSERT
WITH CHECK (
    bucket_id = 'serendib-journeys-images' AND 
    (public.is_admin() OR auth.role() = 'service_role')
);

CREATE POLICY "Admins Delete Serendib Images"
ON storage.objects FOR DELETE
USING (
    bucket_id = 'serendib-journeys-images' AND 
    (public.is_admin() OR auth.role() = 'service_role')
);

-- =========================================================================
-- END OF SCHEMA
-- =========================================================================
