import React from 'react';
import { useRealEstate } from '../context/RealEstateContext';

export const TermsPage: React.FC = () => {
  const { siteSettings } = useRealEstate();

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 bg-white border border-cool-200/80 rounded-sm p-6 sm:p-10 shadow-sm">
        <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1">
          Legal Framework
        </span>
        <h1 className="font-serif text-2xl sm:text-4xl font-medium text-cool-900 mb-4">
          Terms & Conditions of Service
        </h1>
        <p className="text-xs text-cool-400 mb-6 pb-3 border-b border-cool-100">
          Applicable across all global portals, private client representations, and digital viewings
        </p>

        <div className="text-xs sm:text-sm text-cool-600 font-light leading-relaxed space-y-5">
          <section>
            <h2 className="font-serif text-base sm:text-lg font-medium text-cool-900 mb-1.5">1. Scope of Presentation</h2>
            <p>
              The property particulars, photography, virtual tours, and floor plans exhibited on this platform are curated in good faith for illustrative guidance. They do not constitute an unalterable contract of sale or formal warranty. Prospective purchasers must satisfy themselves through independent legal and architectural surveys.
            </p>
          </section>

          <section>
            <h2 className="font-serif text-base sm:text-lg font-medium text-cool-900 mb-1.5">2. Confidential Off-Market Mandates</h2>
            <p>
              Information marked as "Confidential" or "Private Mandate" is disclosed solely to authorized recipients under enforceable Non-Disclosure Agreements (NDAs). Unauthorized recirculation or public reproduction is strictly prohibited under international copyright and commercial confidentiality statutes.
            </p>
          </section>

          <section>
            <h2 className="font-serif text-base sm:text-lg font-medium text-cool-900 mb-1.5">3. Anti-Money Laundering (AML) Compliance</h2>
            <p>
              In compliance with international financial regulations, {siteSettings.companyName} requires verified proof of identity and source of funds verification before completing binding purchase contracts or executing formal escrow releases.
            </p>
          </section>

          <section>
            <h2 className="font-serif text-base sm:text-lg font-medium text-cool-900 mb-1.5">4. Applicable Jurisdiction</h2>
            <p>
              These terms are governed by English law and subject to the exclusive jurisdiction of the English courts, alongside supplemental local laws governing property conveyancing in the specific territory of the asset.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};
