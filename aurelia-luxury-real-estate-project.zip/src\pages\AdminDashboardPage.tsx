import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Building2,
  Users,
  Inbox,
  Settings,
  Plus,
  Trash2,
  Edit,
  Eye,
  LogOut,
  Download,
  Star,
  Search,
  FileText,
  Check,
  X,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useRealEstate } from '../context/RealEstateContext';
import { Property, PropertyType, PropertyPurpose, PropertyStatus, LeadStatus } from '../types';
import { formatPrice } from '../utils/helpers';

export const AdminDashboardPage: React.FC = () => {
  const { user, logout, isAuthenticated } = useAuth();
  const {
    properties,
    addProperty,
    updateProperty,
    deleteProperty,
    toggleFeatured,
    updatePropertyStatus,
    leads,
    updateLeadStatus,
    addLeadNote,
    deleteLead,
    submissions,
    updateSubmissionStatus,
    siteSettings,
    updateSiteSettings,
    blogPosts,
    deleteBlogPost,
    testimonials,
    deleteTestimonial
  } = useRealEstate();

  const navigate = useNavigate();

  React.useEffect(() => {
    if (!isAuthenticated) {
      navigate('/admin/login');
    }
  }, [isAuthenticated, navigate]);

  const [activeTab, setActiveTab] = useState<'properties' | 'leads' | 'submissions' | 'content' | 'settings'>('properties');
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 4000);
  };

  // PROPERTIES TAB STATE & ACTIONS
  const [propSearch, setPropSearch] = useState('');
  const [propModalOpen, setPropModalOpen] = useState(false);
  const [editingPropertyId, setEditingPropertyId] = useState<string | null>(null);

  const [propForm, setPropForm] = useState({
    referenceId: 'AUE-' + Math.floor(1000 + Math.random() * 9000),
    title: '',
    tagline: '',
    description: '',
    purpose: 'sale' as PropertyPurpose,
    type: 'villa' as PropertyType,
    status: 'available' as PropertyStatus,
    price: 10000000,
    pricePrefix: 'Guide Price',
    rentalPeriod: undefined as any,
    currency: '$',
    isFeatured: true,
    isLuxury: true,
    isPriceReduced: false,
    bedrooms: 5,
    bathrooms: 6,
    parkingSpaces: 4,
    floorAreaSqFt: 6500,
    landAreaSqFt: 18000,
    yearBuilt: 2024,
    furnishedStatus: 'furnished' as any,
    featuredImage: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1800&q=85',
    galleryImagesText: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1800&q=85\nhttps://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1800&q=85',
    amenitiesText: 'Infinity Swimming Pool, Private Spa & Sauna, Wine Cellar, Private Cinema, 24-Hour Concierge',
    city: 'Dubai',
    area: 'Palm Jumeirah',
    address: 'Frond G, Palm Jumeirah',
    country: 'United Arab Emirates',
    lat: 25.1180,
    lng: 55.1320
  });

  const openNewPropertyModal = () => {
    setEditingPropertyId(null);
    setPropForm({
      referenceId: 'AUE-' + Math.floor(1000 + Math.random() * 9000),
      title: '',
      tagline: '',
      description: '',
      purpose: 'sale',
      type: 'villa',
      status: 'available',
      price: 8500000,
      pricePrefix: 'Guide Price',
      rentalPeriod: undefined,
      currency: '$',
      isFeatured: true,
      isLuxury: true,
      isPriceReduced: false,
      bedrooms: 4,
      bathrooms: 5,
      parkingSpaces: 3,
      floorAreaSqFt: 5500,
      landAreaSqFt: 15000,
      yearBuilt: 2024,
      furnishedStatus: 'furnished',
      featuredImage: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1800&q=85',
      galleryImagesText: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1800&q=85',
      amenitiesText: 'Swimming Pool, Private Spa, Wine Cellar, Smart Home',
      city: 'London',
      area: 'Mayfair',
      address: '24 Curzon Street',
      country: 'United Kingdom',
      lat: 51.5074,
      lng: -0.1478
    });
    setPropModalOpen(true);
  };

  const openEditPropertyModal = (p: Property) => {
    setEditingPropertyId(p.id);
    setPropForm({
      referenceId: p.referenceId,
      title: p.title,
      tagline: p.tagline || '',
      description: p.description,
      purpose: p.purpose,
      type: p.type,
      status: p.status,
      price: p.price,
      pricePrefix: p.pricePrefix || 'Guide Price',
      rentalPeriod: p.rentalPeriod,
      currency: p.currency,
      isFeatured: p.isFeatured,
      isLuxury: p.isLuxury,
      isPriceReduced: p.isPriceReduced || false,
      bedrooms: p.bedrooms,
      bathrooms: p.bathrooms,
      parkingSpaces: p.parkingSpaces,
      floorAreaSqFt: p.floorAreaSqFt,
      landAreaSqFt: p.landAreaSqFt || 0,
      yearBuilt: p.yearBuilt || 2024,
      furnishedStatus: p.furnishedStatus,
      featuredImage: p.featuredImage,
      galleryImagesText: p.galleryImages.join('\n'),
      amenitiesText: p.amenities.join(', '),
      city: p.location.city,
      area: p.location.area,
      address: p.location.address,
      country: p.location.country,
      lat: p.location.lat,
      lng: p.location.lng
    });
    setPropModalOpen(true);
  };

  const handleSaveProperty = (e: React.FormEvent) => {
    e.preventDefault();
    const galleryImages = propForm.galleryImagesText
      .split('\n')
      .map(s => s.trim())
      .filter(Boolean);

    const amenities = propForm.amenitiesText
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);

    if (editingPropertyId) {
      updateProperty(editingPropertyId, {
        referenceId: propForm.referenceId,
        title: propForm.title,
        tagline: propForm.tagline,
        description: propForm.description,
        purpose: propForm.purpose,
        type: propForm.type,
        status: propForm.status,
        price: Number(propForm.price),
        pricePrefix: propForm.pricePrefix,
        rentalPeriod: propForm.purpose === 'rent' ? 'month' : undefined,
        isFeatured: propForm.isFeatured,
        isLuxury: propForm.isLuxury,
        isPriceReduced: propForm.isPriceReduced,
        bedrooms: Number(propForm.bedrooms),
        bathrooms: Number(propForm.bathrooms),
        parkingSpaces: Number(propForm.parkingSpaces),
        floorAreaSqFt: Number(propForm.floorAreaSqFt),
        landAreaSqFt: Number(propForm.landAreaSqFt) || undefined,
        yearBuilt: Number(propForm.yearBuilt) || undefined,
        furnishedStatus: propForm.furnishedStatus,
        featuredImage: propForm.featuredImage,
        galleryImages,
        amenities,
        location: {
          city: propForm.city,
          area: propForm.area,
          address: propForm.address,
          country: propForm.country,
          lat: Number(propForm.lat) || 0,
          lng: Number(propForm.lng) || 0
        }
      });
      showToast(`Property "${propForm.title}" updated.`);
    } else {
      addProperty({
        referenceId: propForm.referenceId,
        title: propForm.title,
        tagline: propForm.tagline,
        description: propForm.description,
        purpose: propForm.purpose,
        type: propForm.type,
        status: propForm.status,
        price: Number(propForm.price),
        pricePrefix: propForm.pricePrefix,
        rentalPeriod: propForm.purpose === 'rent' ? 'month' : undefined,
        currency: siteSettings.currencySymbol,
        isFeatured: propForm.isFeatured,
        isLuxury: propForm.isLuxury,
        isPriceReduced: propForm.isPriceReduced,
        bedrooms: Number(propForm.bedrooms),
        bathrooms: Number(propForm.bathrooms),
        parkingSpaces: Number(propForm.parkingSpaces),
        floorAreaSqFt: Number(propForm.floorAreaSqFt),
        landAreaSqFt: Number(propForm.landAreaSqFt) || undefined,
        yearBuilt: Number(propForm.yearBuilt) || undefined,
        furnishedStatus: propForm.furnishedStatus,
        featuredImage: propForm.featuredImage,
        galleryImages,
        amenities,
        location: {
          city: propForm.city,
          area: propForm.area,
          address: propForm.address,
          country: propForm.country,
          lat: Number(propForm.lat) || 0,
          lng: Number(propForm.lng) || 0
        }
      });
      showToast(`New property "${propForm.title}" published.`);
    }

    setPropModalOpen(false);
  };

  const displayedProperties = properties.filter(p => {
    if (!propSearch.trim()) return true;
    const q = propSearch.toLowerCase();
    return (
      p.title.toLowerCase().includes(q) ||
      p.referenceId.toLowerCase().includes(q) ||
      p.location.city.toLowerCase().includes(q) ||
      p.type.toLowerCase().includes(q)
    );
  });

  // LEADS & CRM TAB
  const [leadSearch, setLeadSearch] = useState('');
  const [leadStatusFilter, setLeadStatusFilter] = useState<string>('all');
  const [selectedLeadNotesId, setSelectedLeadNotesId] = useState<string | null>(null);
  const [newNoteText, setNewNoteText] = useState('');

  const displayedLeads = leads.filter(l => {
    if (leadStatusFilter !== 'all' && l.status !== leadStatusFilter) return false;
    if (leadSearch.trim()) {
      const q = leadSearch.toLowerCase();
      return (
        l.customerName.toLowerCase().includes(q) ||
        l.email.toLowerCase().includes(q) ||
        (l.propertyTitle && l.propertyTitle.toLowerCase().includes(q)) ||
        (l.propertyRef && l.propertyRef.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const exportLeadsCSV = () => {
    const headers = ['ID', 'Type', 'Customer Name', 'Email', 'Phone', 'Property Ref', 'Property Title', 'Status', 'Date', 'Message'];
    const rows = leads.map(l => [
      l.id,
      l.type,
      `"${l.customerName.replace(/"/g, '""')}"`,
      l.email,
      l.phone,
      l.propertyRef || '',
      `"${(l.propertyTitle || '').replace(/"/g, '""')}"`,
      l.status,
      l.createdAt,
      `"${l.message.replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `aurelia_leads_export_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('CRM Leads exported to CSV.');
  };

  // SETTINGS TAB
  const [settingsForm, setSettingsForm] = useState(siteSettings);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSiteSettings(settingsForm);
    showToast('Platform settings updated.');
  };

  return (
    <div className="min-h-screen bg-cool-50 flex flex-col">
      {/* Toast Alert */}
      {successToast && (
        <div className="fixed top-5 right-5 z-50 bg-navy text-white px-4 py-2.5 rounded-sm shadow-xl border border-white/20 flex items-center space-x-2 text-xs font-medium animate-in fade-in duration-150">
          <Check className="w-4 h-4 text-pink-muted" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Top Admin Bar: Deep Navy with Clean Monogram */}
      <header className="bg-navy text-white border-b border-white/10 px-6 py-3 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center space-x-3.5">
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-6 h-6 border border-white/40 flex items-center justify-center">
              <span className="text-white font-serif font-bold text-xs">A</span>
            </div>
            <span className="font-serif tracking-[0.2em] font-medium text-xs uppercase">
              {siteSettings.logoText} <span className="text-pink-muted font-light">Admin</span>
            </span>
          </Link>
          <span className="hidden sm:inline text-white/20">|</span>
          <span className="hidden sm:inline text-[11px] text-cool-400 font-light">
            {user?.name}
          </span>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <Link
            to="/"
            target="_blank"
            className="text-cool-400 hover:text-white flex items-center space-x-1 transition-colors text-[11px]"
          >
            <span>Live Site</span>
            <ExternalLink className="w-3 h-3" />
          </Link>
          <button
            onClick={() => {
              logout();
              navigate('/admin/login');
            }}
            className="text-cool-400 hover:text-rose-400 flex items-center space-x-1 transition-colors text-[11px]"
          >
            <LogOut className="w-3 h-3" />
            <span>Sign Out</span>
          </button>
        </div>
      </header>

      {/* Workspace */}
      <div className="flex-grow flex flex-col lg:flex-row">
        {/* Sidebar */}
        <aside className="lg:w-60 bg-navy-midnight text-white flex-shrink-0 p-3.5 space-y-1">
          <div className="text-[9.5px] uppercase tracking-widest text-cool-400 font-semibold px-2.5 py-1.5">
            Operations
          </div>

          <button
            onClick={() => setActiveTab('properties')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-sm text-xs font-medium tracking-wide transition-colors ${
              activeTab === 'properties' ? 'bg-white text-navy font-semibold' : 'text-cool-300 hover:bg-white/5'
            }`}
          >
            <div className="flex items-center space-x-2">
              <Building2 className="w-3.5 h-3.5" />
              <span>Properties</span>
            </div>
            <span className="text-[10px] bg-black/20 px-1.5 py-0.5 rounded">
              {properties.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('leads')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-sm text-xs font-medium tracking-wide transition-colors ${
              activeTab === 'leads' ? 'bg-white text-navy font-semibold' : 'text-cool-300 hover:bg-white/5'
            }`}
          >
            <div className="flex items-center space-x-2">
              <Inbox className="w-3.5 h-3.5" />
              <span>Inquiries CRM</span>
            </div>
            <span className="text-[10px] bg-pink-muted text-navy px-1.5 py-0.5 rounded font-bold">
              {leads.filter(l => l.status === 'New').length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('submissions')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-sm text-xs font-medium tracking-wide transition-colors ${
              activeTab === 'submissions' ? 'bg-white text-navy font-semibold' : 'text-cool-300 hover:bg-white/5'
            }`}
          >
            <div className="flex items-center space-x-2">
              <Users className="w-3.5 h-3.5" />
              <span>Seller Requests</span>
            </div>
            <span className="text-[10px] bg-black/20 px-1.5 py-0.5 rounded">
              {submissions.length}
            </span>
          </button>

          <div className="text-[9.5px] uppercase tracking-widest text-cool-400 font-semibold px-2.5 py-1.5 pt-5">
            Configuration
          </div>

          <button
            onClick={() => setActiveTab('content')}
            className={`w-full flex items-center space-x-2 px-3 py-2 rounded-sm text-xs font-medium tracking-wide transition-colors ${
              activeTab === 'content' ? 'bg-white text-navy font-semibold' : 'text-cool-300 hover:bg-white/5'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Content & Journal</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center space-x-2 px-3 py-2 rounded-sm text-xs font-medium tracking-wide transition-colors ${
              activeTab === 'settings' ? 'bg-white text-navy font-semibold' : 'text-cool-300 hover:bg-white/5'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Settings</span>
          </button>
        </aside>

        {/* Content Area */}
        <main className="flex-grow p-5 lg:p-8 max-w-6xl mx-auto w-full">
          {/* TAB 1: PROPERTIES MANAGEMENT */}
          {activeTab === 'properties' && (
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
                <div>
                  <h1 className="font-serif text-2xl font-medium text-cool-900">
                    Properties Portfolio Manager
                  </h1>
                  <p className="text-xs text-cool-500 font-light">
                    Add, edit, manage prices, and organize photo galleries for luxury listings.
                  </p>
                </div>

                <button
                  onClick={openNewPropertyModal}
                  className="bg-navy hover:bg-navy-midnight text-white px-3.5 py-2 text-xs uppercase tracking-wider font-medium rounded-sm flex items-center space-x-1.5 shadow-sm transition-colors"
                >
                  <Plus className="w-3.5 h-3.5 text-pink-muted" />
                  <span>Add Property</span>
                </button>
              </div>

              {/* Search Bar */}
              <div className="bg-white p-3 rounded-sm border border-cool-200/80 mb-5 flex items-center justify-between shadow-sm">
                <div className="relative w-full max-w-xs">
                  <Search className="w-3.5 h-3.5 text-cool-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search by title, ref ID, or city..."
                    value={propSearch}
                    onChange={e => setPropSearch(e.target.value)}
                    className="w-full bg-cool-50 border border-cool-200 pl-8 pr-2.5 py-1.5 text-xs text-cool-800 rounded-sm focus:outline-none focus:border-navy"
                  />
                </div>
                <span className="text-[11px] text-cool-500">
                  {displayedProperties.length} active listings
                </span>
              </div>

              {/* Properties Table */}
              <div className="bg-white border border-cool-200/80 rounded-sm shadow-sm overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-cool-50 border-b border-cool-200/80 text-cool-400 uppercase tracking-wider text-[10px] font-semibold">
                      <th className="p-3">Property</th>
                      <th className="p-3">Purpose / Type</th>
                      <th className="p-3">Price</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Featured</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-cool-100">
                    {displayedProperties.map(prop => (
                      <tr key={prop.id} className="hover:bg-cool-50/50 transition-colors">
                        <td className="p-3 flex items-center space-x-2.5">
                          <img
                            src={prop.featuredImage}
                            alt={prop.title}
                            className="w-12 h-9 object-cover rounded-sm flex-shrink-0 border border-cool-200"
                          />
                          <div>
                            <span className="text-[9px] uppercase font-mono text-cool-400 block">
                              {prop.referenceId}
                            </span>
                            <Link
                              to={`/property/${prop.id}`}
                              className="font-medium text-cool-900 hover:text-navy text-xs line-clamp-1"
                            >
                              {prop.title}
                            </Link>
                            <span className="text-[10px] text-cool-400 block">
                              {prop.location.area}, {prop.location.city}
                            </span>
                          </div>
                        </td>

                        <td className="p-3">
                          <span className="uppercase font-semibold text-cool-700 block text-[11px]">
                            {prop.purpose}
                          </span>
                          <span className="capitalize text-cool-400 text-[10px]">
                            {prop.type}
                          </span>
                        </td>

                        <td className="p-3 font-serif text-sm font-medium text-navy">
                          {formatPrice(prop.price, siteSettings.currencySymbol, prop.rentalPeriod)}
                        </td>

                        <td className="p-3">
                          <select
                            value={prop.status}
                            onChange={e => updatePropertyStatus(prop.id, e.target.value as PropertyStatus)}
                            className={`border text-[10px] uppercase tracking-wider font-semibold py-0.5 px-1.5 rounded-sm focus:outline-none ${
                              prop.status === 'available'
                                ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                                : prop.status === 'reserved'
                                ? 'bg-amber-50 border-amber-300 text-amber-800'
                                : 'bg-cool-100 border-cool-300 text-cool-700'
                            }`}
                          >
                            <option value="available">Available</option>
                            <option value="reserved">Reserved</option>
                            <option value="sold">Sold</option>
                            <option value="rented">Rented</option>
                          </select>
                        </td>

                        <td className="p-3">
                          <button
                            onClick={() => toggleFeatured(prop.id)}
                            className={`p-1 rounded-sm transition-colors ${
                              prop.isFeatured
                                ? 'text-pink-muted hover:text-navy'
                                : 'text-cool-300 hover:text-cool-500'
                            }`}
                            title={prop.isFeatured ? 'Featured' : 'Not featured'}
                          >
                            <Star className={`w-3.5 h-3.5 ${prop.isFeatured ? 'fill-current' : ''}`} />
                          </button>
                        </td>

                        <td className="p-3 text-right space-x-1.5">
                          <Link
                            to={`/property/${prop.id}`}
                            target="_blank"
                            className="p-1 border border-cool-200 rounded-sm hover:border-navy text-cool-500 inline-block"
                            title="View"
                          >
                            <Eye className="w-3 h-3" />
                          </Link>

                          <button
                            onClick={() => openEditPropertyModal(prop)}
                            className="p-1 border border-cool-200 rounded-sm hover:border-navy text-cool-500 hover:text-navy inline-block transition-colors"
                            title="Edit"
                          >
                            <Edit className="w-3 h-3" />
                          </button>

                          <button
                            onClick={() => {
                              if (window.confirm(`Delete "${prop.title}"?`)) {
                                deleteProperty(prop.id);
                                showToast('Property deleted.');
                              }
                            }}
                            className="p-1 border border-rose-200 text-rose-600 hover:bg-rose-50 rounded-sm inline-block transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: INQUIRIES & LEADS CRM */}
          {activeTab === 'leads' && (
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
                <div>
                  <h1 className="font-serif text-2xl font-medium text-cool-900">
                    Private Client CRM & Leads
                  </h1>
                  <p className="text-xs text-cool-500 font-light">
                    Manage viewing requests, dossier inquiries, contact status, and client advisory notes.
                  </p>
                </div>

                <button
                  onClick={exportLeadsCSV}
                  className="bg-white border border-cool-200 hover:bg-cool-50 text-cool-800 px-3 py-1.5 text-xs uppercase tracking-wider font-medium rounded-sm flex items-center space-x-1.5 shadow-sm transition-colors"
                >
                  <Download className="w-3.5 h-3.5 text-pink-muted" />
                  <span>Export CSV</span>
                </button>
              </div>

              {/* Status Tabs */}
              <div className="bg-white p-3 rounded-sm border border-cool-200/80 mb-5 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-sm">
                <div className="relative w-full sm:w-auto">
                  <Search className="w-3.5 h-3.5 text-cool-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search client or property..."
                    value={leadSearch}
                    onChange={e => setLeadSearch(e.target.value)}
                    className="bg-cool-50 border border-cool-200 pl-8 pr-2.5 py-1 text-xs text-cool-800 rounded-sm focus:outline-none focus:border-navy w-56"
                  />
                </div>

                <div className="flex items-center space-x-1 overflow-x-auto w-full sm:w-auto">
                  {['all', 'New', 'Contacted', 'Viewing Scheduled', 'Closed'].map(status => (
                    <button
                      key={status}
                      onClick={() => setLeadStatusFilter(status)}
                      className={`px-2.5 py-1 text-[11px] font-medium uppercase tracking-wider rounded-sm transition-colors ${
                        leadStatusFilter === status
                          ? 'bg-navy text-white font-semibold'
                          : 'bg-cool-100 text-cool-600 hover:bg-cool-200'
                      }`}
                    >
                      {status === 'all' ? 'All' : status}
                    </button>
                  ))}
                </div>
              </div>

              {/* Leads Table */}
              <div className="bg-white border border-cool-200/80 rounded-sm shadow-sm overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-cool-50 border-b border-cool-200/80 text-cool-400 uppercase tracking-wider text-[10px] font-semibold">
                      <th className="p-3">Customer</th>
                      <th className="p-3">Inquiry Target</th>
                      <th className="p-3">Schedule</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Notes</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-cool-100">
                    {displayedLeads.map(lead => (
                      <tr key={lead.id} className="hover:bg-cool-50/50 transition-colors">
                        <td className="p-3">
                          <span className="font-medium text-cool-900 text-xs block">
                            {lead.customerName}
                          </span>
                          <span className="text-cool-400 text-[10px] block">{lead.email}</span>
                          <span className="text-cool-400 text-[10px] block">{lead.phone}</span>
                        </td>

                        <td className="p-3">
                          {lead.propertyTitle ? (
                            <div>
                              <span className="font-medium text-cool-800 block line-clamp-1 text-xs">
                                {lead.propertyTitle}
                              </span>
                              <span className="text-[9px] font-mono text-cool-400">
                                Ref: {lead.propertyRef}
                              </span>
                            </div>
                          ) : (
                            <span className="text-cool-400 italic text-xs">General Mandate</span>
                          )}
                          <p className="text-[10px] text-cool-500 line-clamp-1 mt-0.5 font-light">
                            "{lead.message}"
                          </p>
                        </td>

                        <td className="p-3 text-[11px] text-cool-600">
                          {lead.preferredDate ? `${lead.preferredDate} ${lead.preferredTime || ''}` : 'Flexible'}
                        </td>

                        <td className="p-3">
                          <select
                            value={lead.status}
                            onChange={e => updateLeadStatus(lead.id, e.target.value as LeadStatus)}
                            className="border text-[10px] uppercase tracking-wider font-semibold py-0.5 px-1.5 rounded-sm bg-cool-50 border-cool-200 focus:outline-none"
                          >
                            <option value="New">New</option>
                            <option value="Contacted">Contacted</option>
                            <option value="Follow-up">Follow-up</option>
                            <option value="Viewing Scheduled">Viewing Scheduled</option>
                            <option value="Negotiation">Negotiation</option>
                            <option value="Closed">Closed</option>
                            <option value="Unsuccessful">Unsuccessful</option>
                          </select>
                        </td>

                        <td className="p-3">
                          <button
                            onClick={() => setSelectedLeadNotesId(lead.id)}
                            className="text-[11px] text-navy hover:underline font-medium"
                          >
                            {lead.notes ? 'View Notes' : '+ Add Note'}
                          </button>
                        </td>

                        <td className="p-3 text-right">
                          <button
                            onClick={() => {
                              if (window.confirm('Delete lead?')) {
                                deleteLead(lead.id);
                                showToast('Lead removed.');
                              }
                            }}
                            className="p-1 border border-rose-200 text-rose-600 hover:bg-rose-50 rounded-sm transition-colors"
                            title="Delete Lead"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: SELLER SUBMISSIONS */}
          {activeTab === 'submissions' && (
            <div>
              <div className="mb-5">
                <h1 className="font-serif text-2xl font-medium text-cool-900">
                  Seller & Owner Listing Submissions
                </h1>
                <p className="text-xs text-cool-500 font-light">
                  Property owners who submitted their residence through the Sell With Us portal.
                </p>
              </div>

              {submissions.length === 0 ? (
                <div className="bg-white border border-cool-200/80 p-10 text-center rounded-sm shadow-sm">
                  <Inbox className="w-10 h-10 text-cool-300 mx-auto mb-2" />
                  <h3 className="font-serif text-lg font-medium text-cool-900 mb-1">
                    No Pending Submissions
                  </h3>
                  <p className="text-xs text-cool-400">
                    Submissions from the public form will appear here in real-time.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {submissions.map(sub => (
                    <div
                      key={sub.id}
                      className="bg-white border border-cool-200/80 p-5 rounded-sm shadow-sm flex flex-col md:flex-row justify-between gap-4"
                    >
                      <div className="space-y-2 text-xs">
                        <div className="flex items-center space-x-2">
                          <span className="font-serif text-lg font-medium text-cool-900">
                            {sub.ownerName}
                          </span>
                          <span className="bg-cool-100 text-cool-700 text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded">
                            {sub.purpose} • {sub.propertyType}
                          </span>
                        </div>

                        <div className="text-cool-600 space-y-0.5">
                          <div>📍 <strong>Location:</strong> {sub.propertyLocation}</div>
                          <div>💰 <strong>Expected Price:</strong> ${sub.expectedPrice.toLocaleString()}</div>
                          <div>📞 <strong>Contact:</strong> {sub.phone} | {sub.email}</div>
                        </div>

                        <p className="text-cool-500 font-light line-clamp-2">
                          "{sub.description}"
                        </p>
                      </div>

                      <div className="flex flex-col justify-between items-end space-y-3">
                        <select
                          value={sub.status}
                          onChange={e => updateSubmissionStatus(sub.id, e.target.value as any)}
                          className="bg-cool-50 border border-cool-200 text-xs py-1 px-2.5 rounded-sm font-medium uppercase tracking-wider focus:outline-none"
                        >
                          <option value="pending">Pending</option>
                          <option value="reviewed">Reviewed</option>
                          <option value="listed">Listed</option>
                          <option value="declined">Declined</option>
                        </select>

                        <button
                          onClick={() => {
                            setEditingPropertyId(null);
                            setPropForm({
                              ...propForm,
                              title: `${sub.propertyType.toUpperCase()} in ${sub.propertyLocation}`,
                              description: sub.description,
                              purpose: sub.purpose,
                              type: sub.propertyType,
                              price: sub.expectedPrice,
                              address: sub.propertyLocation,
                              featuredImage: sub.photos[0] || propForm.featuredImage
                            });
                            setActiveTab('properties');
                            setPropModalOpen(true);
                          }}
                          className="bg-navy hover:bg-navy-midnight text-white px-3 py-1.5 text-xs uppercase tracking-wider font-medium rounded-sm transition-colors"
                        >
                          Convert to Active Listing
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: CONTENT & JOURNAL */}
          {activeTab === 'content' && (
            <div className="space-y-8">
              <div>
                <h1 className="font-serif text-2xl font-medium text-cool-900 mb-1">
                  Content & Journal Management
                </h1>
                <p className="text-xs text-cool-500 font-light">
                  Manage articles and client testimonials.
                </p>
              </div>

              {/* Blog Articles */}
              <div className="bg-white border border-cool-200/80 p-5 rounded-sm shadow-sm">
                <h3 className="font-serif text-lg font-medium text-cool-900 mb-3 border-b border-cool-100 pb-2">
                  Editorial Journal ({blogPosts.length})
                </h3>

                <div className="space-y-2">
                  {blogPosts.map(post => (
                    <div
                      key={post.id}
                      className="flex items-center justify-between p-2.5 bg-cool-50 rounded-sm border border-cool-200/60"
                    >
                      <div className="flex items-center space-x-2.5">
                        <img
                          src={post.image}
                          alt={post.title}
                          className="w-10 h-7 object-cover rounded-sm"
                        />
                        <div>
                          <span className="font-medium text-xs text-cool-900 block line-clamp-1">
                            {post.title}
                          </span>
                          <span className="text-[10px] text-cool-400">
                            {post.category} • {post.publishedAt}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-1.5">
                        <Link
                          to={`/blog/${post.slug}`}
                          target="_blank"
                          className="p-1 border border-cool-200 rounded text-cool-600 hover:border-navy"
                          title="View"
                        >
                          <Eye className="w-3 h-3" />
                        </Link>
                        <button
                          onClick={() => {
                            if (window.confirm('Delete article?')) {
                              deleteBlogPost(post.id);
                              showToast('Article deleted.');
                            }
                          }}
                          className="p-1 border border-rose-200 text-rose-600 hover:bg-rose-50 rounded"
                          title="Delete"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Testimonials */}
              <div className="bg-white border border-cool-200/80 p-5 rounded-sm shadow-sm">
                <h3 className="font-serif text-lg font-medium text-cool-900 mb-3 border-b border-cool-100 pb-2">
                  Client Testimonials ({testimonials.length})
                </h3>

                <div className="space-y-2">
                  {testimonials.map(test => (
                    <div
                      key={test.id}
                      className="flex items-center justify-between p-2.5 bg-cool-50 rounded-sm border border-cool-200/60"
                    >
                      <div>
                        <span className="font-medium text-xs text-cool-900 block">
                          {test.clientName} ({test.location})
                        </span>
                        <p className="text-[11px] text-cool-500 italic line-clamp-1">"{test.quote}"</p>
                      </div>

                      <button
                        onClick={() => {
                          if (window.confirm('Delete testimonial?')) {
                            deleteTestimonial(test.id);
                            showToast('Testimonial deleted.');
                          }
                        }}
                        className="p-1 border border-rose-200 text-rose-600 hover:bg-rose-50 rounded"
                        title="Delete"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: WEBSITE SETTINGS */}
          {activeTab === 'settings' && (
            <div className="bg-white border border-cool-200/80 p-6 rounded-sm shadow-sm max-w-2xl">
              <div className="mb-5 border-b border-cool-100 pb-3">
                <h1 className="font-serif text-2xl font-medium text-cool-900">
                  Global Settings
                </h1>
                <p className="text-xs text-cool-500 font-light">
                  Update company branding, contact numbers, and currency symbols.
                </p>
              </div>

              <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                      Company Name
                    </label>
                    <input
                      type="text"
                      value={settingsForm.companyName}
                      onChange={e => setSettingsForm({ ...settingsForm, companyName: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 p-2 rounded-sm focus:border-navy focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                      Logo Text
                    </label>
                    <input
                      type="text"
                      value={settingsForm.logoText}
                      onChange={e => setSettingsForm({ ...settingsForm, logoText: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 p-2 rounded-sm focus:border-navy focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                      WhatsApp Digits (e.g. 447946088800)
                    </label>
                    <input
                      type="text"
                      value={settingsForm.whatsappNumber}
                      onChange={e => setSettingsForm({ ...settingsForm, whatsappNumber: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 p-2 rounded-sm focus:border-navy focus:outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                      WhatsApp Display
                    </label>
                    <input
                      type="text"
                      value={settingsForm.whatsappDisplay}
                      onChange={e => setSettingsForm({ ...settingsForm, whatsappDisplay: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 p-2 rounded-sm focus:border-navy focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                      Phone Number
                    </label>
                    <input
                      type="text"
                      value={settingsForm.phone}
                      onChange={e => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 p-2 rounded-sm focus:border-navy focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                      Email
                    </label>
                    <input
                      type="email"
                      value={settingsForm.email}
                      onChange={e => setSettingsForm({ ...settingsForm, email: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 p-2 rounded-sm focus:border-navy focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                    Headquarters Address
                  </label>
                  <input
                    type="text"
                    value={settingsForm.address}
                    onChange={e => setSettingsForm({ ...settingsForm, address: e.target.value })}
                    className="w-full bg-cool-50 border border-cool-200 p-2 rounded-sm focus:border-navy focus:outline-none"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="bg-navy hover:bg-navy-midnight text-white px-6 py-2 text-xs uppercase tracking-wider font-medium rounded-sm transition-colors"
                  >
                    Save Settings
                  </button>
                </div>
              </form>
            </div>
          )}
        </main>
      </div>

      {/* ADD / EDIT PROPERTY MODAL */}
      {propModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm overflow-y-auto flex items-center justify-center p-4">
          <div className="bg-white rounded-sm shadow-2xl max-w-3xl w-full my-6 border border-cool-200 overflow-hidden">
            <div className="bg-navy text-white px-5 py-3.5 flex items-center justify-between">
              <h3 className="font-serif text-lg font-medium">
                {editingPropertyId ? 'Edit Property Listing' : 'Publish Property'}
              </h3>
              <button
                onClick={() => setPropModalOpen(false)}
                className="text-cool-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveProperty} className="p-5 sm:p-6 space-y-4 max-h-[80vh] overflow-y-auto text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                    Reference ID *
                  </label>
                  <input
                    type="text"
                    required
                    value={propForm.referenceId}
                    onChange={e => setPropForm({ ...propForm, referenceId: e.target.value })}
                    className="w-full bg-cool-50 border border-cool-200 p-1.5 rounded-sm font-mono font-bold"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                    Property Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={propForm.title}
                    onChange={e => setPropForm({ ...propForm, title: e.target.value })}
                    className="w-full bg-cool-50 border border-cool-200 p-1.5 rounded-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                    Purpose *
                  </label>
                  <select
                    value={propForm.purpose}
                    onChange={e => setPropForm({ ...propForm, purpose: e.target.value as PropertyPurpose })}
                    className="w-full bg-cool-50 border border-cool-200 p-1.5 rounded-sm"
                  >
                    <option value="sale">For Sale</option>
                    <option value="rent">For Rent</option>
                  </select>
                </div>

                <div>
                  <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                    Type *
                  </label>
                  <select
                    value={propForm.type}
                    onChange={e => setPropForm({ ...propForm, type: e.target.value as PropertyType })}
                    className="w-full bg-cool-50 border border-cool-200 p-1.5 rounded-sm"
                  >
                    <option value="villa">Villa</option>
                    <option value="penthouse">Penthouse</option>
                    <option value="apartment">Apartment</option>
                    <option value="house">Townhouse</option>
                    <option value="commercial">Commercial</option>
                    <option value="land">Land</option>
                  </select>
                </div>

                <div>
                  <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                    Price ($) *
                  </label>
                  <input
                    type="number"
                    required
                    value={propForm.price}
                    onChange={e => setPropForm({ ...propForm, price: Number(e.target.value) })}
                    className="w-full bg-cool-50 border border-cool-200 p-1.5 rounded-sm font-semibold"
                  />
                </div>

                <div>
                  <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                    City *
                  </label>
                  <input
                    type="text"
                    required
                    value={propForm.city}
                    onChange={e => setPropForm({ ...propForm, city: e.target.value })}
                    className="w-full bg-cool-50 border border-cool-200 p-1.5 rounded-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                  Featured Main Image URL *
                </label>
                <input
                  type="url"
                  required
                  value={propForm.featuredImage}
                  onChange={e => setPropForm({ ...propForm, featuredImage: e.target.value })}
                  className="w-full bg-cool-50 border border-cool-200 p-1.5 rounded-sm font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="block uppercase tracking-wider text-cool-400 font-medium mb-1 text-[10px]">
                  Description
                </label>
                <textarea
                  rows={3}
                  value={propForm.description}
                  onChange={e => setPropForm({ ...propForm, description: e.target.value })}
                  className="w-full bg-cool-50 border border-cool-200 p-2 rounded-sm font-light"
                />
              </div>

              <div className="flex space-x-4 pt-2">
                <label className="flex items-center space-x-1.5 cursor-pointer text-cool-700">
                  <input
                    type="checkbox"
                    checked={propForm.isFeatured}
                    onChange={e => setPropForm({ ...propForm, isFeatured: e.target.checked })}
                    className="accent-navy"
                  />
                  <span>Featured</span>
                </label>

                <label className="flex items-center space-x-1.5 cursor-pointer text-cool-700">
                  <input
                    type="checkbox"
                    checked={propForm.isLuxury}
                    onChange={e => setPropForm({ ...propForm, isLuxury: e.target.checked })}
                    className="accent-navy"
                  />
                  <span>Trophy Luxury</span>
                </label>
              </div>

              <div className="border-t border-cool-100 pt-3 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setPropModalOpen(false)}
                  className="px-4 py-1.5 border border-cool-200 text-cool-600 rounded-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-navy hover:bg-navy-midnight text-white px-6 py-1.5 rounded-sm font-medium uppercase tracking-wider"
                >
                  {editingPropertyId ? 'Save Changes' : 'Publish Property'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* LEAD NOTES MODAL */}
      {selectedLeadNotesId && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-sm max-w-sm w-full p-5 shadow-xl border border-cool-200">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-serif text-base font-medium text-cool-900">
                Client Advisory Log
              </h3>
              <button onClick={() => setSelectedLeadNotesId(null)}>
                <X className="w-3.5 h-3.5 text-cool-400" />
              </button>
            </div>

            <div className="bg-cool-50 p-2.5 rounded-sm border border-cool-200 text-xs text-cool-600 whitespace-pre-line mb-3 max-h-40 overflow-y-auto">
              {leads.find(l => l.id === selectedLeadNotesId)?.notes || 'No notes logged yet.'}
            </div>

            <textarea
              rows={3}
              placeholder="Add note..."
              value={newNoteText}
              onChange={e => setNewNoteText(e.target.value)}
              className="w-full bg-cool-50 border border-cool-200 p-2 text-xs rounded-sm mb-3 focus:outline-none focus:border-navy"
            />

            <div className="flex justify-end space-x-2 text-xs">
              <button
                type="button"
                onClick={() => setSelectedLeadNotesId(null)}
                className="px-3 py-1 text-cool-500"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => {
                  if (newNoteText.trim()) {
                    addLeadNote(selectedLeadNotesId, newNoteText.trim());
                    setNewNoteText('');
                    showToast('Note saved.');
                  }
                }}
                className="bg-navy text-white px-4 py-1 rounded-sm font-medium uppercase tracking-wider text-[11px]"
              >
                Save Note
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
