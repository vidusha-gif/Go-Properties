import React from 'react';
import { Link } from 'react-router-dom';
import {
  Scale,
  X,
  Plus,
  ArrowRight,
  Check,
  Minus
} from 'lucide-react';
import { useRealEstate } from '../context/RealEstateContext';
import { formatPrice, formatArea } from '../utils/helpers';

export const PropertyComparePage: React.FC = () => {
  const { compareList, removeFromCompare, clearCompare, properties, siteSettings } = useRealEstate();

  const comparedProperties = properties.filter(p => compareList.includes(p.id));

  const allAmenities = Array.from(
    new Set(comparedProperties.flatMap(p => p.amenities))
  ).sort();

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between border-b border-cool-200/60 pb-4 mb-6 gap-3">
          <div>
            <div className="flex items-center space-x-1.5 text-cool-400 text-[10px] uppercase tracking-[0.25em] font-semibold mb-1">
              <Scale className="w-3.5 h-3.5" />
              <span>Side-by-Side</span>
            </div>
            <h1 className="font-serif text-2xl sm:text-4xl font-medium text-cool-900">
              Property Comparison
            </h1>
          </div>

          {comparedProperties.length > 0 && (
            <div className="flex items-center space-x-3">
              <span className="text-xs text-cool-500">
                Comparing <strong className="text-cool-900">{comparedProperties.length}</strong> of 4
              </span>
              <button
                onClick={clearCompare}
                className="text-xs font-medium uppercase tracking-wider text-cool-400 hover:text-rose-600 transition-colors"
              >
                Clear All
              </button>
            </div>
          )}
        </div>

        {comparedProperties.length === 0 ? (
          <div className="bg-white border border-cool-200/80 rounded-sm p-12 text-center max-w-md mx-auto shadow-sm">
            <h3 className="font-serif text-xl font-medium text-cool-900 mb-1.5">
              No Properties Selected
            </h3>
            <p className="text-cool-500 text-xs font-light mb-5 max-w-sm mx-auto">
              Select the balance scale icon on any property card or detail page to compare up to 4 residences side-by-side.
            </p>
            <Link
              to="/properties"
              className="bg-navy hover:bg-navy-midnight text-white px-5 py-2 text-xs uppercase tracking-wider font-medium rounded-sm inline-flex items-center space-x-1.5 transition-colors"
            >
              <span>Browse Properties</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full bg-white border border-cool-200/80 rounded-sm shadow-sm border-collapse min-w-[650px]">
              <thead>
                <tr>
                  <th className="p-3.5 text-left bg-cool-50 border-b border-r border-cool-200 w-1/5 text-[11px] uppercase tracking-wider text-cool-400 font-medium">
                    Criteria
                  </th>
                  {comparedProperties.map(prop => (
                    <th
                      key={prop.id}
                      className="p-3.5 bg-cool-50 border-b border-r border-cool-200 last:border-r-0 relative align-top"
                    >
                      <button
                        onClick={() => removeFromCompare(prop.id)}
                        className="absolute top-2.5 right-2.5 p-1 rounded-full bg-cool-200 hover:bg-rose-100 hover:text-rose-600 text-cool-500 transition-colors"
                        title="Remove"
                      >
                        <X className="w-3 h-3" />
                      </button>

                      <div className="aspect-[16/10] w-full rounded-sm overflow-hidden mb-2 bg-cool-100">
                        <img
                          src={prop.featuredImage}
                          alt={prop.title}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      <div className="text-left">
                        <span className="text-[9px] uppercase tracking-wider font-mono text-cool-400 block">
                          Ref: {prop.referenceId}
                        </span>
                        <Link
                          to={`/property/${prop.id}`}
                          className="font-serif text-base font-medium text-cool-900 hover:text-navy transition-colors line-clamp-1 block"
                        >
                          {prop.title}
                        </Link>
                      </div>
                    </th>
                  ))}

                  {comparedProperties.length < 4 && (
                    <th className="p-3.5 bg-cool-50/50 border-b border-cool-200 text-center align-middle">
                      <Link
                        to="/properties"
                        className="border border-dashed border-cool-300 hover:border-navy p-6 rounded-sm flex flex-col items-center justify-center text-cool-400 hover:text-navy transition-colors"
                      >
                        <Plus className="w-5 h-5 mb-1" />
                        <span className="text-[10px] font-medium uppercase tracking-wider">
                          Add Property
                        </span>
                      </Link>
                    </th>
                  )}
                </tr>
              </thead>

              <tbody className="divide-y divide-cool-100 text-xs">
                {/* Price */}
                <tr>
                  <td className="p-3.5 font-medium text-cool-700 bg-cool-50/70 border-r border-cool-200">
                    Price
                  </td>
                  {comparedProperties.map(prop => (
                    <td key={prop.id} className="p-3.5 border-r border-cool-200 last:border-r-0 font-serif text-lg font-medium text-navy">
                      {formatPrice(prop.price, siteSettings.currencySymbol, prop.rentalPeriod)}
                    </td>
                  ))}
                  {comparedProperties.length < 4 && <td className="p-3.5 bg-cool-50/20"></td>}
                </tr>

                {/* Purpose / Status */}
                <tr>
                  <td className="p-3.5 font-medium text-cool-700 bg-cool-50/70 border-r border-cool-200">
                    Purpose & Status
                  </td>
                  {comparedProperties.map(prop => (
                    <td key={prop.id} className="p-3.5 border-r border-cool-200 last:border-r-0">
                      <span className="uppercase font-semibold tracking-wider text-cool-900">
                        {prop.purpose === 'sale' ? 'For Sale' : 'For Rent'}
                      </span>
                      <span className="text-cool-300 mx-1">•</span>
                      <span className="capitalize text-cool-500">{prop.status}</span>
                    </td>
                  ))}
                  {comparedProperties.length < 4 && <td className="p-3.5 bg-cool-50/20"></td>}
                </tr>

                {/* Type */}
                <tr>
                  <td className="p-3.5 font-medium text-cool-700 bg-cool-50/70 border-r border-cool-200">
                    Type
                  </td>
                  {comparedProperties.map(prop => (
                    <td key={prop.id} className="p-3.5 border-r border-cool-200 last:border-r-0 capitalize text-cool-600">
                      {prop.type}
                    </td>
                  ))}
                  {comparedProperties.length < 4 && <td className="p-3.5 bg-cool-50/20"></td>}
                </tr>

                {/* Location */}
                <tr>
                  <td className="p-3.5 font-medium text-cool-700 bg-cool-50/70 border-r border-cool-200">
                    Location
                  </td>
                  {comparedProperties.map(prop => (
                    <td key={prop.id} className="p-3.5 border-r border-cool-200 last:border-r-0 text-cool-600">
                      {prop.location.area}, {prop.location.city}
                    </td>
                  ))}
                  {comparedProperties.length < 4 && <td className="p-3.5 bg-cool-50/20"></td>}
                </tr>

                {/* Beds / Baths */}
                <tr>
                  <td className="p-3.5 font-medium text-cool-700 bg-cool-50/70 border-r border-cool-200">
                    Bedrooms / Baths
                  </td>
                  {comparedProperties.map(prop => (
                    <td key={prop.id} className="p-3.5 border-r border-cool-200 last:border-r-0 text-cool-600">
                      {prop.bedrooms} Beds / {prop.bathrooms} Baths
                    </td>
                  ))}
                  {comparedProperties.length < 4 && <td className="p-3.5 bg-cool-50/20"></td>}
                </tr>

                {/* Floor Area */}
                <tr>
                  <td className="p-3.5 font-medium text-cool-700 bg-cool-50/70 border-r border-cool-200">
                    Floor Area
                  </td>
                  {comparedProperties.map(prop => (
                    <td key={prop.id} className="p-3.5 border-r border-cool-200 last:border-r-0 text-cool-600">
                      {formatArea(prop.floorAreaSqFt)}
                    </td>
                  ))}
                  {comparedProperties.length < 4 && <td className="p-3.5 bg-cool-50/20"></td>}
                </tr>

                {/* Amenities Matrix */}
                <tr>
                  <td colSpan={comparedProperties.length + 1} className="p-3 bg-cool-100 font-serif text-xs font-semibold text-cool-800">
                    Amenities Breakdown
                  </td>
                </tr>

                {allAmenities.map((amenity, idx) => (
                  <tr key={idx}>
                    <td className="p-2.5 font-normal text-cool-600 bg-cool-50/70 border-r border-cool-200">
                      {amenity}
                    </td>
                    {comparedProperties.map(prop => {
                      const hasAmenity = prop.amenities.includes(amenity);
                      return (
                        <td key={prop.id} className="p-2.5 border-r border-cool-200 last:border-r-0 text-center">
                          {hasAmenity ? (
                            <span className="text-navy font-bold text-xs">✓</span>
                          ) : (
                            <span className="text-cool-300 text-xs">—</span>
                          )}
                        </td>
                      );
                    })}
                    {comparedProperties.length < 4 && <td className="p-2.5 bg-cool-50/20"></td>}
                  </tr>
                ))}

                {/* Action */}
                <tr>
                  <td className="p-3.5 bg-cool-50/70 border-r border-cool-200 font-medium text-cool-700">
                    Action
                  </td>
                  {comparedProperties.map(prop => (
                    <td key={prop.id} className="p-3.5 border-r border-cool-200 last:border-r-0 text-center">
                      <Link
                        to={`/property/${prop.id}`}
                        className="bg-navy hover:bg-navy-midnight text-white px-3 py-1.5 rounded-sm text-[10px] uppercase tracking-wider font-medium inline-block transition-colors"
                      >
                        View Details
                      </Link>
                    </td>
                  ))}
                  {comparedProperties.length < 4 && <td className="p-3.5 bg-cool-50/20"></td>}
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
