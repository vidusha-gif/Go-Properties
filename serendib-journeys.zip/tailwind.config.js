/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        tropical: {
          DEFAULT: '#123D32',
          deep: '#123D32',
          emerald: '#176B50',
          light: '#1f5345',
          subtle: '#e8f3ef'
        },
        gold: {
          DEFAULT: '#D6AD60',
          light: '#E5C483',
          dark: '#B78F3E',
          subtle: '#FAF4E8'
        },
        cream: {
          DEFAULT: '#FAF8F2',
          dark: '#F0ECE1'
        },
        charcoal: {
          DEFAULT: '#222A26',
          light: '#36403B',
          muted: '#626E67'
        }
      },
      fontFamily: {
        serif: ['"Playfair Display"', 'Georgia', 'serif'],
        sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif']
      },
      boxShadow: {
        'luxury': '0 20px 40px -15px rgba(18, 61, 50, 0.12), 0 0 1px 1px rgba(214, 173, 96, 0.2)',
        'gold-glow': '0 0 25px rgba(214, 173, 96, 0.35)',
        'card': '0 10px 30px -10px rgba(18, 61, 50, 0.08)'
      }
    },
  },
  plugins: [],
}
