import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Mail,
  Phone,
  MapPin,
  Clock,
  ArrowRight,
  ShieldCheck,
  Instagram,
  Linkedin,
  Facebook,
  Youtube,
  MessageCircle,
  CheckCircle2
} from 'lucide-react';
import { useRealEstate } from '../../context/RealEstateContext';
import { generateWhatsAppLink } from '../../utils/helpers';

export const Footer: React.FC = () => {
  const { siteSettings } = useRealEstate();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim()) {
      setSubscribed(true);
      setNewsletterEmail('');
      setTimeout(() => setSubscribed(false), 5000);
    }
  };

  const whatsappHref = generateWhatsAppLink(
    siteSettings.whatsappNumber,
    `Hello, I would like to connect with an advisor at ${siteSettings.companyName}.`
  );

  return (
    <footer className="bg-navy text-stone-300 border-t border-white/10 pt-16 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Newsletter: Deep Midnight Blue with Muted Pink Accent */}
        <div className="bg-navy-midnight/80 border border-white/10 rounded-sm p-6 sm:p-10 mb-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-7">
              <span className="text-[10px] uppercase tracking-[0.25em] text-pink-muted font-semibold block mb-1.5">
                Private Gazette
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl text-white font-normal mb-2">
                Curated Global Market Intelligence
              </h3>
              <p className="text-cool-400 text-xs max-w-lg font-light leading-relaxed">
                Receive confidential off-market briefings, prime residential transaction analyses, and architectural monographs directly from our partners.
              </p>
            </div>

            <div className="lg:col-span-5">
              {subscribed ? (
                <div className="bg-emerald-950/50 border border-emerald-500/30 text-emerald-300 p-3 rounded-sm flex items-center space-x-2.5 text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>You have been added to our private editorial dispatch.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="email"
                    required
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    placeholder="Enter your email address..."
                    className="flex-grow bg-white/5 border border-white/15 px-3.5 py-2 text-xs text-white placeholder-cool-400 focus:outline-none focus:border-pink-muted rounded-sm transition-colors"
                  />
                  <button
                    type="submit"
                    className="bg-white hover:bg-pink-soft text-navy px-5 py-2 text-xs uppercase tracking-wider font-semibold rounded-sm transition-colors flex items-center justify-center space-x-1.5 flex-shrink-0"
                  >
                    <span>Subscribe</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </form>
              )}
              <span className="text-[10px] text-cool-400 mt-2 block font-light">
                Discreet distribution. No third-party syndication. Unsubscribe anytime.
              </span>
            </div>
          </div>
        </div>

        {/* 4-column footer directory */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 mb-14">
          {/* Col 1: Brand Info */}
          <div className="lg:col-span-4 space-y-4">
            <Link to="/" className="flex items-center space-x-2.5 group">
              <div className="w-7 h-7 border border-white/40 flex items-center justify-center group-hover:border-pink-muted transition-colors">
                <span className="text-white group-hover:text-pink-muted font-serif font-bold text-xs">
                  A
                </span>
              </div>
              <div>
                <span className="font-serif tracking-[0.24em] text-base font-medium uppercase text-white block">
                  {siteSettings.logoText}
                </span>
                <span className="text-[7.5px] uppercase tracking-[0.3em] text-cool-400 block -mt-1 font-light">
                  Private Estates
                </span>
              </div>
            </Link>

            <p className="text-cool-400 text-xs leading-relaxed font-light">
              Aurelia Estates represents the world's most discerning private clients, family offices, and architectural connoisseurs across premier global capitals.
            </p>

            <div className="pt-2">
              <span className="text-[10px] uppercase tracking-wider text-cool-400 font-semibold block mb-2.5">
                Global Advisory Network
              </span>
              <div className="flex items-center space-x-2.5">
                <a
                  href={siteSettings.socialLinks.instagram}
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-cool-400 hover:text-white hover:border-pink-muted transition-colors"
                  aria-label="Instagram"
                >
                  <Instagram className="w-3.5 h-3.5" />
                </a>
                <a
                  href={siteSettings.socialLinks.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-cool-400 hover:text-white hover:border-pink-muted transition-colors"
                  aria-label="LinkedIn"
                >
                  <Linkedin className="w-3.5 h-3.5" />
                </a>
                <a
                  href={siteSettings.socialLinks.facebook}
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-cool-400 hover:text-white hover:border-pink-muted transition-colors"
                  aria-label="Facebook"
                >
                  <Facebook className="w-3.5 h-3.5" />
                </a>
                <a
                  href={siteSettings.socialLinks.youtube}
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-cool-400 hover:text-white hover:border-pink-muted transition-colors"
                  aria-label="YouTube"
                >
                  <Youtube className="w-3.5 h-3.5" />
                </a>
                <a
                  href={whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-pink-muted hover:bg-white/5 transition-colors"
                  aria-label="WhatsApp"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>

          {/* Col 2: Portfolios */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-serif text-base text-white font-medium border-b border-white/10 pb-1.5">
              Portfolios
            </h4>
            <ul className="space-y-2 text-xs text-cool-400">
              <li>
                <Link to="/properties" className="hover:text-white transition-colors">
                  All Properties
                </Link>
              </li>
              <li>
                <Link to="/properties?purpose=sale" className="hover:text-white transition-colors">
                  Residences for Sale
                </Link>
              </li>
              <li>
                <Link to="/properties?purpose=rent" className="hover:text-white transition-colors">
                  Prime Rentals
                </Link>
              </li>
              <li>
                <Link to="/properties?tag=luxury" className="hover:text-white transition-colors">
                  Trophy & Luxury Estates
                </Link>
              </li>
              <li>
                <Link to="/properties?type=villa" className="hover:text-white transition-colors">
                  Waterfront Villas
                </Link>
              </li>
              <li>
                <Link to="/properties?type=penthouse" className="hover:text-white transition-colors">
                  Skyline Penthouses
                </Link>
              </li>
              <li>
                <Link to="/properties?type=commercial" className="hover:text-white transition-colors">
                  Commercial Assets
                </Link>
              </li>
              <li>
                <Link to="/properties?type=land" className="hover:text-white transition-colors">
                  Development Land
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Company */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-serif text-base text-white font-medium border-b border-white/10 pb-1.5">
              Company
            </h4>
            <ul className="space-y-2 text-xs text-cool-400">
              <li>
                <Link to="/about" className="hover:text-white transition-colors">
                  About Our House
                </Link>
              </li>
              <li>
                <Link to="/team" className="hover:text-white transition-colors">
                  Brokers & Partners
                </Link>
              </li>
              <li>
                <Link to="/sell" className="hover:text-white transition-colors">
                  List Your Property
                </Link>
              </li>
              <li>
                <Link to="/locations" className="hover:text-white transition-colors">
                  Global Destinations
                </Link>
              </li>
              <li>
                <Link to="/blog" className="hover:text-white transition-colors">
                  Editorial & Insights
                </Link>
              </li>
              <li>
                <Link to="/faq" className="hover:text-white transition-colors">
                  Client FAQs
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-white transition-colors">
                  Private Office
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 4: Private Office Info */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-serif text-base text-white font-medium border-b border-white/10 pb-1.5">
              Private Office
            </h4>
            <div className="space-y-2.5 text-xs text-cool-400">
              <div className="flex items-start space-x-2.5">
                <MapPin className="w-3.5 h-3.5 text-pink-muted flex-shrink-0 mt-0.5" />
                <span>{siteSettings.address}</span>
              </div>
              <div className="flex items-center space-x-2.5">
                <Phone className="w-3.5 h-3.5 text-pink-muted flex-shrink-0" />
                <a href={`tel:${siteSettings.phone.replace(/[^0-9+]/g, '')}`} className="hover:text-white transition-colors">
                  {siteSettings.phone}
                </a>
              </div>
              <div className="flex items-center space-x-2.5">
                <MessageCircle className="w-3.5 h-3.5 text-pink-muted flex-shrink-0" />
                <a href={whatsappHref} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                  {siteSettings.whatsappDisplay} (WhatsApp)
                </a>
              </div>
              <div className="flex items-center space-x-2.5">
                <Mail className="w-3.5 h-3.5 text-pink-muted flex-shrink-0" />
                <a href={`mailto:${siteSettings.email}`} className="hover:text-white transition-colors">
                  {siteSettings.email}
                </a>
              </div>
              <div className="flex items-center space-x-2.5 text-[11px] text-cool-400">
                <Clock className="w-3.5 h-3.5 text-cool-400 flex-shrink-0" />
                <span>{siteSettings.businessHours}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Sub-footer */}
        <div className="border-t border-white/10 pt-6 flex flex-col md:flex-row items-center justify-between text-[11px] text-cool-400 space-y-3 md:space-y-0">
          <div>
            © {new Date().getFullYear()} {siteSettings.companyName}. All rights reserved.
          </div>

          <div className="flex items-center space-x-5">
            <Link to="/privacy" className="hover:text-stone-200 transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="hover:text-stone-200 transition-colors">
              Terms & Conditions
            </Link>
            <Link
              to="/admin/login"
              className="hover:text-white text-cool-400 flex items-center space-x-1 transition-colors"
            >
              <ShieldCheck className="w-3 h-3 text-pink-muted" />
              <span>Admin</span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};
