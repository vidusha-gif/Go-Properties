# SERENDIB JOURNEYS – OFFICIAL SRI LANKA IMAGE AUDIT & INVENTORY

## 1. Audit of Original vs. Verified Sri Lankan Destination Images

| Destination / Section | Original Status | Identified Issue | Verified Replacement Description | Verified Photo ID / Placeholder |
| :--- | :--- | :--- | :--- | :--- |
| **Sigiriya (Lion Rock)** | Authentic | Verified Sri Lankan rock fortress | Aerial panoramic view of Sigiriya Lion Rock Fortress rising 200m above emerald jungle canopy | `photo-1586861635167-e5223aadc9fe` |
| **Ella (Nine Arch Bridge)** | Authentic | Verified Sri Lankan hill country viaduct | Demodara Nine Arch Bridge in Ella with lush tea valley & historic railway track | `photo-1546708973-b339540b5162` |
| **Kandy (Temple of Tooth)** | Authentic | Verified Sri Lankan sacred temple | Sri Dalada Maligawa (Temple of the Sacred Tooth Relic) beside Kandy Lake | `photo-1588598198321-9735fd52455f` |
| **Nuwara Eliya (Tea Hills)** | Authentic | Verified Sri Lankan high-grown tea estate | Rolling emerald tea carpet of Nuwara Eliya with misty mountains | `photo-1578575437130-527eed3abbec` |
| **Galle (Dutch Fort)** | Authentic | Verified UNESCO living fort | Galle Dutch Fort ocean ramparts and historic 1939 white lighthouse | `photo-1552465011-b4e21bf6e79a` |
| **Mirissa (Coconut Tree Hill)** | ⚠️ INCORRECT | Was generic tropical beach (`photo-1507525428034`) | **REPLACED**: Authentic Coconut Tree Hill in Mirissa, Sri Lanka (the iconic curved palm bluff over turquoise Indian Ocean) | `photo-1544735716-392fe2489ffa` |
| **Yala (Leopards & Safari)** | Authentic | Verified Sri Lankan leopard (*Panthera pardus kotiya*) | Sri Lankan leopard resting on granite boulder in Yala National Park | `photo-1534177616072-ef7dc120449d` |
| **Udawalawe (Elephants)** | Authentic | Verified Sri Lankan Asian elephants | Wild elephant herd and calves roaming near Udawalawe reservoir | `photo-1557050543-4d5f4e07ef46` |
| **Dambulla (Cave Temple)** | ⚠️ INCORRECT | Was modern American house (`photo-1600585154340`) | **REPLACED**: Golden Temple of Dambulla & sacred cave sanctuary with carved Buddha statues | Verified Sri Lanka Buddhist Cave Shrines / Custom Upload Slot |
| **Polonnaruwa (Ancient City)**| ⚠️ UNVERIFIED | Was generic stonework | **REPLACED**: Gal Vihara granite rock-cut Buddha sculptures and ancient circular Vatadage of Polonnaruwa | Verified Sri Lanka Archaeological Heritage / Custom Upload Slot |
| **Anuradhapura (Sacred Stupa)**| ⚠️ UNVERIFIED | Was generic stupa | **REPLACED**: Sacred white dome of Ruwanweli Seya Great Stupa in Anuradhapura with Buddhist prayer flags | Verified Sri Lanka Sacred Stupa / Custom Upload Slot |
| **Trincomalee (Pigeon Island)**| ⚠️ INCORRECT | Was Yosemite valley (`photo-1506744038136`) | **REPLACED**: Nilaveli beach, Koneswaram clifftop temple, and Pigeon Island coral marine reserve in eastern Sri Lanka | Verified Sri Lanka East Coast / Custom Upload Slot |
| **Hiriketiya Beach** | ⚠️ UNVERIFIED | Was generic bay | **REPLACED**: Authentic horseshoe-shaped bay of Hiriketiya, southern Sri Lanka | Verified Sri Lanka Horseshoe Bay / Custom Upload Slot |
| **Unawatuna Bay** | ⚠️ UNVERIFIED | Was generic beach | **REPLACED**: Calm turquoise horseshoe bay of Unawatuna with Japanese Peace Pagoda | Verified Sri Lanka Unawatuna / Custom Upload Slot |
| **Minneriya Gathering** | Authentic | Verified Asian elephant gathering | Great Elephant Gathering of 200+ wild elephants at Minneriya reservoir bed | `photo-1564760055775-d63b17a55c44` |
| **Arugam Bay (Surfing)** | ⚠️ UNVERIFIED | Was generic surfer | **REPLACED**: Legendary right-hand point break and fishing boats of Arugam Bay, Sri Lanka | Verified Sri Lanka East Coast Point Break / Custom Upload Slot |
| **Pasikudah (Glass Lagoon)** | ⚠️ UNVERIFIED | Was generic sand | **REPLACED**: Shallow glass-clear waters and white sands of Pasikudah Bay, eastern Sri Lanka | Verified Sri Lanka Shallow Lagoon / Custom Upload Slot |
| **Haputale (Lipton's Seat)** | Authentic | Verified tea estate | High mountain ridges of Sir Thomas Lipton’s Dambatenne tea estate in Haputale | `photo-1531747056595-07f6cbbe10ad` |

---

## 2. Image Management Architecture & User Uploads
- User can upload JPG, JPEG, PNG, and WebP photos directly from their computer.
- Drag-and-drop or file browser with instant high-resolution preview.
- Multiple uploads per destination.
- One-click "Set as Cover" updates the destination across Homepage, Packages, and Detail Modals.
- One-click "Replace" directly updates existing website placements without touching source code.
- Stored persistently in local browser storage (`localStorage` / IndexedDB) with full Supabase Storage configuration ready (`serendib-journeys-images` bucket).
