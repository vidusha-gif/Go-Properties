import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Heart,
  Scale,
  Phone,
  MessageCircle,
  Menu,
  X,
  ChevronDown,
  ShieldCheck,
  Compass,
  ArrowUpRight
} from 'lucide-react';
import { useRealEstate } from '../../context/RealEstateContext';
import { generateWhatsAppLink } from '../../utils/helpers';

export const Navbar: React.FC = () => {
  const { siteSettings, favorites, compareList } = useRealEstate();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [propertiesDropdownOpen, setPropertiesDropdownOpen] = useState(false);
  const location = useLocation();

  // Scroll detection
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 25);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
    setPropertiesDropdownOpen(false);
  }, [location.pathname, location.search]);

  // Only the Homepage has the full-bleed dark hero image; inner pages use solid clean nav
  const isDarkHeroPage = location.pathname === '/';
  const hasSolidNav = isScrolled || !isDarkHeroPage;

  const whatsappHref = generateWhatsAppLink(
    siteSettings.whatsappNumber,
    `Hello, I would like to inquire about luxury property advisory services with ${siteSettings.companyName}.`
  );

  return (
    <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-300">
      {/* Top micro-bar: Minimal, Deep Navy with subtle muted pink accent */}
      <div className="hidden lg:block bg-navy text-cool-400 text-[11px] border-b border-white/5 py-1.5 px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-5">
            <span className="flex items-center space-x-1.5 text-cool-300 font-normal">
              <span className="w-1.5 h-1.5 rounded-full bg-pink-muted"></span>
              <span>Prime International Residences & Private Mandates</span>
            </span>
            <span className="text-white/10">|</span>
            <span className="text-cool-400 flex items-center">
              <Compass className="w-3 h-3 text-cool-400 mr-1" />
              <span>London • Dubai • Los Angeles • French Riviera • Zurich</span>
            </span>
          </div>

          <div className="flex items-center space-x-5">
            <a
              href={`tel:${siteSettings.phone.replace(/[^0-9+]/g, '')}`}
              className="flex items-center space-x-1.5 text-cool-400 hover:text-white transition-colors"
            >
              <Phone className="w-3 h-3 text-cool-400" />
              <span>{siteSettings.phone}</span>
            </a>
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-1.5 text-cool-400 hover:text-pink-muted transition-colors"
            >
              <MessageCircle className="w-3 h-3 text-pink-muted" />
              <span>WhatsApp Concierge</span>
            </a>
            <Link
              to="/admin/login"
              className="flex items-center space-x-1 text-cool-400 hover:text-white transition-colors"
              title="Admin Portal"
            >
              <ShieldCheck className="w-3 h-3" />
              <span>Admin</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Main navigation bar: Solid clean white on inner pages / scrolled, transparent over homepage hero */}
      <nav
        className={`w-full transition-all duration-300 ${
          hasSolidNav
            ? 'bg-white/95 backdrop-blur-md py-3 shadow-[0_2px_15px_rgba(16,27,51,0.04)] border-b border-cool-200/70 text-cool-900'
            : 'bg-gradient-to-b from-black/60 via-black/25 to-transparent py-4 text-white'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Refined Minimal Logo */}
          <Link to="/" className="group flex items-center space-x-2.5 text-left">
            <div className={`w-7 h-7 flex items-center justify-center border transition-all duration-300 ${
              hasSolidNav 
                ? 'border-navy text-navy group-hover:bg-navy group-hover:text-white' 
                : 'border-white/40 text-white group-hover:border-pink-muted group-hover:text-pink-muted'
            }`}>
              <span className="font-serif text-sm font-semibold tracking-wider">A</span>
            </div>
            <div>
              <span className={`font-serif tracking-[0.24em] text-sm font-medium uppercase block transition-colors ${
                hasSolidNav ? 'text-navy group-hover:text-black' : 'text-white group-hover:text-pink-muted'
              }`}>
                {siteSettings.logoText}
              </span>
              <span className="text-[7.5px] uppercase tracking-[0.3em] text-cool-400 block -mt-1 font-light">
                Private Estates
              </span>
            </div>
          </Link>

          {/* Desktop Nav Links - Compact & Refined */}
          <div className="hidden lg:flex items-center space-x-7 text-xs font-normal tracking-wide">
            <Link
              to="/"
              className={`transition-colors py-1 relative ${
                location.pathname === '/' 
                  ? (hasSolidNav ? 'text-navy font-medium' : 'text-white font-medium') 
                  : (hasSolidNav ? 'text-cool-600 hover:text-navy' : 'text-stone-200 hover:text-white')
              }`}
            >
              Home
              {location.pathname === '/' && (
                <span className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-pink-muted rounded-full"></span>
              )}
            </Link>

            {/* Properties Dropdown */}
            <div
              className="relative"
              onMouseEnter={() => setPropertiesDropdownOpen(true)}
              onMouseLeave={() => setPropertiesDropdownOpen(false)}
            >
              <button
                className={`flex items-center space-x-1 py-1 transition-colors ${
                  location.pathname.startsWith('/properties')
                    ? (hasSolidNav ? 'text-navy font-medium' : 'text-white font-medium')
                    : (hasSolidNav ? 'text-cool-600 hover:text-navy' : 'text-stone-200 hover:text-white')
                }`}
              >
                <span>Properties</span>
                <ChevronDown className="w-3 h-3 opacity-60" />
              </button>

              {propertiesDropdownOpen && (
                <div className="absolute top-full -left-2 w-56 bg-white border border-cool-200/90 shadow-[0_12px_30px_rgba(16,27,51,0.08)] py-2 rounded-sm animate-in fade-in slide-in-from-top-1 duration-150 z-50">
                  <Link
                    to="/properties"
                    className="block px-4 py-2 text-cool-700 hover:text-navy hover:bg-cool-50 transition-colors text-xs"
                  >
                    All Properties
                  </Link>
                  <Link
                    to="/properties?purpose=sale"
                    className="block px-4 py-2 text-cool-700 hover:text-navy hover:bg-cool-50 transition-colors text-xs"
                  >
                    Buy Residences
                  </Link>
                  <Link
                    to="/properties?purpose=rent"
                    className="block px-4 py-2 text-cool-700 hover:text-navy hover:bg-cool-50 transition-colors text-xs"
                  >
                    Rent Residences
                  </Link>
                  <Link
                    to="/properties?tag=luxury"
                    className="block px-4 py-2 text-cool-700 hover:text-navy hover:bg-cool-50 transition-colors text-xs"
                  >
                    Trophy & Luxury Estates
                  </Link>
                  <div className="border-t border-cool-100 my-1"></div>
                  <Link
                    to="/properties?type=commercial"
                    className="block px-4 py-2 text-cool-700 hover:text-navy hover:bg-cool-50 transition-colors text-xs"
                  >
                    Commercial Assets
                  </Link>
                  <Link
                    to="/properties?type=land"
                    className="block px-4 py-2 text-cool-700 hover:text-navy hover:bg-cool-50 transition-colors text-xs"
                  >
                    Development Land
                  </Link>
                </div>
              )}
            </div>

            <Link
              to="/locations"
              className={`transition-colors py-1 ${
                location.pathname.startsWith('/locations')
                  ? (hasSolidNav ? 'text-navy font-medium' : 'text-white font-medium')
                  : (hasSolidNav ? 'text-cool-600 hover:text-navy' : 'text-stone-200 hover:text-white')
              }`}
            >
              Destinations
            </Link>

            <Link
              to="/sell"
              className={`transition-colors py-1 ${
                location.pathname === '/sell'
                  ? (hasSolidNav ? 'text-navy font-medium' : 'text-white font-medium')
                  : (hasSolidNav ? 'text-cool-600 hover:text-navy' : 'text-stone-200 hover:text-white')
              }`}
            >
              Sell With Us
            </Link>

            <Link
              to="/blog"
              className={`transition-colors py-1 ${
                location.pathname.startsWith('/blog')
                  ? (hasSolidNav ? 'text-navy font-medium' : 'text-white font-medium')
                  : (hasSolidNav ? 'text-cool-600 hover:text-navy' : 'text-stone-200 hover:text-white')
              }`}
            >
              Editorial
            </Link>

            <Link
              to="/about"
              className={`transition-colors py-1 ${
                location.pathname === '/about'
                  ? (hasSolidNav ? 'text-navy font-medium' : 'text-white font-medium')
                  : (hasSolidNav ? 'text-cool-600 hover:text-navy' : 'text-stone-200 hover:text-white')
              }`}
            >
              About
            </Link>

            <Link
              to="/contact"
              className={`transition-colors py-1 ${
                location.pathname === '/contact'
                  ? (hasSolidNav ? 'text-navy font-medium' : 'text-white font-medium')
                  : (hasSolidNav ? 'text-cool-600 hover:text-navy' : 'text-stone-200 hover:text-white')
              }`}
            >
              Contact
            </Link>
          </div>

          {/* Right Action Icons & Compact CTA */}
          <div className="hidden lg:flex items-center space-x-4">
            {/* Compare Badge */}
            <Link
              to="/compare"
              className={`relative p-1.5 transition-colors ${
                hasSolidNav ? 'text-cool-500 hover:text-navy' : 'text-stone-300 hover:text-white'
              }`}
              title="Compare Properties"
            >
              <Scale className="w-4 h-4" />
              {compareList.length > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-navy text-white text-[9px] font-semibold w-3.5 h-3.5 rounded-full flex items-center justify-center border border-white">
                  {compareList.length}
                </span>
              )}
            </Link>

            {/* Favorites Badge */}
            <Link
              to="/favorites"
              className={`relative p-1.5 transition-colors ${
                hasSolidNav ? 'text-cool-500 hover:text-navy' : 'text-stone-300 hover:text-white'
              }`}
              title="Saved Properties"
            >
              <Heart className="w-4 h-4" />
              {favorites.length > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-pink-muted text-navy text-[9px] font-bold w-3.5 h-3.5 rounded-full flex items-center justify-center">
                  {favorites.length}
                </span>
              )}
            </Link>

            {/* Refined Compact CTA */}
            <Link
              to="/sell"
              className={`inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-sm text-[11px] uppercase tracking-wider font-medium transition-all duration-200 border ${
                hasSolidNav
                  ? 'bg-navy text-white hover:bg-navy-midnight border-navy'
                  : 'bg-white/10 hover:bg-white text-white hover:text-navy border-white/30 backdrop-blur-sm'
              }`}
            >
              <span>List Property</span>
              <ArrowUpRight className="w-3 h-3" />
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex lg:hidden items-center space-x-2.5">
            <Link
              to="/favorites"
              className={`relative p-1 ${hasSolidNav ? 'text-navy' : 'text-white'}`}
            >
              <Heart className="w-4 h-4" />
              {favorites.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-pink-muted text-navy text-[8px] font-bold w-3.5 h-3.5 rounded-full flex items-center justify-center">
                  {favorites.length}
                </span>
              )}
            </Link>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`p-1.5 focus:outline-none ${hasSolidNav ? 'text-navy' : 'text-white'}`}
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer - Minimal Clean Layout */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white text-cool-900 border-b border-cool-200 px-6 py-6 space-y-3.5 shadow-xl animate-in slide-in-from-top-2 duration-200 max-h-[85vh] overflow-y-auto">
          <Link
            to="/"
            className="block text-xs uppercase tracking-wider font-medium text-cool-800 hover:text-navy py-1.5 border-b border-cool-100"
          >
            Home
          </Link>
          <div className="py-1.5 border-b border-cool-100">
            <div className="text-[10px] uppercase tracking-widest text-cool-400 font-semibold mb-1.5">
              Properties
            </div>
            <div className="pl-2 space-y-1.5 text-xs text-cool-700">
              <Link to="/properties" className="block hover:text-navy">All Properties</Link>
              <Link to="/properties?purpose=sale" className="block hover:text-navy">Buy Residences</Link>
              <Link to="/properties?purpose=rent" className="block hover:text-navy">Rent Residences</Link>
              <Link to="/properties?tag=luxury" className="block hover:text-navy">Trophy Estates</Link>
              <Link to="/properties?type=commercial" className="block hover:text-navy">Commercial</Link>
              <Link to="/properties?type=land" className="block hover:text-navy">Development Land</Link>
            </div>
          </div>
          <Link
            to="/locations"
            className="block text-xs uppercase tracking-wider font-medium text-cool-800 hover:text-navy py-1.5 border-b border-cool-100"
          >
            Destinations
          </Link>
          <Link
            to="/sell"
            className="block text-xs uppercase tracking-wider font-medium text-cool-800 hover:text-navy py-1.5 border-b border-cool-100"
          >
            Sell With Us
          </Link>
          <Link
            to="/blog"
            className="block text-xs uppercase tracking-wider font-medium text-cool-800 hover:text-navy py-1.5 border-b border-cool-100"
          >
            Editorial
          </Link>
          <Link
            to="/about"
            className="block text-xs uppercase tracking-wider font-medium text-cool-800 hover:text-navy py-1.5 border-b border-cool-100"
          >
            About Us
          </Link>
          <Link
            to="/contact"
            className="block text-xs uppercase tracking-wider font-medium text-cool-800 hover:text-navy py-1.5 border-b border-cool-100"
          >
            Contact
          </Link>
          <Link
            to="/admin/login"
            className="block text-xs uppercase tracking-wider font-medium text-navy hover:text-black py-1.5 border-b border-cool-100"
          >
            Admin Portal
          </Link>

          <div className="pt-2 flex flex-col space-y-2">
            <Link
              to="/sell"
              className="w-full text-center bg-navy text-white py-2 text-xs uppercase tracking-wider font-medium rounded-sm"
            >
              List Your Property
            </Link>
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full text-center border border-cool-200 text-cool-700 py-2 text-xs uppercase tracking-wider font-medium rounded-sm flex items-center justify-center space-x-1.5"
            >
              <MessageCircle className="w-3.5 h-3.5 text-pink-muted" />
              <span>WhatsApp Concierge</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
