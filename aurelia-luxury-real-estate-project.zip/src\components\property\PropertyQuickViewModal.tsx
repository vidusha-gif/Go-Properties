import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  X,
  Bed,
  Bath,
  Maximize2,
  MapPin,
  Heart,
  Scale,
  MessageCircle,
  Calendar,
  ArrowRight,
  Check
} from 'lucide-react';
import { useRealEstate } from '../../context/RealEstateContext';
import { formatPrice, generateWhatsAppLink } from '../../utils/helpers';

export const PropertyQuickViewModal: React.FC = () => {
  const {
    quickViewProperty,
    closeQuickView,
    siteSettings,
    isFavorite,
    toggleFavorite,
    isInCompare,
    toggleCompare,
    addLead
  } = useRealEstate();

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [showViewingForm, setShowViewingForm] = useState(false);
  const [viewingFormSubmitted, setViewingFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    preferredDate: '',
    preferredTime: '',
    message: ''
  });

  if (!quickViewProperty) return null;

  const favorite = isFavorite(quickViewProperty.id);
  const inCompare = isInCompare(quickViewProperty.id);

  const images = [
    quickViewProperty.featuredImage,
    ...(quickViewProperty.galleryImages || [])
  ].filter((img, idx, arr) => arr.indexOf(img) === idx);

  const whatsappMsg = `Hello, I am reviewing the quick specs for ${quickViewProperty.title} (${quickViewProperty.referenceId}) and would like to arrange a private consultation.`;
  const whatsappUrl = generateWhatsAppLink(siteSettings.whatsappNumber, whatsappMsg);

  const handleViewingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addLead({
      type: 'property_viewing',
      propertyId: quickViewProperty.id,
      propertyTitle: quickViewProperty.title,
      propertyRef: quickViewProperty.referenceId,
      customerName: formData.name,
      email: formData.email,
      phone: formData.phone,
      preferredDate: formData.preferredDate,
      preferredTime: formData.preferredTime,
      message: formData.message || 'Requested private viewing via Quick View.',
      source: 'Quick View Modal'
    });
    setViewingFormSubmitted(true);
    setTimeout(() => {
      setViewingFormSubmitted(false);
      setShowViewingForm(false);
    }, 4000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-150">
      <div className="relative bg-white rounded-sm max-w-3xl w-full shadow-2xl border border-cool-200 overflow-hidden my-6">
        {/* Close Button */}
        <button
          onClick={closeQuickView}
          className="absolute top-3 right-3 z-20 w-8 h-8 rounded-full bg-black/50 hover:bg-black/80 text-white flex items-center justify-center transition-colors"
          aria-label="Close modal"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 max-h-[85vh] overflow-y-auto">
          {/* Left Column: Media Gallery */}
          <div className="md:col-span-6 bg-navy flex flex-col justify-between p-4">
            <div className="relative aspect-[4/3] w-full overflow-hidden rounded-sm bg-black">
              <img
                src={images[activeImageIndex] || quickViewProperty.featuredImage}
                alt={quickViewProperty.title}
                className="w-full h-full object-cover transition-all duration-300"
              />
              <div className="absolute top-2.5 left-2.5 flex flex-wrap gap-1">
                <span className="px-2 py-0.5 text-[9px] font-semibold uppercase bg-navy text-white rounded-sm">
                  {quickViewProperty.purpose === 'sale' ? 'For Sale' : 'For Rent'}
                </span>
                {quickViewProperty.isLuxury && (
                  <span className="px-2 py-0.5 text-[9px] font-semibold uppercase bg-pink-soft text-navy border border-pink-muted/60 rounded-sm">
                    Luxury
                  </span>
                )}
              </div>
            </div>

            {/* Thumbnail selector */}
            {images.length > 1 && (
              <div className="flex items-center space-x-1.5 mt-2.5 overflow-x-auto pb-1">
                {images.slice(0, 5).map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-14 h-10 rounded-sm overflow-hidden flex-shrink-0 border transition-all ${
                      activeImageIndex === idx ? 'border-pink-muted scale-105' : 'border-transparent opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="thumb" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Details & Actions */}
          <div className="md:col-span-6 p-5 sm:p-6 flex flex-col justify-between bg-white">
            <div>
              <div className="flex items-center justify-between text-[11px] text-cool-400 mb-1.5">
                <span className="uppercase tracking-wider font-medium text-navy">
                  {quickViewProperty.type} • Ref: {quickViewProperty.referenceId}
                </span>
                <div className="flex items-center space-x-1.5">
                  <button
                    onClick={() => toggleFavorite(quickViewProperty.id)}
                    className={`p-1 rounded-sm border transition-colors ${
                      favorite ? 'bg-pink-soft border-pink-muted text-navy' : 'border-cool-200 text-cool-400 hover:text-navy'
                    }`}
                    title="Save"
                  >
                    <Heart className={`w-3.5 h-3.5 ${favorite ? 'fill-current' : ''}`} />
                  </button>
                  <button
                    onClick={() => toggleCompare(quickViewProperty.id)}
                    className={`p-1 rounded-sm border transition-colors ${
                      inCompare ? 'bg-navy text-white border-navy' : 'border-cool-200 text-cool-400 hover:text-navy'
                    }`}
                    title="Compare"
                  >
                    <Scale className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <h2 className="font-serif text-xl sm:text-2xl font-medium text-cool-900 mb-1">
                {quickViewProperty.title}
              </h2>

              <div className="flex items-center text-[11px] text-cool-400 mb-3">
                <MapPin className="w-3 h-3 text-pink-muted mr-1" />
                <span>
                  {quickViewProperty.location.area}, {quickViewProperty.location.city}
                </span>
              </div>

              <div className="bg-cool-50 border border-cool-200/60 p-3 rounded-sm mb-3">
                <span className="text-[10px] uppercase tracking-wider text-cool-400 block -mb-0.5">
                  {quickViewProperty.pricePrefix || 'Price'}
                </span>
                <span className="font-serif text-2xl font-medium text-navy">
                  {formatPrice(
                    quickViewProperty.price,
                    siteSettings.currencySymbol,
                    quickViewProperty.rentalPeriod
                  )}
                </span>
              </div>

              {/* Specs Pills */}
              <div className="grid grid-cols-3 gap-1.5 py-2.5 border-t border-b border-cool-100 text-xs text-cool-700 mb-3">
                <div className="flex items-center space-x-1.5">
                  <Bed className="w-3.5 h-3.5 text-cool-400" />
                  <span>{quickViewProperty.bedrooms} Beds</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <Bath className="w-3.5 h-3.5 text-cool-400" />
                  <span>{quickViewProperty.bathrooms} Baths</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <Maximize2 className="w-3.5 h-3.5 text-cool-400" />
                  <span>{quickViewProperty.floorAreaSqFt.toLocaleString()} sqft</span>
                </div>
              </div>

              <p className="text-xs text-cool-500 line-clamp-3 leading-relaxed mb-4 font-light">
                {quickViewProperty.description}
              </p>
            </div>

            {/* Private Viewing Form or Action Buttons */}
            {showViewingForm ? (
              <div className="border-t border-cool-100 pt-3 animate-in fade-in">
                {viewingFormSubmitted ? (
                  <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-sm text-center">
                    <Check className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
                    <p className="text-xs font-medium">Viewing Request Lodged</p>
                  </div>
                ) : (
                  <form onSubmit={handleViewingSubmit} className="space-y-2 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-cool-700">
                        Private Viewing Request
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowViewingForm(false)}
                        className="text-cool-400 hover:text-cool-700 text-xs"
                      >
                        Cancel
                      </button>
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      <input
                        type="text"
                        required
                        placeholder="Your Name"
                        value={formData.name}
                        onChange={e => setFormData({ ...formData, name: e.target.value })}
                        className="border border-cool-200 p-1.5 text-xs rounded-sm focus:border-navy focus:outline-none"
                      />
                      <input
                        type="email"
                        required
                        placeholder="Email Address"
                        value={formData.email}
                        onChange={e => setFormData({ ...formData, email: e.target.value })}
                        className="border border-cool-200 p-1.5 text-xs rounded-sm focus:border-navy focus:outline-none"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      <input
                        type="tel"
                        required
                        placeholder="Phone"
                        value={formData.phone}
                        onChange={e => setFormData({ ...formData, phone: e.target.value })}
                        className="border border-cool-200 p-1.5 text-xs rounded-sm focus:border-navy focus:outline-none"
                      />
                      <input
                        type="date"
                        required
                        value={formData.preferredDate}
                        onChange={e => setFormData({ ...formData, preferredDate: e.target.value })}
                        className="border border-cool-200 p-1.5 text-xs rounded-sm focus:border-navy focus:outline-none"
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full bg-navy hover:bg-navy-midnight text-white py-1.5 text-[11px] uppercase tracking-wider font-medium rounded-sm transition-colors"
                    >
                      Confirm Viewing
                    </button>
                  </form>
                )}
              </div>
            ) : (
              <div className="border-t border-cool-100 pt-3 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="border border-cool-200 text-cool-700 hover:border-navy hover:text-navy py-2 px-3 rounded-sm text-[11px] font-medium uppercase tracking-wider flex items-center justify-center space-x-1.5 transition-colors"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-pink-muted" />
                    <span>WhatsApp</span>
                  </a>
                  <button
                    onClick={() => setShowViewingForm(true)}
                    className="border border-navy text-navy hover:bg-navy hover:text-white py-2 px-3 rounded-sm text-[11px] font-medium uppercase tracking-wider flex items-center justify-center space-x-1.5 transition-colors"
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Book Viewing</span>
                  </button>
                </div>

                <Link
                  to={`/property/${quickViewProperty.id}`}
                  onClick={closeQuickView}
                  className="w-full bg-navy hover:bg-navy-midnight text-white py-2.5 px-4 rounded-sm text-[11px] font-medium uppercase tracking-wider flex items-center justify-center space-x-1.5 transition-colors"
                >
                  <span>Explore Full Presentation</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
