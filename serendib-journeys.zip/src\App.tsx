import React, { useState, useEffect, useRef } from 'react';
import { INITIAL_PACKAGES } from './data/packages';
import { INITIAL_DESTINATIONS } from './data/destinations';
import { INITIAL_EXPERIENCES } from './data/experiences';
import { INITIAL_VEHICLES } from './data/vehicles';
import { DEFAULT_MEDIA_REGISTRY } from './data/mediaRegistry';
import { INITIAL_TESTIMONIALS } from './data/testimonials';
import { TourPackage, Destination, Vehicle, Inquiry, WebsiteSettings, MediaRegistry, SupabaseConfig } from './types';

export const CURRENCIES = {
  USD: { symbol: '$', rate: 1, label: 'USD ($)' },
  EUR: { symbol: '€', rate: 0.92, label: 'EUR (€)' },
  GBP: { symbol: '£', rate: 0.79, label: 'GBP (£)' },
  AUD: { symbol: 'A$', rate: 1.52, label: 'AUD (A$)' },
  INR: { symbol: '₹', rate: 84.5, label: 'INR (₹)' },
  LKR: { symbol: 'Rs', rate: 305, label: 'LKR (Rs)' }
};

export default function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'about' | 'destinations' | 'experiences' | 'packages' | 'transport' | 'gallery' | 'contact' | 'admin'>('home');
  const [currency, setCurrency] = useState<keyof typeof CURRENCIES>('USD');
  const [language, setLanguage] = useState('EN');

  // Media Registry
  const [mediaRegistry, setMediaRegistry] = useState<MediaRegistry>(() => {
    try {
      const saved = localStorage.getItem('serendib_media_registry');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return DEFAULT_MEDIA_REGISTRY;
  });

  const [packages, setPackages] = useState<TourPackage[]>(() => {
    try {
      const saved = localStorage.getItem('serendib_packages');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_PACKAGES;
  });

  const [destinations] = useState<Destination[]>(INITIAL_DESTINATIONS);
  const [vehicles] = useState<Vehicle[]>(INITIAL_VEHICLES);
  const [testimonials] = useState(INITIAL_TESTIMONIALS);

  const [inquiries, setInquiries] = useState<Inquiry[]>(() => {
    try {
      const saved = localStorage.getItem('serendib_inquiries');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [
      {
        id: 'SJ-9241',
        createdAt: '2026-11-17T10:15:00Z',
        name: 'Oliver Harris',
        email: 'oliver.harris@ukmail.co.uk',
        phone: '+44 7911 123456',
        country: 'United Kingdom',
        travelDate: '2027-01-15',
        travelers: '2 Adults',
        packageInterested: '7 Days – Island Highlights',
        budget: 'Luxury',
        transport: 'Sedan Car with Private Chauffeur',
        status: 'Quoted',
        message: 'Looking for a private honeymoon itinerary with luxury boutique stays in Ella and Galle.'
      }
    ];
  });

  const [settings] = useState<WebsiteSettings>({
    whatsappNumber: '+94771234567',
    whatsappDisplay: '+94 77 123 4567',
    email: 'hello@serendibjourneys.com',
    phone: '+94 11 234 5678',
    address: 'No. 45/2, Galle Road, Colombo 03, Sri Lanka',
    businessHours: '24/7 Dedicated Concierge Support'
  });

  const [supabaseConfig, setSupabaseConfig] = useState<SupabaseConfig>(() => {
    try {
      const saved = localStorage.getItem('serendib_supabase_config');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      url: '',
      anonKey: '',
      bucketName: 'serendib-journeys-images',
      connected: false
    };
  });

  const [selectedCategory, setSelectedCategory] = useState<string>('sigiriya');
  const [adminPasscode, setAdminPasscode] = useState('');
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [planTripModalOpen, setPlanTripModalOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('serendib_media_registry', JSON.stringify(mediaRegistry));
    } catch (e) {}
  }, [mediaRegistry]);

  const formatPrice = (usd: number) => {
    const curr = CURRENCIES[currency] || CURRENCIES.USD;
    return `${curr.symbol} ${Math.round(usd * curr.rate).toLocaleString()}`;
  };

  const getMediaCover = (key: string): string => {
    const list = mediaRegistry[key];
    if (list && list.length > 0) {
      const cover = list.find(img => img.isCover) || list[0];
      return cover.url;
    }
    return 'https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?auto=format&fit=crop&w=1200&q=80';
  };

  const getWhatsAppUrl = (customText?: string) => {
    const cleanNumber = settings.whatsappNumber.replace(/[^0-9]/g, '');
    const text = encodeURIComponent(customText || "Hello SERENDIB JOURNEYS! I am interested in planning a trip to Sri Lanka. Could you please provide more information?");
    return `https://wa.me/${cleanNumber}?text=${text}`;
  };

  return (
    <div className="min-h-screen flex flex-col bg-cream text-charcoal">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-tropical-deep/95 backdrop-blur-md border-b border-gold/20 shadow-luxury h-20 flex items-center justify-between px-4 sm:px-8">
        <div 
          className="flex items-center gap-3 cursor-pointer"
          onClick={() => { setCurrentPage('home'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
        >
          <div className="w-10 h-10 rounded-full gold-gradient p-0.5 flex items-center justify-center">
            <div className="w-full h-full rounded-full bg-tropical-deep flex items-center justify-center">
              <svg viewBox="0 0 100 100" className="w-6 h-6 text-gold fill-current">
                <path d="M50 15 C44 28 32 38 22 52 C35 55 45 46 50 30 C55 46 65 55 78 52 C68 38 56 28 50 15 Z" fill="#D6AD60"/>
                <circle cx="50" cy="65" r="7" fill="#FAF8F2"/>
              </svg>
            </div>
          </div>
          <div>
            <span className="font-serif text-xl font-bold text-cream">SERENDIB <span className="font-sans font-light text-gold">JOURNEYS</span></span>
            <p className="text-[10px] tracking-widest text-cream/70 uppercase">Discover Sri Lanka</p>
          </div>
        </div>

        <nav className="hidden lg:flex items-center gap-6 text-sm">
          {['home', 'about', 'destinations', 'packages', 'transport', 'gallery', 'contact', 'admin'].map((page) => (
            <button
              key={page}
              onClick={() => setCurrentPage(page as any)}
              className={`capitalize ${currentPage === page ? 'text-gold font-bold' : 'text-cream/80 hover:text-gold'}`}
            >
              {page === 'admin' ? '📸 Media Library' : page}
            </button>
          ))}
        </nav>

        <button
          onClick={() => setPlanTripModalOpen(true)}
          className="gold-gradient text-tropical-deep font-bold text-xs px-5 py-2.5 rounded-full"
        >
          Plan Your Trip
        </button>
      </header>

      {/* Main Pages */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <div>
            <section className="relative min-h-[85vh] flex items-center justify-center bg-tropical-deep">
              <img
                src={getMediaCover('hero')}
                alt="Sigiriya Lion Rock Sri Lanka"
                className="absolute inset-0 w-full h-full object-cover opacity-80"
              />
              <div className="relative z-10 text-center max-w-4xl px-4 text-cream">
                <h1 className="font-serif text-5xl sm:text-7xl font-bold mb-4">
                  Discover the Magic of <span className="text-gold">Sri Lanka</span>
                </h1>
                <p className="text-lg text-cream/90 max-w-2xl mx-auto mb-8">
                  From golden beaches and misty mountains to ancient kingdoms and unforgettable wildlife encounters.
                </p>
                <div className="flex justify-center gap-4">
                  <button onClick={() => setCurrentPage('destinations')} className="px-6 py-3 rounded-full bg-white/20 text-cream font-bold">
                    Explore Destinations
                  </button>
                  <button onClick={() => setPlanTripModalOpen(true)} className="px-6 py-3 rounded-full gold-gradient text-tropical-deep font-bold">
                    Plan Your Journey
                  </button>
                </div>
              </div>
            </section>

            {/* Destinations Preview with Live Covers */}
            <section className="py-20 max-w-7xl mx-auto px-4">
              <h2 className="font-serif text-3xl font-bold text-tropical-deep text-center mb-10">Authentic Sri Lankan Destinations</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {destinations.slice(0, 8).map((dest) => (
                  <div key={dest.id} className="bg-white rounded-2xl overflow-hidden shadow-card border border-charcoal/10">
                    <img src={getMediaCover(dest.imageKey)} alt={dest.name} className="h-48 w-full object-cover" />
                    <div className="p-4">
                      <span className="text-[10px] text-emerald font-bold uppercase">{dest.region}</span>
                      <h3 className="font-serif text-xl font-bold text-tropical-deep mt-1">{dest.name}</h3>
                      <p className="text-xs text-charcoal/70 line-clamp-2 mt-1">{dest.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>
        )}

        {/* Media Manager Tab */}
        {currentPage === 'admin' && (
          <div className="py-12 max-w-7xl mx-auto px-4">
            <div className="bg-white p-8 rounded-3xl shadow-card border border-charcoal/10">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <span className="text-xs font-bold text-emerald uppercase tracking-wider">Image Management Suite</span>
                  <h2 className="font-serif text-3xl font-bold text-tropical-deep mt-1">Image Library & Upload System</h2>
                </div>
                <button
                  onClick={() => {
                    setMediaRegistry(DEFAULT_MEDIA_REGISTRY);
                    alert('Reset to verified Sri Lankan destination images.');
                  }}
                  className="px-4 py-2 text-xs font-semibold rounded-xl bg-tropical-subtle text-tropical-deep"
                >
                  Reset to Verified Defaults
                </button>
              </div>

              {/* Destination Selector */}
              <div className="flex flex-wrap gap-2 mb-6">
                {Object.keys(mediaRegistry).map((key) => (
                  <button
                    key={key}
                    onClick={() => setSelectedCategory(key)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold uppercase ${
                      selectedCategory === key ? 'bg-tropical-deep text-gold' : 'bg-cream text-charcoal/70'
                    }`}
                  >
                    {key} ({(mediaRegistry[key] || []).length})
                  </button>
                ))}
              </div>

              {/* Upload & Current Images */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {(mediaRegistry[selectedCategory] || []).map((img) => (
                  <div key={img.id} className="border rounded-2xl overflow-hidden shadow-sm">
                    <img src={img.url} alt={img.title} className="h-48 w-full object-cover" />
                    <div className="p-4">
                      <h4 className="font-bold text-sm text-tropical-deep">{img.title}</h4>
                      <p className="text-xs text-charcoal/60 mt-1">{img.alt}</p>
                      {img.isCover && <span className="inline-block mt-2 text-[10px] bg-gold/20 text-tropical-deep font-bold px-2 py-0.5 rounded">Main Cover</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-tropical-deep text-cream py-10 text-center text-xs border-t border-gold/20">
        <p className="font-serif text-lg font-bold">SERENDIB JOURNEYS</p>
        <p className="text-gold mt-1">"Discover Sri Lanka. Experience the Extraordinary."</p>
      </footer>
    </div>
  );
}
