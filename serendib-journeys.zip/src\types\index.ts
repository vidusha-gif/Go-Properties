export interface DayItinerary {
  day: number;
  title: string;
  description: string;
}

export interface TourPackage {
  id: string;
  title: string;
  subtitle: string;
  duration: string;
  days: number;
  basePriceUSD: number;
  category: 'Classic' | 'Highlights' | 'Most Popular' | 'Grand Journey' | 'Signature Luxury';
  featured: boolean;
  imageKey: string;
  highlights: string[];
  placesVisited: string[];
  inclusions: string[];
  exclusions: string[];
  itinerary: DayItinerary[];
}

export type Region = 
  | 'Cultural Triangle' 
  | 'Hill Country' 
  | 'Southern Coast' 
  | 'Wildlife' 
  | 'Eastern Coast';

export interface Destination {
  id: string;
  name: string;
  region: Region;
  tagline: string;
  imageKey: string;
  description: string;
  attractions: string[];
  experiences: string[];
  bestSeason: string;
  weatherInfo: string;
}

export interface Experience {
  id: string;
  title: string;
  tagline: string;
  imageKey: string;
  description: string;
  highlights: string[];
}

export interface Vehicle {
  id: string;
  category: string;
  models: string;
  image: string;
  capacity: string;
  luggage: string;
  ac: string;
  transmission: string;
  driver: string;
  features: string[];
  bestFor: string;
}

export interface MediaItem {
  id: string;
  title: string;
  alt: string;
  url: string;
  isCover: boolean;
  isCustomUpload?: boolean;
  sectionUsage?: string[];
  recommendedSize?: string;
  location?: string;
  category?: string;
}

export type MediaRegistry = Record<string, MediaItem[]>;

export interface Testimonial {
  id: string;
  name: string;
  country: string;
  flag: string;
  tour: string;
  rating: number;
  date: string;
  comment: string;
}

export interface Inquiry {
  id: string;
  createdAt: string;
  name: string;
  email: string;
  phone: string;
  country: string;
  travelDate: string;
  travelers: string;
  packageInterested: string;
  budget: string;
  transport: string;
  status: 'New' | 'Quoted' | 'In Discussion' | 'Confirmed' | 'Archived';
  message: string;
}

export interface WebsiteSettings {
  whatsappNumber: string;
  whatsappDisplay: string;
  email: string;
  phone: string;
  address: string;
  businessHours: string;
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  bucketName: string;
  connected: boolean;
}

export interface CurrencyConfig {
  symbol: string;
  rate: number;
  label: string;
}
