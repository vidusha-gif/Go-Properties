import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Calendar, Clock } from 'lucide-react';
import { useRealEstate } from '../context/RealEstateContext';

export const BlogPage: React.FC = () => {
  const { blogPosts } = useRealEstate();
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = ['all', ...Array.from(new Set(blogPosts.map(p => p.category)))];

  const filteredPosts = selectedCategory === 'all'
    ? blogPosts
    : blogPosts.filter(p => p.category === selectedCategory);

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1.5">
            The Journal
          </span>
          <h1 className="font-serif text-2xl sm:text-4xl font-medium text-cool-900 mb-2">
            Market Insights & Architectural Guides
          </h1>
          <p className="text-cool-500 text-xs font-light leading-relaxed">
            Forensic analysis on global wealth flows, prime capital appreciation, tax structuring, and contemporary architecture.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-1.5 mb-10">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 text-xs font-medium uppercase tracking-wider rounded-sm transition-colors ${
                selectedCategory === cat
                  ? 'bg-navy text-white font-semibold'
                  : 'bg-white border border-cool-200 text-cool-600 hover:text-navy'
              }`}
            >
              {cat === 'all' ? 'All Publications' : cat}
            </button>
          ))}
        </div>

        {/* Grid of Articles */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPosts.map(post => (
            <article
              key={post.id}
              className="bg-white border border-cool-200/80 rounded-sm overflow-hidden shadow-sm hover:shadow-[0_8px_25px_rgba(16,27,51,0.05)] transition-all duration-300 flex flex-col group"
            >
              <div className="relative aspect-[16/10] overflow-hidden bg-cool-100">
                <Link to={`/blog/${post.slug}`} className="block w-full h-full">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                </Link>
                <div className="absolute top-2.5 left-2.5 bg-black/60 backdrop-blur-md px-2 py-0.5 text-[9px] uppercase font-bold tracking-wider text-white rounded-sm">
                  {post.category}
                </div>
              </div>

              <div className="p-5 flex-grow flex flex-col justify-between">
                <div>
                  <div className="flex items-center space-x-2.5 text-[10px] text-cool-400 mb-1.5">
                    <span className="flex items-center space-x-1">
                      <Calendar className="w-3 h-3" />
                      <span>{post.publishedAt}</span>
                    </span>
                    <span>•</span>
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{post.readTime}</span>
                    </span>
                  </div>

                  <Link to={`/blog/${post.slug}`}>
                    <h2 className="font-serif text-lg font-medium text-cool-900 group-hover:text-navy transition-colors mb-2 line-clamp-2">
                      {post.title}
                    </h2>
                  </Link>

                  <p className="text-xs text-cool-500 font-light leading-relaxed mb-4 line-clamp-3">
                    {post.excerpt}
                  </p>
                </div>

                <div className="border-t border-cool-100 pt-3 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <img
                      src={post.author.avatar}
                      alt={post.author.name}
                      className="w-6 h-6 rounded-full object-cover border border-cool-200"
                    />
                    <span className="text-xs font-medium text-cool-700">
                      {post.author.name}
                    </span>
                  </div>

                  <Link
                    to={`/blog/${post.slug}`}
                    className="text-navy hover:text-black font-medium text-xs flex items-center space-x-1"
                  >
                    <span>Read</span>
                    <ArrowRight className="w-3 h-3" />
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
};
