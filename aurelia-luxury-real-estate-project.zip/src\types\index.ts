export type PropertyPurpose = 'sale' | 'rent';

export type PropertyType = 
  | 'house' 
  | 'villa' 
  | 'apartment' 
  | 'penthouse' 
  | 'commercial' 
  | 'land' 
  | 'estate';

export type PropertyStatus = 'available' | 'reserved' | 'sold' | 'rented';

export interface Property {
  id: string;
  referenceId: string; // e.g., 'AUE-8921'
  title: string;
  tagline?: string;
  description: string;
  purpose: PropertyPurpose;
  type: PropertyType;
  status: PropertyStatus;
  price: number;
  currency: string;
  pricePrefix?: string; // e.g. "From", "Guide Price"
  rentalPeriod?: 'month' | 'week' | 'year';
  isFeatured: boolean;
  isLuxury: boolean;
  isPriceReduced?: boolean;
  originalPrice?: number;
  
  // Location
  location: {
    address: string;
    city: string;
    state?: string;
    country: string;
    area: string; // Neighborhood / District
    lat: number;
    lng: number;
    hideExactAddress?: boolean;
  };

  // Dimensions & Details
  bedrooms: number;
  bathrooms: number;
  halfBaths?: number;
  parkingSpaces: number;
  floorAreaSqFt: number;
  landAreaSqFt?: number;
  yearBuilt?: number;
  furnishedStatus: 'furnished' | 'unfurnished' | 'semi-furnished';

  // Media
  featuredImage: string;
  galleryImages: string[];
  floorPlanUrl?: string;
  videoTourUrl?: string;
  virtualTour3DUrl?: string;

  // Features & Amenities
  amenities: string[];
  nearbyFacilities?: { name: string; distance: string }[];

  // Meta
  createdAt: string;
  updatedAt: string;
  viewsCount?: number;
}

export type LeadStatus = 
  | 'New' 
  | 'Contacted' 
  | 'Follow-up' 
  | 'Viewing Scheduled' 
  | 'Negotiation' 
  | 'Closed' 
  | 'Unsuccessful';

export interface InquiryLead {
  id: string;
  type: 'general' | 'property_viewing' | 'property_inquiry';
  propertyId?: string;
  propertyTitle?: string;
  propertyRef?: string;
  customerName: string;
  email: string;
  phone: string;
  message: string;
  preferredDate?: string;
  preferredTime?: string;
  status: LeadStatus;
  notes?: string;
  assignedTo?: string;
  createdAt: string;
  source: string;
}

export interface PropertySubmission {
  id: string;
  ownerName: string;
  email: string;
  phone: string;
  propertyLocation: string;
  propertyType: PropertyType;
  purpose: PropertyPurpose;
  expectedPrice: number;
  description: string;
  photos: string[];
  preferredContact: 'whatsapp' | 'phone' | 'email';
  status: 'pending' | 'reviewed' | 'listed' | 'declined';
  notes?: string;
  createdAt: string;
}

export interface LocationItem {
  id: string;
  name: string;
  slug: string;
  region: string;
  country: string;
  image: string;
  description: string;
  featured: boolean;
  order: number;
}

export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  readTime: string;
  author: {
    name: string;
    role: string;
    avatar: string;
  };
  image: string;
  publishedAt: string;
  tags: string[];
}

export interface Testimonial {
  id: string;
  clientName: string;
  location: string;
  propertyType: string;
  quote: string;
  rating: number;
  date: string;
  clientTitle?: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  bio: string;
  photo: string;
  email: string;
  phone: string;
  languages: string[];
  specialty: string;
}

export interface FAQItem {
  id: string;
  category: 'buying' | 'selling' | 'renting' | 'investment';
  question: string;
  answer: string;
}

export interface SiteSettings {
  companyName: string;
  tagline: string;
  logoText: string;
  phone: string;
  whatsappNumber: string; // e.g. '+1234567890' (without symbols for link)
  whatsappDisplay: string;
  email: string;
  address: string;
  cityCountry: string;
  currencySymbol: string;
  currencyCode: string;
  businessHours: string;
  heroHeadline: string;
  heroSubheadline: string;
  heroImages: string[];
  socialLinks: {
    instagram: string;
    linkedin: string;
    facebook: string;
    youtube: string;
  };
}

export interface FilterState {
  searchQuery: string;
  purpose: 'all' | 'sale' | 'rent';
  type: string;
  city: string;
  minPrice: number;
  maxPrice: number;
  bedrooms: string;
  bathrooms: string;
  amenities: string[];
  furnished: string;
  sortBy: 'newest' | 'price-asc' | 'price-desc' | 'featured';
  tag?: string; // e.g., 'luxury'
}
