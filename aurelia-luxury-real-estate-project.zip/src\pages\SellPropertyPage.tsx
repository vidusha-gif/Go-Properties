import React, { useState } from 'react';
import {
  CheckCircle2,
  Shield,
  Globe,
  ArrowRight,
  MessageCircle,
  Camera,
  Plus,
  Trash2
} from 'lucide-react';
import { useRealEstate } from '../context/RealEstateContext';
import { PropertyType, PropertyPurpose } from '../types';
import { generateWhatsAppLink } from '../utils/helpers';

export const SellPropertyPage: React.FC = () => {
  const { addSubmission, siteSettings } = useRealEstate();

  const [photoUrls, setPhotoUrls] = useState<string[]>([
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80'
  ]);
  const [newPhotoInput, setNewPhotoInput] = useState('');

  const [formData, setFormData] = useState({
    ownerName: '',
    email: '',
    phone: '',
    propertyLocation: '',
    propertyType: 'villa' as PropertyType,
    purpose: 'sale' as PropertyPurpose,
    expectedPrice: '',
    description: '',
    preferredContact: 'whatsapp' as 'whatsapp' | 'phone' | 'email'
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleAddPhoto = () => {
    if (newPhotoInput.trim()) {
      setPhotoUrls([...photoUrls, newPhotoInput.trim()]);
      setNewPhotoInput('');
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotoUrls(photoUrls.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addSubmission({
      ownerName: formData.ownerName,
      email: formData.email,
      phone: formData.phone,
      propertyLocation: formData.propertyLocation,
      propertyType: formData.propertyType,
      purpose: formData.purpose,
      expectedPrice: Number(formData.expectedPrice) || 0,
      description: formData.description,
      photos: photoUrls,
      preferredContact: formData.preferredContact
    });

    setIsSubmitted(true);
  };

  const whatsappUrl = generateWhatsAppLink(
    siteSettings.whatsappNumber,
    `Hello, I would like to schedule a private advisory consultation regarding marketing my property with ${siteSettings.companyName}.`
  );

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      {/* Editorial Hero Header in Deep Navy */}
      <div className="bg-navy text-white py-16 px-4 sm:px-6 lg:px-8 mb-12">
        <div className="max-w-3xl mx-auto text-center">
          <span className="text-[10px] uppercase tracking-[0.25em] text-pink-muted font-semibold block mb-2">
            Private Client Agency
          </span>
          <h1 className="font-serif text-3xl sm:text-5xl font-medium mb-3 leading-tight">
            Thinking of Selling or Renting Your Property?
          </h1>
          <p className="text-cool-300 text-xs sm:text-sm font-light leading-relaxed max-w-xl mx-auto mb-6">
            Connect with our team to discover how we can help you market your property and reach the right qualified buyers or tenants across premier international capitals.
          </p>

          <div className="flex flex-wrap justify-center gap-2.5">
            <a
              href="#form-section"
              className="bg-white hover:bg-pink-soft text-navy px-5 py-2 text-xs uppercase tracking-wider font-semibold rounded-sm transition-colors"
            >
              List My Property
            </a>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="border border-white/20 text-cool-300 hover:text-white px-5 py-2 text-xs uppercase tracking-wider font-medium rounded-sm transition-colors flex items-center space-x-1.5"
            >
              <MessageCircle className="w-3.5 h-3.5 text-pink-muted" />
              <span>Talk to Our Team</span>
            </a>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* 3 Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-14">
          <div className="bg-white border border-cool-200/80 p-6 rounded-sm shadow-sm">
            <div className="w-9 h-9 rounded-sm bg-cool-50 flex items-center justify-center text-navy mb-4">
              <Globe className="w-4 h-4" />
            </div>
            <h3 className="font-serif text-lg font-medium text-cool-900 mb-1.5">
              Global Buyer Reach
            </h3>
            <p className="text-cool-500 text-xs leading-relaxed font-light">
              Your residence is showcased directly to verified international family offices and institutional investors.
            </p>
          </div>

          <div className="bg-white border border-cool-200/80 p-6 rounded-sm shadow-sm">
            <div className="w-9 h-9 rounded-sm bg-cool-50 flex items-center justify-center text-navy mb-4">
              <Camera className="w-4 h-4" />
            </div>
            <h3 className="font-serif text-lg font-medium text-cool-900 mb-1.5">
              Architectural Production
            </h3>
            <p className="text-cool-500 text-xs leading-relaxed font-light">
              We commission premier photographers, cinematic 4K videographers, and architectural writers to present your property.
            </p>
          </div>

          <div className="bg-white border border-cool-200/80 p-6 rounded-sm shadow-sm">
            <div className="w-9 h-9 rounded-sm bg-cool-50 flex items-center justify-center text-navy mb-4">
              <Shield className="w-4 h-4" />
            </div>
            <h3 className="font-serif text-lg font-medium text-cool-900 mb-1.5">
              Absolute Discretion
            </h3>
            <p className="text-cool-500 text-xs leading-relaxed font-light">
              Prefer off-market discretion? We execute confidential marketing campaigns under strict NDAs without public markers.
            </p>
          </div>
        </div>

        {/* Property Submission Form Container */}
        <div id="form-section" className="bg-white border border-cool-200/80 rounded-sm shadow-sm p-6 sm:p-10 max-w-3xl mx-auto">
          <div className="text-center max-w-lg mx-auto mb-8">
            <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1">
              Representation Request
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-medium text-cool-900 mb-1.5">
              Submit Your Property for Appraisal
            </h2>
            <p className="text-cool-500 text-xs font-light">
              Complete the overview below. Our managing partners will review your submission and connect within 24 business hours.
            </p>
          </div>

          {isSubmitted ? (
            <div className="bg-emerald-50 border border-emerald-200 p-8 rounded-sm text-center animate-in fade-in">
              <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto mb-3" />
              <h3 className="font-serif text-2xl font-medium text-emerald-900 mb-1.5">
                Submission Successfully Received
              </h3>
              <p className="text-cool-600 text-xs font-light max-w-md mx-auto mb-5">
                Thank you, <strong className="font-semibold text-emerald-900">{formData.ownerName}</strong>. Your submission has been logged into our CRM. A partner will contact you via {formData.preferredContact}.
              </p>
              <button
                onClick={() => setIsSubmitted(false)}
                className="bg-navy text-white px-5 py-2 text-xs uppercase tracking-wider font-medium rounded-sm"
              >
                Submit Another Listing
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6 text-xs">
              {/* Step 1: Owner Info */}
              <div>
                <h3 className="font-serif text-base font-medium text-cool-900 mb-3 border-b border-cool-100 pb-1.5">
                  1. Owner & Contact Information
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Lord Alexander Wright"
                      value={formData.ownerName}
                      onChange={e => setFormData({ ...formData, ownerName: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 px-2.5 py-1.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="owner@familyoffice.com"
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 px-2.5 py-1.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+44 7946..."
                      value={formData.phone}
                      onChange={e => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 px-2.5 py-1.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                    />
                  </div>
                </div>

                <div className="mt-3">
                  <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                    Preferred Contact Channel
                  </label>
                  <div className="flex space-x-4">
                    {['whatsapp', 'phone', 'email'].map((method) => (
                      <label key={method} className="flex items-center space-x-1.5 text-xs text-cool-700 capitalize cursor-pointer">
                        <input
                          type="radio"
                          name="preferredContact"
                          value={method}
                          checked={formData.preferredContact === method}
                          onChange={e => setFormData({ ...formData, preferredContact: e.target.value as any })}
                          className="accent-navy"
                        />
                        <span>{method}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              {/* Step 2: Property Specifications */}
              <div>
                <h3 className="font-serif text-base font-medium text-cool-900 mb-3 border-b border-cool-100 pb-1.5">
                  2. Property Details & Expected Pricing
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                      Intent *
                    </label>
                    <select
                      value={formData.purpose}
                      onChange={e => setFormData({ ...formData, purpose: e.target.value as PropertyPurpose })}
                      className="w-full bg-cool-50 border border-cool-200 px-2.5 py-1.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                    >
                      <option value="sale">Selling</option>
                      <option value="rent">Renting / Leasing</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                      Type *
                    </label>
                    <select
                      value={formData.propertyType}
                      onChange={e => setFormData({ ...formData, propertyType: e.target.value as PropertyType })}
                      className="w-full bg-cool-50 border border-cool-200 px-2.5 py-1.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                    >
                      <option value="villa">Luxury Villa</option>
                      <option value="penthouse">Penthouse</option>
                      <option value="apartment">Apartment</option>
                      <option value="house">Townhouse</option>
                      <option value="commercial">Commercial</option>
                      <option value="land">Development Land</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                      Location / Address *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Mayfair, London"
                      value={formData.propertyLocation}
                      onChange={e => setFormData({ ...formData, propertyLocation: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 px-2.5 py-1.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                      Expected Guide Price ($) *
                    </label>
                    <input
                      type="number"
                      required
                      placeholder="e.g. 15000000"
                      value={formData.expectedPrice}
                      onChange={e => setFormData({ ...formData, expectedPrice: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 px-2.5 py-1.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                    />
                  </div>
                </div>

                <div className="mt-3">
                  <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                    Description & Features
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Provide details on square footage, bedrooms, architectural style, or view aspects..."
                    value={formData.description}
                    onChange={e => setFormData({ ...formData, description: e.target.value })}
                    className="w-full bg-cool-50 border border-cool-200 p-2 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none font-light"
                  />
                </div>
              </div>

              {/* Step 3: Photos */}
              <div>
                <h3 className="font-serif text-base font-medium text-cool-900 mb-3 border-b border-cool-100 pb-1.5">
                  3. Imagery & Photography
                </h3>

                <div className="flex gap-2 mb-3">
                  <input
                    type="url"
                    placeholder="Enter image URL..."
                    value={newPhotoInput}
                    onChange={e => setNewPhotoInput(e.target.value)}
                    className="flex-grow bg-cool-50 border border-cool-200 px-2.5 py-1.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleAddPhoto}
                    className="bg-navy hover:bg-navy-midnight text-white px-3 py-1.5 text-[11px] uppercase tracking-wider font-medium rounded-sm flex items-center space-x-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {photoUrls.map((url, idx) => (
                    <div key={idx} className="relative w-20 h-14 rounded-sm overflow-hidden border border-cool-200">
                      <img src={url} alt={`Upload ${idx + 1}`} className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => handleRemovePhoto(idx)}
                        className="absolute top-1 right-1 p-0.5 bg-black/60 hover:bg-rose-600 text-white rounded-full transition-colors"
                        title="Remove"
                      >
                        <Trash2 className="w-2.5 h-2.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-cool-100 flex flex-col sm:flex-row items-center justify-between gap-3">
                <span className="text-[10px] text-cool-400 font-light">
                  Protected by fiduciary client confidentiality.
                </span>
                <button
                  type="submit"
                  className="w-full sm:w-auto bg-navy hover:bg-navy-midnight text-white px-8 py-2.5 text-xs uppercase tracking-wider font-medium rounded-sm transition-colors flex items-center justify-center space-x-1.5"
                >
                  <span>Submit Property for Evaluation</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
