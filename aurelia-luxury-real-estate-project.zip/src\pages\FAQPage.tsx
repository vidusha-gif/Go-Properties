import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { useRealEstate } from '../context/RealEstateContext';

export const FAQPage: React.FC = () => {
  const { faqs } = useRealEstate();
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'buying' | 'selling' | 'renting' | 'investment'>('all');
  const [openIds, setOpenIds] = useState<string[]>(['faq-1']);

  const toggleOpen = (id: string) => {
    setOpenIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const filteredFaqs = selectedCategory === 'all'
    ? faqs
    : faqs.filter(f => f.category === selectedCategory);

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1.5">
            Advisory Dossier
          </span>
          <h1 className="font-serif text-2xl sm:text-4xl font-medium text-cool-900 mb-2">
            Frequently Asked Questions
          </h1>
          <p className="text-cool-500 text-xs font-light leading-relaxed">
            Clear answers regarding international property acquisitions, seller representations, and confidential off-market protocols.
          </p>
        </div>

        {/* Categories Tab */}
        <div className="flex flex-wrap justify-center gap-1.5 mb-8">
          {[
            { id: 'all', label: 'All' },
            { id: 'buying', label: 'Buying' },
            { id: 'selling', label: 'Selling' },
            { id: 'renting', label: 'Lettings' },
            { id: 'investment', label: 'Investment' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setSelectedCategory(tab.id as any)}
              className={`px-3 py-1 text-xs font-medium uppercase tracking-wider rounded-sm transition-colors ${
                selectedCategory === tab.id
                  ? 'bg-navy text-white font-semibold'
                  : 'bg-white border border-cool-200 text-cool-600 hover:text-navy'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* FAQs Accordion */}
        <div className="space-y-3">
          {filteredFaqs.map(faq => {
            const isOpen = openIds.includes(faq.id);
            return (
              <div
                key={faq.id}
                className="bg-white border border-cool-200/80 rounded-sm overflow-hidden shadow-sm transition-colors"
              >
                <button
                  type="button"
                  onClick={() => toggleOpen(faq.id)}
                  className="w-full text-left p-4 sm:p-5 flex items-center justify-between hover:bg-cool-50/50 transition-colors"
                >
                  <span className="font-serif text-base sm:text-lg font-medium text-cool-900 pr-3">
                    {faq.question}
                  </span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-pink-muted flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-cool-400 flex-shrink-0" />
                  )}
                </button>

                {isOpen && (
                  <div className="px-4 sm:px-5 pb-5 pt-1 text-xs text-cool-600 font-light leading-relaxed border-t border-cool-100 bg-cool-50/30 animate-in fade-in">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
