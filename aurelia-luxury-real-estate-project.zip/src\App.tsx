import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { RealEstateProvider } from './context/RealEstateContext';

// Common Components
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { FloatingWhatsApp } from './components/common/FloatingWhatsApp';
import { PropertyQuickViewModal } from './components/property/PropertyQuickViewModal';

// Pages
import { HomePage } from './pages/HomePage';
import { PropertiesPage } from './pages/PropertiesPage';
import { PropertyDetailPage } from './pages/PropertyDetailPage';
import { PropertyComparePage } from './pages/PropertyComparePage';
import { FavoritesPage } from './pages/FavoritesPage';
import { ExploreLocationsPage } from './pages/ExploreLocationsPage';
import { SellPropertyPage } from './pages/SellPropertyPage';
import { AboutPage } from './pages/AboutPage';
import { TeamPage } from './pages/TeamPage';
import { BlogPage } from './pages/BlogPage';
import { BlogPostPage } from './pages/BlogPostPage';
import { ContactPage } from './pages/ContactPage';
import { FAQPage } from './pages/FAQPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { TermsPage } from './pages/TermsPage';
import { AdminLoginPage } from './pages/AdminLoginPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';

// Scroll to top helper on navigation
const ScrollToTop: React.FC = () => {
  const { pathname, search } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname, search]);

  return null;
};

// Layout container to hide consumer Navbar/Footer on admin paths
const AppLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { pathname } = useLocation();
  const isAdminRoute = pathname.startsWith('/admin');

  return (
    <div className="flex flex-col min-h-screen">
      {!isAdminRoute && <Navbar />}
      <main className="flex-grow">{children}</main>
      {!isAdminRoute && <Footer />}
      {!isAdminRoute && <FloatingWhatsApp />}
      <PropertyQuickViewModal />
    </div>
  );
};

export function App() {
  return (
    <AuthProvider>
      <RealEstateProvider>
        <BrowserRouter>
          <ScrollToTop />
          <AppLayout>
            <Routes>
              {/* 1. Homepage */}
              <Route path="/" element={<HomePage />} />

              {/* 2-7. Properties portfolio routes */}
              <Route path="/properties" element={<PropertiesPage />} />

              {/* 8. Property Details */}
              <Route path="/property/:id" element={<PropertyDetailPage />} />

              {/* 9. Comparison */}
              <Route path="/compare" element={<PropertyComparePage />} />

              {/* 10. Favorites */}
              <Route path="/favorites" element={<FavoritesPage />} />

              {/* 11. Explore Locations */}
              <Route path="/locations" element={<ExploreLocationsPage />} />

              {/* 12. Sell / List Your Property */}
              <Route path="/sell" element={<SellPropertyPage />} />

              {/* 13. About Us */}
              <Route path="/about" element={<AboutPage />} />

              {/* 14. Our Team */}
              <Route path="/team" element={<TeamPage />} />

              {/* 15-16. Blog and Articles */}
              <Route path="/blog" element={<BlogPage />} />
              <Route path="/blog/:slug" element={<BlogPostPage />} />

              {/* 17. Contact */}
              <Route path="/contact" element={<ContactPage />} />

              {/* 18. FAQ */}
              <Route path="/faq" element={<FAQPage />} />

              {/* 19-20. Legal */}
              <Route path="/privacy" element={<PrivacyPage />} />
              <Route path="/terms" element={<TermsPage />} />

              {/* 21-22. Admin Suite */}
              <Route path="/admin/login" element={<AdminLoginPage />} />
              <Route path="/admin" element={<AdminDashboardPage />} />

              {/* Fallback */}
              <Route path="*" element={<HomePage />} />
            </Routes>
          </AppLayout>
        </BrowserRouter>
      </RealEstateProvider>
    </AuthProvider>
  );
}

export default App;
