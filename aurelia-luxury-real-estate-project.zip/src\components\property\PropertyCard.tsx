import React from 'react';
import { Link } from 'react-router-dom';
import {
  Heart,
  Scale,
  Eye,
  Bed,
  Bath,
  Maximize2,
  MapPin,
  MessageCircle,
  ArrowUpRight,
  Car
} from 'lucide-react';
import { Property } from '../../types';
import { useRealEstate } from '../../context/RealEstateContext';
import { formatPrice, generateWhatsAppLink } from '../../utils/helpers';

interface PropertyCardProps {
  property: Property;
  viewMode?: 'grid' | 'list';
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ property, viewMode = 'grid' }) => {
  const { isFavorite, toggleFavorite, isInCompare, toggleCompare, openQuickView, siteSettings } = useRealEstate();

  const favorite = isFavorite(property.id);
  const inCompare = isInCompare(property.id);

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleFavorite(property.id);
  };

  const handleCompareClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleCompare(property.id);
  };

  const handleQuickViewClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    openQuickView(property);
  };

  // WhatsApp inquiry URL
  const whatsappMsg = `Hello, I am interested in inquiring about ${property.title} (${property.referenceId}) listed at ${formatPrice(property.price, siteSettings.currencySymbol, property.rentalPeriod)}.`;
  const whatsappUrl = generateWhatsAppLink(siteSettings.whatsappNumber, whatsappMsg);

  if (viewMode === 'list') {
    return (
      <div className="group bg-white border border-cool-200/70 rounded-sm overflow-hidden hover:border-cool-300 hover:shadow-[0_8px_25px_rgba(16,27,51,0.05)] transition-all duration-300 flex flex-col md:flex-row">
        {/* Image Container */}
        <div className="relative md:w-2/5 h-60 md:h-auto overflow-hidden bg-cool-100 flex-shrink-0">
          <img
            src={property.featuredImage}
            alt={property.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
            loading="lazy"
          />

          {/* Minimal Badges */}
          <div className="absolute top-2.5 left-2.5 flex flex-wrap gap-1 z-10 pointer-events-none">
            <span className="px-2 py-0.5 text-[9px] font-semibold tracking-wider uppercase bg-navy text-white rounded-sm">
              {property.purpose === 'sale' ? 'For Sale' : 'For Rent'}
            </span>
            {property.isLuxury && (
              <span className="px-2 py-0.5 text-[9px] font-semibold tracking-wider uppercase bg-pink-soft text-navy border border-pink-muted/60 rounded-sm">
                Luxury
              </span>
            )}
            {property.status === 'reserved' && (
              <span className="px-2 py-0.5 text-[9px] font-semibold tracking-wider uppercase bg-cool-700 text-white rounded-sm">
                Reserved
              </span>
            )}
          </div>

          {/* Quick Action Overlay */}
          <div className="absolute top-2.5 right-2.5 flex items-center space-x-1 z-10">
            <button
              onClick={handleFavoriteClick}
              className={`p-1.5 rounded-full backdrop-blur-md transition-colors ${
                favorite
                  ? 'bg-pink-muted text-navy'
                  : 'bg-black/40 text-white hover:bg-black/70 hover:text-pink-muted'
              }`}
              title={favorite ? 'Saved' : 'Save property'}
              aria-label="Save Property"
            >
              <Heart className={`w-3.5 h-3.5 ${favorite ? 'fill-current' : ''}`} />
            </button>
            <button
              onClick={handleCompareClick}
              className={`p-1.5 rounded-full backdrop-blur-md transition-colors ${
                inCompare
                  ? 'bg-navy text-white'
                  : 'bg-black/40 text-white hover:bg-black/70 hover:text-pink-muted'
              }`}
              title="Compare property"
              aria-label="Compare Property"
            >
              <Scale className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleQuickViewClick}
              className="p-1.5 rounded-full bg-black/40 text-white hover:bg-black/70 hover:text-pink-muted backdrop-blur-md transition-colors"
              title="Quick view"
              aria-label="Quick View"
            >
              <Eye className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 md:w-3/5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-[11px] text-cool-400 mb-1.5">
              <span className="uppercase tracking-wider font-medium text-cool-500">
                {property.type} • Ref: {property.referenceId}
              </span>
              <span className="flex items-center text-cool-400">
                <MapPin className="w-3 h-3 text-pink-muted mr-1" />
                {property.location.area}, {property.location.city}
              </span>
            </div>

            <Link to={`/property/${property.id}`} className="group-hover:text-navy transition-colors">
              <h3 className="font-serif text-xl font-medium text-cool-900 mb-1.5 line-clamp-1">
                {property.title}
              </h3>
            </Link>

            <p className="text-cool-500 text-xs line-clamp-2 mb-3.5 font-light leading-relaxed">
              {property.description}
            </p>

            {/* Specs */}
            <div className="flex flex-wrap items-center gap-4 py-2.5 border-t border-b border-cool-100 text-[11px] text-cool-600">
              {property.bedrooms > 0 && (
                <div className="flex items-center space-x-1.5">
                  <Bed className="w-3.5 h-3.5 text-cool-400" />
                  <span>{property.bedrooms} Beds</span>
                </div>
              )}
              {property.bathrooms > 0 && (
                <div className="flex items-center space-x-1.5">
                  <Bath className="w-3.5 h-3.5 text-cool-400" />
                  <span>{property.bathrooms} Baths</span>
                </div>
              )}
              {property.floorAreaSqFt > 0 && (
                <div className="flex items-center space-x-1.5">
                  <Maximize2 className="w-3.5 h-3.5 text-cool-400" />
                  <span>{property.floorAreaSqFt.toLocaleString()} sq ft</span>
                </div>
              )}
              {property.parkingSpaces > 0 && (
                <div className="flex items-center space-x-1.5">
                  <Car className="w-3.5 h-3.5 text-cool-400" />
                  <span>{property.parkingSpaces} Garage</span>
                </div>
              )}
            </div>
          </div>

          <div className="pt-3.5 flex items-center justify-between">
            <div>
              {property.pricePrefix && (
                <span className="text-[10px] uppercase tracking-wider text-cool-400 block -mb-0.5">
                  {property.pricePrefix}
                </span>
              )}
              <span className="font-serif text-xl font-medium text-navy">
                {formatPrice(property.price, siteSettings.currencySymbol, property.rentalPeriod)}
              </span>
            </div>

            <div className="flex items-center space-x-2">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1.5 border border-cool-200 text-cool-500 hover:text-navy hover:border-navy rounded-sm transition-colors"
                title="Inquire on WhatsApp"
              >
                <MessageCircle className="w-3.5 h-3.5" />
              </a>
              <Link
                to={`/property/${property.id}`}
                className="bg-navy hover:bg-navy-midnight text-white px-3.5 py-1.5 text-[11px] uppercase tracking-wider font-medium rounded-sm flex items-center space-x-1 transition-colors"
              >
                <span>Details</span>
                <ArrowUpRight className="w-3 h-3" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Grid view (Default)
  return (
    <div className="group bg-white border border-cool-200/70 rounded-sm overflow-hidden hover:border-cool-300 hover:shadow-[0_8px_25px_rgba(16,27,51,0.05)] transition-all duration-300 flex flex-col">
      {/* Image Container */}
      <div className="relative aspect-[16/10] overflow-hidden bg-cool-100">
        <Link to={`/property/${property.id}`} className="block w-full h-full">
          <img
            src={property.featuredImage}
            alt={property.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
            loading="lazy"
          />
        </Link>

        {/* Minimal Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-wrap gap-1 z-10 pointer-events-none">
          <span className="px-2 py-0.5 text-[9px] font-semibold tracking-wider uppercase bg-navy text-white rounded-sm">
            {property.purpose === 'sale' ? 'For Sale' : 'For Rent'}
          </span>
          {property.isLuxury && (
            <span className="px-2 py-0.5 text-[9px] font-semibold tracking-wider uppercase bg-pink-soft text-navy border border-pink-muted/60 rounded-sm">
              Luxury
            </span>
          )}
          {property.status === 'reserved' && (
            <span className="px-2 py-0.5 text-[9px] font-semibold tracking-wider uppercase bg-cool-700 text-white rounded-sm">
              Reserved
            </span>
          )}
          {property.status === 'sold' && (
            <span className="px-2 py-0.5 text-[9px] font-semibold tracking-wider uppercase bg-cool-900 text-white rounded-sm">
              Sold
            </span>
          )}
        </div>

        {/* Action Overlay */}
        <div className="absolute top-2.5 right-2.5 flex items-center space-x-1 z-10">
          <button
            onClick={handleFavoriteClick}
            className={`p-1.5 rounded-full backdrop-blur-md transition-colors ${
              favorite
                ? 'bg-pink-muted text-navy'
                : 'bg-black/40 text-white hover:bg-black/70 hover:text-pink-muted'
            }`}
            title={favorite ? 'Saved' : 'Save property'}
            aria-label="Save Property"
          >
            <Heart className={`w-3.5 h-3.5 ${favorite ? 'fill-current' : ''}`} />
          </button>
          <button
            onClick={handleCompareClick}
            className={`p-1.5 rounded-full backdrop-blur-md transition-colors ${
              inCompare
                ? 'bg-navy text-white'
                : 'bg-black/40 text-white hover:bg-black/70 hover:text-pink-muted'
            }`}
            title="Compare property"
            aria-label="Compare Property"
          >
            <Scale className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleQuickViewClick}
            className="p-1.5 rounded-full bg-black/40 text-white hover:bg-black/70 hover:text-pink-muted backdrop-blur-md transition-colors"
            title="Quick view"
            aria-label="Quick View"
          >
            <Eye className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Discreet Ref tag */}
        <div className="absolute bottom-2 left-2.5 text-[9px] tracking-widest uppercase text-white/80 bg-black/40 backdrop-blur-sm px-1.5 py-0.5 rounded-sm">
          {property.referenceId}
        </div>
      </div>

      {/* Info Container */}
      <div className="p-4 flex-grow flex flex-col justify-between">
        <div>
          <div className="flex items-center text-[11px] text-cool-400 mb-1.5">
            <MapPin className="w-3 h-3 text-pink-muted mr-1 flex-shrink-0" />
            <span className="truncate">{property.location.area}, {property.location.city}</span>
          </div>

          <Link to={`/property/${property.id}`} className="group-hover:text-navy transition-colors">
            <h3 className="font-serif text-lg font-medium text-cool-900 mb-2 line-clamp-1">
              {property.title}
            </h3>
          </Link>

          {/* Minimal Specs */}
          <div className="grid grid-cols-3 gap-1.5 py-2.5 border-t border-b border-cool-100 text-[11px] text-cool-500 mb-3">
            <div className="flex items-center space-x-1">
              <Bed className="w-3 h-3 text-cool-400" />
              <span>{property.bedrooms > 0 ? `${property.bedrooms} Beds` : `${property.type}`}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Bath className="w-3 h-3 text-cool-400" />
              <span>{property.bathrooms > 0 ? `${property.bathrooms} Baths` : 'N/A'}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Maximize2 className="w-3 h-3 text-cool-400" />
              <span>
                {property.floorAreaSqFt > 0
                  ? `${property.floorAreaSqFt.toLocaleString()} sqft`
                  : property.landAreaSqFt
                  ? `${property.landAreaSqFt.toLocaleString()} sqft`
                  : 'N/A'}
              </span>
            </div>
          </div>
        </div>

        {/* Price & Action */}
        <div className="flex items-center justify-between pt-0.5">
          <div>
            {property.pricePrefix && (
              <span className="text-[9px] uppercase tracking-wider text-cool-400 block -mb-0.5">
                {property.pricePrefix}
              </span>
            )}
            <span className="font-serif text-lg font-medium text-navy">
              {formatPrice(property.price, siteSettings.currencySymbol, property.rentalPeriod)}
            </span>
          </div>

          <div className="flex items-center space-x-1.5">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-1.5 border border-cool-200 text-cool-500 hover:text-navy hover:border-navy rounded-sm transition-colors"
              title="Quick WhatsApp inquiry"
            >
              <MessageCircle className="w-3.5 h-3.5" />
            </a>
            <Link
              to={`/property/${property.id}`}
              className="bg-navy hover:bg-navy-midnight text-white px-2.5 py-1.5 text-[10px] uppercase tracking-wider font-medium rounded-sm flex items-center space-x-1 transition-all"
            >
              <span>View</span>
              <ArrowUpRight className="w-3 h-3" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
