import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { Property } from '../../types';
import { useRealEstate } from '../../context/RealEstateContext';
import { formatPrice } from '../../utils/helpers';

interface PropertyMapProps {
  properties: Property[];
  height?: string;
  selectedPropertyId?: string;
  onMarkerClick?: (prop: Property) => void;
}

export const PropertyMap: React.FC<PropertyMapProps> = ({
  properties,
  height = '600px',
  selectedPropertyId,
  onMarkerClick
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [key: string]: L.Marker }>({});
  const { siteSettings } = useRealEstate();

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Default center
    const initialCenter: [number, number] = properties.length > 0 && properties[0].location.lat
      ? [properties[0].location.lat, properties[0].location.lng]
      : [35.0, -10.0];

    // Initialize Map instance
    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: initialCenter,
        zoom: properties.length === 1 ? 13 : 3,
        scrollWheelZoom: false,
        attributionControl: false
      });

      // CartoDB Positron Luxury clean minimal tiles
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        subdomains: 'abcd'
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;

    // Clear previous markers
    Object.values(markersRef.current).forEach(m => m.remove());
    markersRef.current = {};

    const bounds = L.latLngBounds([]);

    // Add Markers for properties
    properties.forEach(prop => {
      if (!prop.location || typeof prop.location.lat !== 'number' || typeof prop.location.lng !== 'number') return;

      const formattedPrice = formatPrice(prop.price, siteSettings.currencySymbol, prop.rentalPeriod);
      let compactPrice = formattedPrice;
      if (prop.price >= 1000000) {
        compactPrice = `${siteSettings.currencySymbol}${(prop.price / 1000000).toFixed(1).replace('.0', '')}M`;
      } else if (prop.price >= 1000) {
        compactPrice = `${siteSettings.currencySymbol}${Math.round(prop.price / 1000)}k`;
      }
      if (prop.purpose === 'rent') {
        compactPrice += '/mo';
      }

      const customIcon = L.divIcon({
        className: 'custom-map-marker-wrapper',
        html: `<div class="custom-map-marker ${selectedPropertyId === prop.id ? 'active' : ''}">${compactPrice}</div>`,
        iconSize: [80, 28],
        iconAnchor: [40, 30],
        popupAnchor: [0, -30]
      });

      const marker = L.marker([prop.location.lat, prop.location.lng], { icon: customIcon }).addTo(map);

      // Popup Content Card - Clean Deep Navy / Cool Gray / Minimal White
      const popupHtml = `
        <div style="width: 230px; font-family: 'Plus Jakarta Sans', sans-serif;">
          <div style="position: relative; width: 100%; height: 120px; overflow: hidden; background: #111;">
            <img src="${prop.featuredImage}" style="width: 100%; height: 100%; object-fit: cover;" />
            <span style="position: absolute; top: 6px; left: 6px; background: #101B33; color: #fff; font-size: 8px; font-weight: 600; padding: 2px 6px; text-transform: uppercase; letter-spacing: 0.05em; border-radius: 2px;">
              ${prop.purpose === 'sale' ? 'For Sale' : 'For Rent'}
            </span>
          </div>
          <div style="padding: 10px; background: #fff;">
            <div style="font-size: 9px; color: #8992A3; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 2px;">
              ${prop.location.area}, ${prop.location.city}
            </div>
            <div style="font-family: 'Cormorant Garamond', Georgia, serif; font-size: 15px; font-weight: 500; color: #111111; line-height: 1.2; margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
              ${prop.title}
            </div>
            <div style="font-size: 13px; font-weight: 600; color: #101B33; margin-bottom: 8px;">
              ${formattedPrice}
            </div>
            <a href="#/property/${prop.id}" style="display: block; text-align: center; background: #101B33; color: #fff; padding: 6px; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.05em; text-decoration: none; border-radius: 2px;">
              View Details
            </a>
          </div>
        </div>
      `;

      marker.bindPopup(popupHtml);

      marker.on('click', () => {
        if (onMarkerClick) onMarkerClick(prop);
      });

      markersRef.current[prop.id] = marker;
      bounds.extend([prop.location.lat, prop.location.lng]);
    });

    if (properties.length > 1 && bounds.isValid()) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 12 });
    } else if (properties.length === 1) {
      map.setView([properties[0].location.lat, properties[0].location.lng], 13);
    }
  }, [properties, selectedPropertyId, siteSettings.currencySymbol]);

  return (
    <div className="relative w-full rounded-sm overflow-hidden border border-cool-200/80 shadow-sm" style={{ height }}>
      <div ref={mapContainerRef} className="w-full h-full z-0" />
      <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md px-2.5 py-1 rounded-sm border border-cool-200 text-[11px] text-cool-600 shadow-sm z-10 pointer-events-none">
        <span className="font-semibold text-navy">{properties.length}</span> luxury residences mapped
      </div>
    </div>
  );
};
