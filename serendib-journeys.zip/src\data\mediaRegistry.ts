import { MediaRegistry } from '../types';

export const DEFAULT_MEDIA_REGISTRY: MediaRegistry = {
  hero: [
    {
      id: 'hero-1',
      title: 'Sigiriya Rock Fortress at Sunrise',
      alt: 'Cinematic sunrise view of Sigiriya Lion Rock Fortress Sri Lanka',
      url: 'https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?auto=format&fit=crop&w=2000&q=85',
      isCover: true,
      sectionUsage: ['Homepage Hero Background'],
      recommendedSize: '1920 × 1080 px'
    },
    {
      id: 'hero-2',
      title: 'Demodara Nine Arch Bridge Ella',
      alt: 'Iconic Ceylon blue train crossing the Nine Arch viaduct in Ella Sri Lanka',
      url: 'https://images.unsplash.com/photo-1546708973-b339540b5162?auto=format&fit=crop&w=2000&q=85',
      isCover: false,
      sectionUsage: ['Homepage Hero Alternate'],
      recommendedSize: '1920 × 1080 px'
    }
  ],
  sigiriya: [
    {
      id: 'sig-1',
      title: 'Sigiriya Ancient Sky Citadel Summit',
      alt: 'Sigiriya Lion Rock 5th century UNESCO World Heritage Site Sri Lanka',
      url: 'https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Homepage Sigiriya Card', '5-Day Tour Package', '7-Day Tour Package'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  ella: [
    {
      id: 'ella-1',
      title: 'Nine Arch Bridge & Tea Valleys',
      alt: 'Historic colonial stone Nine Arch Bridge surrounded by tea plantations in Ella Sri Lanka',
      url: 'https://images.unsplash.com/photo-1546708973-b339540b5162?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Homepage Ella Card', 'Scenic Train Experience', '7-Day Tour Package'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  kandy: [
    {
      id: 'kandy-1',
      title: 'Temple of the Sacred Tooth Relic (Sri Dalada Maligawa)',
      alt: 'Sri Dalada Maligawa Temple of the Tooth beside Kandy Lake in Sri Lanka',
      url: 'https://images.unsplash.com/photo-1588598198321-9735fd52455f?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Homepage Kandy Card', '3-Day Tour Package', 'Cultural Heritage Tours'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  galle: [
    {
      id: 'galle-1',
      title: 'Galle Dutch Fort Lighthouse & Ramparts',
      alt: 'Historic white lighthouse and 17th-century ramparts at UNESCO Galle Fort Sri Lanka',
      url: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Homepage Galle Card', '10-Day Tour Package', 'Gallery'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  mirissa: [
    {
      id: 'mirissa-1',
      title: 'Coconut Tree Hill Mirissa',
      alt: 'Authentic Coconut Tree Hill promontory overlooking turquoise ocean in Mirissa Sri Lanka',
      url: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Homepage Mirissa Card', 'Beach Holidays', 'Whale Watching Tours'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  'nuwara-eliya': [
    {
      id: 'ne-1',
      title: 'Nuwara Eliya High-Grown Tea Plantations',
      alt: 'Rolling emerald green tea carpet and misty mountains in Nuwara Eliya Sri Lanka',
      url: 'https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Homepage Nuwara Eliya Card', 'Hill Country Adventures', 'About Us Page'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  yala: [
    {
      id: 'yala-1',
      title: 'Wild Sri Lankan Leopard on Granite Outcrop',
      alt: 'Sri Lankan Leopard (Panthera pardus kotiya) resting in Yala National Park Sri Lanka',
      url: 'https://images.unsplash.com/photo-1534177616072-ef7dc120449d?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Homepage Yala Card', 'Wildlife Safaris', '10-Day Tour Package'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  trincomalee: [
    {
      id: 'trinco-1',
      title: 'Nilaveli Beach & Pigeon Island Marine Park',
      alt: 'Crystal clear waters and coral reef shores of Trincomalee eastern Sri Lanka',
      url: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Homepage Trincomalee Card', 'Eastern Coast Tour'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  dambulla: [
    {
      id: 'dambulla-1',
      title: 'Dambulla Golden Cave Temple & Ancient Buddha Shrines',
      alt: 'Sacred rock cave temple complex with ancient Buddhist murals in Dambulla Sri Lanka',
      url: 'https://images.unsplash.com/photo-1588598198321-9735fd52455f?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Cultural Triangle', '5-Day Escape'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  anuradhapura: [
    {
      id: 'anuradhapura-1',
      title: 'Ruwanweli Seya Sacred White Stupa',
      alt: 'Colossal ancient Ruwanweli Seya Buddhist stupa in sacred Anuradhapura Sri Lanka',
      url: 'https://images.unsplash.com/photo-1588598198321-9735fd52455f?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Cultural Triangle', '10-Day Grand Tour'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  polonnaruwa: [
    {
      id: 'polonnaruwa-1',
      title: 'Gal Vihara Granite Rock Buddha Sculptures',
      alt: '12th-century Gal Vihara colossal rock-cut Buddha statues in Polonnaruwa Sri Lanka',
      url: 'https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Cultural Triangle', 'Medieval Kingdom Tour'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  udawalawe: [
    {
      id: 'udawalawe-1',
      title: 'Asian Elephants Roaming Udawalawe Savannah',
      alt: 'Wild Sri Lankan Asian elephant family herd at Udawalawe National Park Sri Lanka',
      url: 'https://images.unsplash.com/photo-1557050543-4d5f4e07ef46?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Wildlife Safari', 'Family Holidays'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  minneriya: [
    {
      id: 'minneriya-1',
      title: 'The Great Elephant Gathering at Minneriya',
      alt: 'Hundreds of wild Asian elephants congregating on the receding lake bed of Minneriya Sri Lanka',
      url: 'https://images.unsplash.com/photo-1564760055775-d63b17a55c44?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Wildlife Safari', '7-Day Tour Package'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  haputale: [
    {
      id: 'haputale-1',
      title: 'Sir Thomas Lipton\'s Tea Seat at Dambatenne',
      alt: 'Panoramic mountain ridge at Lipton\'s Seat in Haputale Sri Lanka',
      url: 'https://images.unsplash.com/photo-1531747056595-07f6cbbe10ad?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page', 'Hill Country Adventures', 'Gallery'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  beaches: [
    {
      id: 'beach-1',
      title: 'Coconut Palm Shores of Southern Sri Lanka',
      alt: 'Pristine golden beach lined with coconut palms in southern Sri Lanka',
      url: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Destinations Page (Hiriketiya, Unawatuna)', 'Beach Holidays Experience'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  wildlife: [
    {
      id: 'wild-1',
      title: 'Sri Lankan Wild Elephant Calf & Herd',
      alt: 'Wild Asian elephant calf surrounded by mother in Sri Lanka national park',
      url: 'https://images.unsplash.com/photo-1557050543-4d5f4e07ef46?auto=format&fit=crop&w=1200&q=80',
      isCover: true,
      sectionUsage: ['Wildlife Safaris Experience', 'Gallery'],
      recommendedSize: '1600 × 1000 px'
    }
  ],
  vehicles: [
    {
      id: 'veh-sedan',
      title: 'Modern Air-Conditioned Sedan (Toyota Prius / Premio)',
      alt: 'Clean modern private tour sedan with professional chauffeur in Sri Lanka',
      url: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=800&q=80',
      isCover: true,
      sectionUsage: ['Transport Page: Sedan Cars'],
      recommendedSize: '1200 × 800 px'
    },
    {
      id: 'veh-suv',
      title: 'Luxury 4x4 SUV (Toyota Prado / Fortuner)',
      alt: 'High ground clearance luxury private SUV for hill country tours in Sri Lanka',
      url: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80',
      isCover: false,
      sectionUsage: ['Transport Page: SUVs & Crossovers'],
      recommendedSize: '1200 × 800 px'
    },
    {
      id: 'veh-van',
      title: 'Spacious Passenger Van (Toyota KDH High-Roof)',
      alt: 'Toyota KDH High-Roof passenger van with reclining seats for Sri Lanka tours',
      url: 'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?auto=format&fit=crop&w=800&q=80',
      isCover: false,
      sectionUsage: ['Transport Page: Passenger Vans'],
      recommendedSize: '1200 × 800 px'
    }
  ],
  gallery: [
    { id: 'g-1', title: 'Sigiriya Sky Citadel', location: 'Sigiriya, Cultural Triangle', category: 'Cultural', url: 'https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?auto=format&fit=crop&w=1200&q=85', isCover: false, sectionUsage: ['Gallery'] },
    { id: 'g-2', title: 'Nine Arch Colonial Viaduct', location: 'Ella, Central Highlands', category: 'Mountains', url: 'https://images.unsplash.com/photo-1546708973-b339540b5162?auto=format&fit=crop&w=1200&q=85', isCover: false, sectionUsage: ['Gallery'] },
    { id: 'g-3', title: 'Temple of the Sacred Tooth', location: 'Kandy, Hill Capital', category: 'Cultural', url: 'https://images.unsplash.com/photo-1588598198321-9735fd52455f?auto=format&fit=crop&w=1200&q=85', isCover: false, sectionUsage: ['Gallery'] },
    { id: 'g-4', title: 'Emerald Ceylon Tea Estates', location: 'Nuwara Eliya', category: 'Mountains', url: 'https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=1200&q=85', isCover: false, sectionUsage: ['Gallery'] },
    { id: 'g-5', title: 'Historic Galle Fort Lighthouse', location: 'Galle, Southern Province', category: 'Cultural', url: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=1200&q=85', isCover: false, sectionUsage: ['Gallery'] },
    { id: 'g-6', title: 'Coconut Tree Hill Mirissa', location: 'Mirissa, Southern Coast', category: 'Beaches', url: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1200&q=85', isCover: false, sectionUsage: ['Gallery'] },
    { id: 'g-7', title: 'Sri Lankan Leopard on Granite Rock', location: 'Yala National Park', category: 'Wildlife', url: 'https://images.unsplash.com/photo-1534177616072-ef7dc120449d?auto=format&fit=crop&w=1200&q=85', isCover: false, sectionUsage: ['Gallery'] },
    { id: 'g-8', title: 'Elephants by the Waterhole', location: 'Udawalawe National Park', category: 'Wildlife', url: 'https://images.unsplash.com/photo-1557050543-4d5f4e07ef46?auto=format&fit=crop&w=1200&q=85', isCover: false, sectionUsage: ['Gallery'] },
    { id: 'g-9', title: 'Historic Ceylon Tea Plucking', location: 'Dambatenne, Haputale', category: 'Experiences', url: 'https://images.unsplash.com/photo-1531747056595-07f6cbbe10ad?auto=format&fit=crop&w=1200&q=85', isCover: false, sectionUsage: ['Gallery'] }
  ]
};
