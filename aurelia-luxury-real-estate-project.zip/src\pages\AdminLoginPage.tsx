import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ShieldCheck, Lock, Mail, ArrowRight, ArrowLeft } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useRealEstate } from '../context/RealEstateContext';

export const AdminLoginPage: React.FC = () => {
  const { login, isAuthenticated } = useAuth();
  const { siteSettings } = useRealEstate();
  const navigate = useNavigate();

  const [email, setEmail] = useState('admin@aurelia.com');
  const [password, setPassword] = useState('aurelia2027');
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  React.useEffect(() => {
    if (isAuthenticated) {
      navigate('/admin');
    }
  }, [isAuthenticated, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');

    const res = await login(email, password);
    setLoading(false);

    if (res.success) {
      navigate('/admin');
    } else {
      setErrorMsg(res.message || 'Authentication failed');
    }
  };

  const handleDemoFill = () => {
    setEmail('admin@aurelia.com');
    setPassword('aurelia2027');
    setErrorMsg('');
  };

  return (
    <div className="min-h-screen bg-navy text-white flex flex-col justify-center py-20 px-4 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <Link to="/" className="flex items-center justify-center space-x-2.5 mb-6 group">
          <div className="w-8 h-8 border border-white/40 flex items-center justify-center group-hover:border-pink-muted transition-colors">
            <span className="text-white group-hover:text-pink-muted font-serif font-bold text-sm">
              A
            </span>
          </div>
          <span className="font-serif tracking-[0.24em] text-xl font-medium uppercase text-white">
            {siteSettings.logoText}
          </span>
        </Link>

        <div className="text-center">
          <div className="inline-flex items-center space-x-1.5 bg-white/10 px-3 py-1 rounded-full text-[11px] text-pink-muted font-medium mb-2.5">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Administrative Command Portal</span>
          </div>
          <h2 className="font-serif text-2xl font-medium text-white mb-1.5">
            Sign In to Private Dashboard
          </h2>
          <p className="text-cool-400 text-xs font-light">
            Restricted access for certified estate directors and brokerage partners.
          </p>
        </div>
      </div>

      <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-navy-midnight/80 border border-white/10 py-7 px-6 sm:px-8 rounded-sm shadow-xl">
          {errorMsg && (
            <div className="mb-4 bg-rose-950/60 border border-rose-500/40 text-rose-300 p-2.5 rounded-sm text-xs">
              {errorMsg}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div>
              <label className="block text-[10px] uppercase tracking-wider text-cool-400 font-medium mb-1">
                Admin Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-cool-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full bg-navy border border-white/15 pl-9 pr-3 py-2 text-xs text-white rounded-sm focus:border-pink-muted focus:outline-none"
                  placeholder="admin@aurelia.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] uppercase tracking-wider text-cool-400 font-medium mb-1">
                Security Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-cool-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full bg-navy border border-white/15 pl-9 pr-3 py-2 text-xs text-white rounded-sm focus:border-pink-muted focus:outline-none"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-white hover:bg-pink-soft text-navy py-2.5 px-4 text-xs uppercase tracking-wider font-semibold rounded-sm transition-colors flex items-center justify-center space-x-1.5 shadow-sm disabled:opacity-50"
              >
                <span>{loading ? 'Authenticating...' : 'Sign In'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>

          {/* Quick Demo Fill Box */}
          <div className="mt-5 pt-4 border-t border-white/10 text-center">
            <span className="text-[10px] text-cool-400 block mb-1.5 font-mono">
              admin@aurelia.com / aurelia2027
            </span>
            <button
              type="button"
              onClick={handleDemoFill}
              className="text-xs text-pink-muted hover:underline font-medium"
            >
              Fill Demo Credentials Automatically
            </button>
          </div>
        </div>

        <div className="mt-5 text-center">
          <Link
            to="/"
            className="inline-flex items-center space-x-1 text-xs text-cool-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-3 h-3" />
            <span>Return to Public Website</span>
          </Link>
        </div>
      </div>
    </div>
  );
};
