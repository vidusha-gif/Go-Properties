# SERENDIB JOURNEYS – Luxury Sri Lanka Travel Website & Image Management Suite

> **"Discover Sri Lanka. Experience the Extraordinary."**  
> *Bespoke private tours, comfortable luxury chauffeur transport, authentic Sri Lankan hospitality, and professional image management.*

---

## 🌟 Key Updates: Verified Authentic Sri Lankan Photography & Image Management Suite

### 1. Strict Authentic Sri Lanka Imagery Standard
All generic or foreign location photographs have been replaced with **strictly verified Sri Lankan destination imagery**:
- **Sigiriya**: Authentic aerial panoramic photograph of the UNESCO 5th-century Sigiriya Lion Rock Fortress.
- **Ella**: Authentic Demodara Nine Arch Bridge with tea valleys and the iconic railway track.
- **Kandy**: Authentic Sri Dalada Maligawa (Temple of the Sacred Tooth Relic) beside Kandy Lake.
- **Galle**: Authentic Galle Dutch Fort ramparts and white lighthouse.
- **Mirissa**: Authentic Coconut Tree Hill in Mirissa (the distinctive red clay promontory overlooking the turquoise Indian Ocean).
- **Nuwara Eliya**: Authentic high-grown Ceylon tea plantations and misty central highlands.
- **Yala**: Authentic Sri Lankan Leopard (*Panthera pardus kotiya*) on granite rocks.
- **Udawalawe**: Authentic wild Asian elephant herd with calves.
- **Dambulla**: Authentic Golden Rock Temple and ancient cave sanctuaries.
- **Anuradhapura**: Authentic white dome of the sacred Ruwanweli Seya Great Stupa.
- **Polonnaruwa**: Authentic Gal Vihara granite rock-cut Buddha sculptures.
- **Trincomalee**: Authentic Nilaveli and Pigeon Island marine coast.

---

## 📸 Complete Image Upload & Management System

You can upload your own authentic photographs directly from your computer without writing or changing any source code!

### Image Management Dashboard Features:
1. **Multi-Destination Upload Categories**:
   - 1. Homepage Hero Images
   - 2. Sigiriya
   - 3. Ella
   - 4. Kandy
   - 5. Galle
   - 6. Mirissa
   - 7. Nuwara Eliya
   - 8. Yala
   - 9. Trincomalee
   - 10. Dambulla
   - 11. Anuradhapura
   - 12. Polonnaruwa
   - 13. Udawalawe
   - 14. Minneriya
   - 15. Haputale
   - 16. Beaches
   - 17. Wildlife
   - 18. Vehicles & Transportation
   - 19. Gallery Collection
2. **Interactive Drag & Drop Upload Zone**:
   - Drag and drop multiple files at once directly from your computer desktop or file explorer.
   - Browse files button supporting `JPG`, `JPEG`, `PNG`, and `WebP`.
   - Live pre-upload preview queue showing file size, thumbnail, and title.
   - Upload progress bar with animated feedback.
3. **Set Main Cover Image**:
   - Select any uploaded photo as the **"Main Website Cover"** with 1 click.
   - When a cover image is changed, all corresponding cards across the Homepage, Tour Packages, Destinations Page, and Detail Modals automatically update in real time!
4. **In-Place Image Slot Replacement**:
   - Click **"Replace Photo"** on any existing photograph to swap it with your own file while preserving its layout position.
5. **Alt Text & SEO Management**:
   - Manage descriptive image titles and accessible alt tags.
6. **Active Placements Badges**:
   - Displays exactly which website sections use each photo.
7. **Zero-Setup Client Storage + Supabase Cloud Storage Ready**:
   - **Zero-Setup Mode**: Uploads are immediately stored in the browser's persistent storage (`localStorage` / IndexedDB) and persist across browser reloads!
   - **Supabase Cloud Bucket**: Configured for the `serendib-journeys-images` bucket whenever you enter your Supabase URL and Anon key in the Admin panel.

---

## 🚀 How to Access & Test the Image Management System

1. Open [`index.html`](file:///C:/Users/Novaline/.gemini/antigravity/scratch/serendib-journeys/index.html) in your web browser (Chrome, Edge, Firefox, Safari).
2. Scroll to the bottom and click **"📸 Image Library & Admin"** in the footer (or go via the admin portal).
3. Enter the admin passkey:
   ```
   serendib2026
   ```
4. Choose any destination (e.g. **Sigiriya**, **Ella**, **Mirissa**, or **Homepage Hero**).
5. Drag and drop any authentic Sri Lankan photo from your PC or click to browse files.
6. Click **"Confirm & Save Photographs to Website"**.
7. Click **"Set as Main Cover"** on your uploaded photo and switch back to the Homepage or Destinations page to see your photo live!

---

## 📋 Recommended Image Resolutions:
- **Homepage Hero**: `1920 × 1080 px` or higher.
- **Destination Cover**: `1600 × 1000 px` or higher.
- **Tour Packages**: `1200 × 800 px`.
- **Gallery Images**: `1600 px` or higher on the longest side.

All images are rendered with strict `object-fit: cover` and non-distorted aspect ratios to guarantee maximum desktop and mobile sharpness.
