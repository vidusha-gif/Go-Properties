import { Experience } from '../types';

export const INITIAL_EXPERIENCES: Experience[] = [
  {
    id: 'exp-1',
    title: 'Cultural & Heritage Tours',
    tagline: 'Walk through 2,500 years of living spiritual traditions and royal palaces.',
    image: 'https://images.unsplash.com/photo-1588598198321-9735fd52455f?auto=format&fit=crop&w=800&q=80',
    description: 'Explore the UNESCO Golden Triangle of Sigiriya, Polonnaruwa, Dambulla, and Kandy with expert local cultural historians and private temple blessings.',
    highlights: ['Temple of the Tooth Relic blessing ceremony', 'Sigiriya 5th-century royal fortress', 'Ancient monk cave meditations in Dambulla', 'Authentic village crafts and organic spice gardens']
  },
  {
    id: 'exp-2',
    title: 'Beach Holidays & Escapes',
    tagline: 'Endless golden palm-lined shores, warm turquoise waters, and coastal luxury.',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80',
    description: 'From the southern coast\'s chic boutique bays in Mirissa and Hiriketiya to the calm glass-clear waters of Pasikudah on the east coast, enjoy year-round summer.',
    highlights: ['Private beachfront boutique villas', 'Sunset seafood dining with feet in the sand', 'Surfing gentle point breaks or world-class waves', 'Sea turtle conservation and snorkel lagoons']
  },
  {
    id: 'exp-3',
    title: 'Wildlife Safaris & Game Drives',
    tagline: 'Encounter leopards, elephant herds, and blue whales in their natural habitats.',
    image: 'https://images.unsplash.com/photo-1534177616072-ef7dc120449d?auto=format&fit=crop&w=800&q=80',
    description: 'Sri Lanka is among the world\'s top biodiversity hotspots. Track elusive leopards in Yala, witness the gathering of 300 elephants in Minneriya, and sail alongside ocean giants.',
    highlights: ['Private customized 4x4 open-top safari jeeps', 'Certified wildlife naturalists & trackers', 'Luxury safari tented camps with bush dinners', 'High-probability leopard & sloth bear tracking']
  },
  {
    id: 'exp-4',
    title: 'Hill Country Adventures',
    tagline: 'Emerald tea plantations, cool mountain breezes, and thundering waterfalls.',
    image: 'https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=800&q=80',
    description: 'Ascend into the misty highlands of Nuwara Eliya and Ella. Pluck tea with local masters, hike scenic peaks, and unwind in colonial tea bungalows by roaring fireplaces.',
    highlights: ['Private tea factory masterclass & tea sommelier tasting', 'Hikes to Little Adam\'s Peak and Ella Rock', 'Colonial Afternoon High Tea at heritage mansions', 'Fresh strawberry farm tours and mountain cycling']
  },
  {
    id: 'exp-5',
    title: 'Scenic Train Journeys',
    tagline: 'The world\'s most famous panoramic railway through cloud forests and tea hills.',
    image: 'https://images.unsplash.com/photo-1546708973-b339540b5162?auto=format&fit=crop&w=800&q=80',
    description: 'The iconic blue train ride from Kandy through Nuwara Eliya to Ella is revered globally as an unforgettable bucket-list journey through dramatic mountain passes.',
    highlights: ['Guaranteed reserved observation & 1st-class seating', 'Luggage transferred separately by your private driver', 'Unmatched photography moments over the Nine Arch Bridge', 'Breathtaking viaducts and misty valley crossings']
  },
  {
    id: 'exp-6',
    title: 'Adventure & Nature Expeditions',
    tagline: 'White-water rapids, canopy zip-lines, jungle treks, and sea kayaking.',
    image: 'https://images.unsplash.com/photo-1432405972618-c60b0225b8f9?auto=format&fit=crop&w=800&q=80',
    description: 'For thrill-seekers: white-water rafting in Kitulgala (filming site of The Bridge on the River Kwai), abseiling waterfalls, canyoning, and rainforest expeditions.',
    highlights: ['Kitulgala Grade 3/4 river rafting', 'Flying Ravana mega zip-line over tea valleys', 'Sinharaja UNESCO virgin rainforest trekking', 'Lagoon kayaking with native waterbirds']
  },
  {
    id: 'exp-7',
    title: 'Romantic Honeymoon Experiences',
    tagline: 'Intimate private villas, candlelit beach dinners, and serene romantic escapes.',
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
    description: 'Designed exclusively for couples: private plunge pools overlooking tea hills, champagne sunset cruises, couples\' Ayurvedic spa rituals, and discreet luxury service.',
    highlights: ['Private candlelit dinners on secluded beaches', 'Complimentary honeymoon cakes & floral room arrangements', 'Couples herbal steam baths & synchronized massages', 'Bespoke romantic picnic hampers atop scenic hilltops']
  },
  {
    id: 'exp-8',
    title: 'Family Holidays & Safaris',
    tagline: 'Safe, effortless, enriching adventures curated for all generations.',
    image: 'https://images.unsplash.com/photo-1557050543-4d5f4e07ef46?auto=format&fit=crop&w=800&q=80',
    description: 'Stress-free family itineraries with spacious private vans, child-friendly safari encounters, gentle beach swimming bays, and interactive village cooking sessions.',
    highlights: ['Child safety seats & spacious luxury family vans', 'Visiting baby elephant transit homes & sea turtle hatcheries', 'Gentle scenic train journeys & interactive cooking classes', 'Family-suite accommodations with interconnecting rooms']
  }
];
