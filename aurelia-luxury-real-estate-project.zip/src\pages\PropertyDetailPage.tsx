import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  Heart,
  Scale,
  Share2,
  MapPin,
  Bed,
  Bath,
  Maximize2,
  Car,
  MessageCircle,
  CheckCircle2,
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Maximize,
  X,
  Play,
  Layers
} from 'lucide-react';
import { useRealEstate } from '../context/RealEstateContext';
import { PropertyCard } from '../components/property/PropertyCard';
import { PropertyMap } from '../components/property/PropertyMap';
import { formatPrice, formatArea, generateWhatsAppLink } from '../utils/helpers';

export const PropertyDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const {
    properties,
    isFavorite,
    toggleFavorite,
    isInCompare,
    toggleCompare,
    addLead,
    siteSettings
  } = useRealEstate();

  const property = properties.find(p => p.id === id);

  // Gallery state
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  // Media tabs
  const [mediaTab, setMediaTab] = useState<'photos' | 'floorplan' | 'video' | 'map'>('photos');

  // Inquiry Form state
  const [inquiryType, setInquiryType] = useState<'general' | 'viewing'>('viewing');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    preferredDate: '',
    preferredTime: '',
    message: ''
  });
  const [inquirySubmitted, setInquirySubmitted] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
    setSelectedPhotoIndex(0);
    setInquirySubmitted(false);
  }, [id]);

  if (!property) {
    return (
      <div className="min-h-screen bg-cool-50 pt-36 pb-20 px-4 text-center">
        <h2 className="font-serif text-2xl font-medium text-cool-900 mb-2">
          Property Not Found
        </h2>
        <p className="text-cool-500 text-xs mb-4">
          The requested listing does not exist or has been withdrawn from market.
        </p>
        <Link
          to="/properties"
          className="bg-navy text-white px-5 py-2 text-xs uppercase tracking-wider font-medium rounded-sm inline-block"
        >
          Return to Portfolio
        </Link>
      </div>
    );
  }

  const favorite = isFavorite(property.id);
  const inCompare = isInCompare(property.id);

  const allPhotos = [
    property.featuredImage,
    ...(property.galleryImages || [])
  ].filter((url, idx, arr) => arr.indexOf(url) === idx);

  // WhatsApp prefilled message
  const whatsappMsg = `Hello, I would like to inquire about ${property.title} (Ref: ${property.referenceId}) listed at ${formatPrice(property.price, siteSettings.currencySymbol, property.rentalPeriod)}.`;
  const whatsappUrl = generateWhatsAppLink(siteSettings.whatsappNumber, whatsappMsg);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addLead({
      type: inquiryType === 'viewing' ? 'property_viewing' : 'property_inquiry',
      propertyId: property.id,
      propertyTitle: property.title,
      propertyRef: property.referenceId,
      customerName: formData.name,
      email: formData.email,
      phone: formData.phone,
      preferredDate: formData.preferredDate || undefined,
      preferredTime: formData.preferredTime || undefined,
      message: formData.message || (inquiryType === 'viewing' ? 'Requested private viewing appointment.' : 'Requested general property dossier.'),
      source: 'Property Detail Page'
    });

    setInquirySubmitted(true);
    setFormData({
      name: '',
      email: '',
      phone: '',
      preferredDate: '',
      preferredTime: '',
      message: ''
    });
  };

  // Similar properties
  const similarProperties = properties
    .filter(p => p.id !== property.id && (p.type === property.type || p.location.city === property.location.city))
    .slice(0, 3);

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      {/* Lightbox Modal */}
      {lightboxOpen && (
        <div className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-between p-4 sm:p-6 animate-in fade-in duration-150">
          <div className="w-full flex items-center justify-between text-white text-xs z-10">
            <span className="font-mono text-cool-400">
              {selectedPhotoIndex + 1} / {allPhotos.length} • {property.title}
            </span>
            <button
              onClick={() => setLightboxOpen(false)}
              className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
              aria-label="Close Lightbox"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="relative max-w-5xl w-full h-[75vh] flex items-center justify-center">
            <img
              src={allPhotos[selectedPhotoIndex]}
              alt={property.title}
              className="max-h-full max-w-full object-contain select-none"
            />

            {allPhotos.length > 1 && (
              <>
                <button
                  onClick={() => setSelectedPhotoIndex(prev => (prev === 0 ? allPhotos.length - 1 : prev - 1))}
                  className="absolute left-2 p-2 rounded-full bg-black/50 hover:bg-black/80 text-white transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setSelectedPhotoIndex(prev => (prev === allPhotos.length - 1 ? 0 : prev + 1))}
                  className="absolute right-2 p-2 rounded-full bg-black/50 hover:bg-black/80 text-white transition-colors"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </>
            )}
          </div>

          <div className="flex space-x-1.5 overflow-x-auto max-w-xl py-2">
            {allPhotos.map((photo, i) => (
              <button
                key={i}
                onClick={() => setSelectedPhotoIndex(i)}
                className={`w-14 h-10 rounded-sm overflow-hidden border flex-shrink-0 transition-opacity ${
                  selectedPhotoIndex === i ? 'border-pink-muted opacity-100' : 'border-transparent opacity-40'
                }`}
              >
                <img src={photo} alt="thumb" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between pb-4 border-b border-cool-200/60 mb-5">
          <Link
            to="/properties"
            className="flex items-center space-x-1 text-xs uppercase tracking-wider font-medium text-cool-500 hover:text-navy transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Portfolio</span>
          </Link>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => toggleFavorite(property.id)}
              className={`flex items-center space-x-1 px-2.5 py-1 rounded-sm border text-xs font-medium transition-colors ${
                favorite
                  ? 'bg-pink-soft border-pink-muted text-navy'
                  : 'bg-white border-cool-200 text-cool-600 hover:border-cool-300'
              }`}
            >
              <Heart className={`w-3.5 h-3.5 ${favorite ? 'fill-current' : ''}`} />
              <span className="hidden sm:inline">{favorite ? 'Saved' : 'Save'}</span>
            </button>

            <button
              onClick={() => toggleCompare(property.id)}
              className={`flex items-center space-x-1 px-2.5 py-1 rounded-sm border text-xs font-medium transition-colors ${
                inCompare
                  ? 'bg-navy border-navy text-white'
                  : 'bg-white border-cool-200 text-cool-600 hover:border-cool-300'
              }`}
            >
              <Scale className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{inCompare ? 'Comparing' : 'Compare'}</span>
            </button>

            <button
              onClick={handleShare}
              className="flex items-center space-x-1 px-2.5 py-1 rounded-sm border bg-white border-cool-200 text-cool-600 hover:border-cool-300 text-xs font-medium transition-colors"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{copiedLink ? 'Copied' : 'Share'}</span>
            </button>
          </div>
        </div>

        {/* Title & Price Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-6">
          <div>
            <div className="flex flex-wrap items-center gap-1.5 mb-2">
              <span className="px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider bg-navy text-white rounded-sm">
                {property.purpose === 'sale' ? 'For Sale' : 'For Rent'}
              </span>
              {property.isLuxury && (
                <span className="px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider bg-pink-soft text-navy border border-pink-muted/60 rounded-sm">
                  Luxury
                </span>
              )}
              {property.status === 'reserved' && (
                <span className="px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider bg-cool-700 text-white rounded-sm">
                  Reserved
                </span>
              )}
              <span className="text-[10px] uppercase tracking-widest text-cool-400 font-mono ml-1.5">
                Ref: {property.referenceId}
              </span>
            </div>

            <h1 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-medium text-cool-900 mb-1.5">
              {property.title}
            </h1>

            <div className="flex items-center text-xs text-cool-500">
              <MapPin className="w-3.5 h-3.5 text-pink-muted mr-1 flex-shrink-0" />
              <span>
                {property.location.address}, {property.location.area}, {property.location.city}, {property.location.country}
              </span>
            </div>
          </div>

          <div className="lg:text-right">
            {property.pricePrefix && (
              <span className="text-[10px] uppercase tracking-wider text-cool-400 block -mb-0.5">
                {property.pricePrefix}
              </span>
            )}
            <span className="font-serif text-2xl sm:text-4xl font-medium text-navy block">
              {formatPrice(property.price, siteSettings.currencySymbol, property.rentalPeriod)}
            </span>
          </div>
        </div>

        {/* Media Presentation: Tabs & Gallery */}
        <div className="mb-10">
          <div className="flex items-center space-x-1.5 border-b border-cool-200/70 pb-2 mb-3">
            <button
              onClick={() => setMediaTab('photos')}
              className={`px-3 py-1 text-xs uppercase tracking-wider font-medium rounded-sm transition-colors ${
                mediaTab === 'photos' ? 'bg-navy text-white' : 'text-cool-600 hover:text-navy bg-white border border-cool-200'
              }`}
            >
              <span>Photos ({allPhotos.length})</span>
            </button>

            {property.floorPlanUrl && (
              <button
                onClick={() => setMediaTab('floorplan')}
                className={`flex items-center space-x-1 px-3 py-1 text-xs uppercase tracking-wider font-medium rounded-sm transition-colors ${
                  mediaTab === 'floorplan' ? 'bg-navy text-white' : 'text-cool-600 hover:text-navy bg-white border border-cool-200'
                }`}
              >
                <Layers className="w-3 h-3" />
                <span>Floor Plan</span>
              </button>
            )}

            {property.videoTourUrl && (
              <button
                onClick={() => setMediaTab('video')}
                className={`flex items-center space-x-1 px-3 py-1 text-xs uppercase tracking-wider font-medium rounded-sm transition-colors ${
                  mediaTab === 'video' ? 'bg-navy text-white' : 'text-cool-600 hover:text-navy bg-white border border-cool-200'
                }`}
              >
                <Play className="w-3 h-3" />
                <span>Video Tour</span>
              </button>
            )}

            <button
              onClick={() => setMediaTab('map')}
              className={`flex items-center space-x-1 px-3 py-1 text-xs uppercase tracking-wider font-medium rounded-sm transition-colors ${
                mediaTab === 'map' ? 'bg-navy text-white' : 'text-cool-600 hover:text-navy bg-white border border-cool-200'
              }`}
            >
              <MapPin className="w-3 h-3" />
              <span>Location Map</span>
            </button>
          </div>

          {mediaTab === 'photos' && (
            <div>
              <div className="relative aspect-[16/9] w-full bg-navy rounded-sm overflow-hidden shadow-sm">
                <img
                  src={allPhotos[selectedPhotoIndex]}
                  alt={property.title}
                  className="w-full h-full object-cover cursor-pointer"
                  onClick={() => setLightboxOpen(true)}
                />

                <button
                  onClick={() => setLightboxOpen(true)}
                  className="absolute bottom-3 right-3 bg-black/60 hover:bg-black/80 text-white px-3 py-1.5 rounded-sm text-[11px] uppercase tracking-wider font-medium flex items-center space-x-1.5 backdrop-blur-md transition-colors"
                >
                  <Maximize className="w-3.5 h-3.5" />
                  <span>Full Screen</span>
                </button>

                {allPhotos.length > 1 && (
                  <>
                    <button
                      onClick={() => setSelectedPhotoIndex(prev => (prev === 0 ? allPhotos.length - 1 : prev - 1))}
                      className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40 hover:bg-black/70 text-white transition-colors"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setSelectedPhotoIndex(prev => (prev === allPhotos.length - 1 ? 0 : prev + 1))}
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40 hover:bg-black/70 text-white transition-colors"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </>
                )}
              </div>

              {allPhotos.length > 1 && (
                <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-8 gap-2 mt-2.5">
                  {allPhotos.map((photo, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedPhotoIndex(idx)}
                      className={`relative aspect-[4/3] rounded-sm overflow-hidden border transition-all ${
                        selectedPhotoIndex === idx ? 'border-pink-muted scale-95 shadow-sm' : 'border-transparent opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={photo} alt="thumbnail" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {mediaTab === 'floorplan' && (
            <div className="bg-white p-6 rounded-sm border border-cool-200 text-center">
              <h3 className="font-serif text-lg font-medium text-cool-900 mb-3">
                Architectural Floor Plan
              </h3>
              <div className="max-w-2xl mx-auto rounded-sm overflow-hidden border border-cool-200">
                <img
                  src={property.floorPlanUrl}
                  alt="Floor plan"
                  className="w-full h-auto object-contain"
                />
              </div>
            </div>
          )}

          {mediaTab === 'video' && (
            <div className="aspect-[16/9] bg-navy-deep rounded-sm overflow-hidden flex items-center justify-center text-white">
              <div className="text-center p-6 max-w-sm">
                <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-3 text-pink-muted">
                  <Play className="w-5 h-5 ml-0.5" />
                </div>
                <h3 className="font-serif text-lg font-medium mb-1">Cinematic Video Tour</h3>
                <p className="text-[11px] text-cool-400 font-light mb-3">
                  4K drone footage and high-fidelity interior walkthrough.
                </p>
                <a
                  href={property.videoTourUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-white text-navy hover:bg-pink-soft px-4 py-1.5 text-xs uppercase tracking-wider font-medium rounded-sm inline-block"
                >
                  Play Video Tour
                </a>
              </div>
            </div>
          )}

          {mediaTab === 'map' && (
            <div>
              <PropertyMap properties={[property]} height="400px" />
            </div>
          )}
        </div>

        {/* 2-Column Content Layout (Details & Sticky Inquiry) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column (8 cols): Description, Specs, Features */}
          <div className="lg:col-span-8 space-y-8">
            {/* Overview Key Metrics Bar */}
            <div className="bg-white border border-cool-200/80 rounded-sm p-5 grid grid-cols-2 sm:grid-cols-4 gap-4 shadow-sm">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-sm bg-cool-50 flex items-center justify-center text-navy">
                  <Bed className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-cool-400 font-medium block">
                    Bedrooms
                  </span>
                  <span className="font-serif text-lg font-medium text-cool-900">
                    {property.bedrooms > 0 ? property.bedrooms : 'N/A'}
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-sm bg-cool-50 flex items-center justify-center text-navy">
                  <Bath className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-cool-400 font-medium block">
                    Bathrooms
                  </span>
                  <span className="font-serif text-lg font-medium text-cool-900">
                    {property.bathrooms > 0 ? property.bathrooms : 'N/A'}
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-sm bg-cool-50 flex items-center justify-center text-navy">
                  <Maximize2 className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-cool-400 font-medium block">
                    Floor Area
                  </span>
                  <span className="font-serif text-lg font-medium text-cool-900">
                    {property.floorAreaSqFt > 0 ? `${property.floorAreaSqFt.toLocaleString()} sqft` : 'N/A'}
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-sm bg-cool-50 flex items-center justify-center text-navy">
                  <Car className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-cool-400 font-medium block">
                    Parking
                  </span>
                  <span className="font-serif text-lg font-medium text-cool-900">
                    {property.parkingSpaces > 0 ? `${property.parkingSpaces} Bays` : 'Street'}
                  </span>
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="bg-white border border-cool-200/80 rounded-sm p-6 shadow-sm">
              <h2 className="font-serif text-xl font-medium text-cool-900 mb-3 border-b border-cool-100 pb-2">
                Property Overview
              </h2>
              {property.tagline && (
                <p className="font-serif italic text-base text-cool-700 mb-3">
                  "{property.tagline}"
                </p>
              )}
              <div className="text-cool-600 text-xs sm:text-sm font-light leading-relaxed space-y-3">
                <p>{property.description}</p>
                <p>
                  Built with rigorous attention to structural engineering and acoustic serenity, this residence effortlessly integrates natural stone finishes with state-of-the-art technological automation.
                </p>
              </div>
            </div>

            {/* Specifications Table */}
            <div className="bg-white border border-cool-200/80 rounded-sm p-6 shadow-sm">
              <h2 className="font-serif text-xl font-medium text-cool-900 mb-4 border-b border-cool-100 pb-2">
                Specifications
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2.5 gap-x-6 text-xs">
                <div className="flex justify-between py-1.5 border-b border-cool-100">
                  <span className="text-cool-400">Reference ID</span>
                  <span className="font-medium text-cool-900">{property.referenceId}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-cool-100">
                  <span className="text-cool-400">Property Type</span>
                  <span className="font-medium text-cool-900 uppercase">{property.type}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-cool-100">
                  <span className="text-cool-400">Status</span>
                  <span className="font-medium text-cool-900 uppercase">{property.status}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-cool-100">
                  <span className="text-cool-400">Floor Area</span>
                  <span className="font-medium text-cool-900">{formatArea(property.floorAreaSqFt)}</span>
                </div>
                {property.landAreaSqFt && (
                  <div className="flex justify-between py-1.5 border-b border-cool-100">
                    <span className="text-cool-400">Land Area</span>
                    <span className="font-medium text-cool-900">{property.landAreaSqFt.toLocaleString()} sqft</span>
                  </div>
                )}
                {property.yearBuilt && (
                  <div className="flex justify-between py-1.5 border-b border-cool-100">
                    <span className="text-cool-400">Year Built</span>
                    <span className="font-medium text-cool-900">{property.yearBuilt}</span>
                  </div>
                )}
                <div className="flex justify-between py-1.5 border-b border-cool-100">
                  <span className="text-cool-400">Furnishing</span>
                  <span className="font-medium text-cool-900 capitalize">{property.furnishedStatus}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-cool-100">
                  <span className="text-cool-400">Location</span>
                  <span className="font-medium text-cool-900">{property.location.city}, {property.location.country}</span>
                </div>
              </div>
            </div>

            {/* Features & Amenities */}
            <div className="bg-white border border-cool-200/80 rounded-sm p-6 shadow-sm">
              <h2 className="font-serif text-xl font-medium text-cool-900 mb-4 border-b border-cool-100 pb-2">
                Features & Amenities
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                {property.amenities.map((item, idx) => (
                  <div key={idx} className="flex items-center space-x-2 text-xs text-cool-700">
                    <span className="text-pink-muted font-bold text-xs">✓</span>
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column (4 cols): Sticky Private Inquiry Card */}
          <div className="lg:col-span-4">
            <div className="sticky top-28 bg-white border border-cool-200/80 rounded-sm shadow-sm p-5 sm:p-6">
              <div className="border-b border-cool-100 pb-3 mb-4">
                <span className="text-[10px] uppercase tracking-[0.2em] text-cool-400 font-semibold block mb-0.5">
                  Private Advisory
                </span>
                <h3 className="font-serif text-xl font-medium text-cool-900">
                  Direct Inquiry
                </h3>
              </div>

              {/* Inquiry Type Tabs */}
              <div className="grid grid-cols-2 gap-1.5 p-0.5 bg-cool-100 rounded-sm mb-4">
                <button
                  type="button"
                  onClick={() => setInquiryType('viewing')}
                  className={`py-1.5 text-[11px] font-medium uppercase tracking-wider rounded-sm transition-all ${
                    inquiryType === 'viewing'
                      ? 'bg-navy text-white font-semibold shadow-sm'
                      : 'text-cool-600 hover:text-navy'
                  }`}
                >
                  Book Viewing
                </button>
                <button
                  type="button"
                  onClick={() => setInquiryType('general')}
                  className={`py-1.5 text-[11px] font-medium uppercase tracking-wider rounded-sm transition-all ${
                    inquiryType === 'general'
                      ? 'bg-navy text-white font-semibold shadow-sm'
                      : 'text-cool-600 hover:text-navy'
                  }`}
                >
                  Request Dossier
                </button>
              </div>

              {inquirySubmitted ? (
                <div className="bg-emerald-50 border border-emerald-200 p-5 rounded-sm text-center animate-in fade-in">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-1.5" />
                  <h4 className="font-serif text-lg font-medium text-emerald-900 mb-1">
                    Inquiry Lodged
                  </h4>
                  <p className="text-xs text-emerald-700 mb-3 font-light">
                    Your request regarding {property.referenceId} has been sent to our private client partner.
                  </p>
                  <button
                    onClick={() => setInquirySubmitted(false)}
                    className="text-xs text-emerald-900 font-semibold underline"
                  >
                    Send another inquiry
                  </button>
                </div>
              ) : (
                <form onSubmit={handleInquirySubmit} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Your Full Name"
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 px-2.5 py-1.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="client@advisory.com"
                        value={formData.email}
                        onChange={e => setFormData({ ...formData, email: e.target.value })}
                        className="w-full bg-cool-50 border border-cool-200 px-2.5 py-1.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                        Phone *
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="+44 20..."
                        value={formData.phone}
                        onChange={e => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full bg-cool-50 border border-cool-200 px-2.5 py-1.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                      />
                    </div>
                  </div>

                  {inquiryType === 'viewing' && (
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                          Date
                        </label>
                        <input
                          type="date"
                          value={formData.preferredDate}
                          onChange={e => setFormData({ ...formData, preferredDate: e.target.value })}
                          className="w-full bg-cool-50 border border-cool-200 px-2 py-1.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                          Time Slot
                        </label>
                        <select
                          value={formData.preferredTime}
                          onChange={e => setFormData({ ...formData, preferredTime: e.target.value })}
                          className="w-full bg-cool-50 border border-cool-200 px-2 py-1.5 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none"
                        >
                          <option value="">Any Time</option>
                          <option value="Morning">Morning</option>
                          <option value="Afternoon">Afternoon</option>
                          <option value="Twilight">Twilight</option>
                        </select>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-cool-500 font-medium mb-1">
                      Message / Requirements
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Please note any viewing requests or questions..."
                      value={formData.message}
                      onChange={e => setFormData({ ...formData, message: e.target.value })}
                      className="w-full bg-cool-50 border border-cool-200 p-2 text-xs text-cool-800 rounded-sm focus:border-navy focus:outline-none font-light"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-navy hover:bg-navy-midnight text-white py-2.5 text-xs uppercase tracking-wider font-medium rounded-sm transition-colors"
                  >
                    {inquiryType === 'viewing' ? 'Request Private Viewing' : 'Request Official Dossier'}
                  </button>
                </form>
              )}

              {/* Instant WhatsApp Action */}
              <div className="mt-3 pt-3 border-t border-cool-100">
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full border border-cool-200 text-cool-700 hover:border-navy hover:text-navy py-2 rounded-sm text-xs uppercase tracking-wider font-medium flex items-center justify-center space-x-1.5 transition-colors"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-pink-muted" />
                  <span>WhatsApp Inquiry</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Similar Properties */}
        {similarProperties.length > 0 && (
          <div className="mt-16 pt-12 border-t border-cool-200/60">
            <div className="flex items-center justify-between mb-6">
              <div>
                <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1">
                  Related Holdings
                </span>
                <h3 className="font-serif text-2xl font-medium text-cool-900">
                  Similar Curated Properties
                </h3>
              </div>
              <Link
                to="/properties"
                className="text-xs font-medium uppercase tracking-wider text-navy hover:text-black"
              >
                View Collection
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {similarProperties.map(sim => (
                <PropertyCard key={sim.id} property={sim} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
