import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Award, Globe, ArrowRight } from 'lucide-react';
import { useRealEstate } from '../context/RealEstateContext';

export const AboutPage: React.FC = () => {
  const { siteSettings } = useRealEstate();

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      {/* Editorial Header */}
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16">
        <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1.5">
          Distinction & Fiduciary
        </span>
        <h1 className="font-serif text-3xl sm:text-5xl font-medium text-cool-900 mb-4 leading-tight">
          Curating the World’s Most Architecturally Distinguished Residences
        </h1>
        <p className="text-cool-600 text-xs sm:text-sm font-light leading-relaxed">
          Founded on the principles of discretion, forensic advisory, and architectural reverence, {siteSettings.companyName} represents family offices and private collectors in landmark real estate transactions.
        </p>
      </div>

      {/* Narrative Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-6">
            <div className="relative aspect-[4/3] rounded-sm overflow-hidden shadow-sm">
              <img
                src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80"
                alt="Aurelia Private Client Office"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="lg:col-span-6 space-y-4">
            <span className="text-[10px] uppercase tracking-[0.2em] text-cool-400 font-semibold block">
              The Aurelia Standard
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-medium text-cool-900 leading-tight">
              A Fiduciary Model Built on Absolute Discretion
            </h2>
            <div className="text-cool-600 text-xs sm:text-sm font-light leading-relaxed space-y-3">
              <p>
                In the prime tiers of global real estate, true value is not defined by sheer volume or public notoriety. It is measured in architectural integrity, acoustic tranquility, and immutable legal certainty.
              </p>
              <p>
                Our private advisory practice intentionally limits its client roster. This discipline ensures every property instruction receives the undivided strategic attention of our founding partners, navigating both public showcases and off-market mandates with consummate skill.
              </p>
            </div>

            <div className="border-t border-cool-200 pt-5 grid grid-cols-2 gap-4">
              <div>
                <span className="font-serif text-2xl font-bold text-navy block">
                  $3.5B+
                </span>
                <span className="text-[10px] uppercase tracking-wider text-cool-400 font-medium">
                  Advisory Transactions
                </span>
              </div>
              <div>
                <span className="font-serif text-2xl font-bold text-navy block">
                  100%
                </span>
                <span className="text-[10px] uppercase tracking-wider text-cool-400 font-medium">
                  Confidential Mandates
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Principles */}
      <div className="bg-white border-t border-b border-cool-200/60 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-xl mx-auto mb-12">
            <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1">
              Foundational Principles
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-medium text-cool-900">
              Our Core Advisory Standards
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="bg-cool-50 p-6 rounded-sm border border-cool-200/70">
              <div className="w-8 h-8 rounded-sm bg-white flex items-center justify-center text-navy mb-3">
                <Shield className="w-4 h-4" />
              </div>
              <h3 className="font-serif text-lg font-medium text-cool-900 mb-1.5">
                Discretion & NDAs
              </h3>
              <p className="text-cool-500 text-xs font-light leading-relaxed">
                We handle private residences without unsolicited public exposure, protecting the identity and assets of our high-profile patrons.
              </p>
            </div>

            <div className="bg-cool-50 p-6 rounded-sm border border-cool-200/70">
              <div className="w-8 h-8 rounded-sm bg-white flex items-center justify-center text-navy mb-3">
                <Award className="w-4 h-4" />
              </div>
              <h3 className="font-serif text-lg font-medium text-cool-900 mb-1.5">
                Architectural Rarity
              </h3>
              <p className="text-cool-500 text-xs font-light leading-relaxed">
                We strictly curate properties that possess design excellence, enduring building materials, and irreplaceable topographical provenance.
              </p>
            </div>

            <div className="bg-cool-50 p-6 rounded-sm border border-cool-200/70">
              <div className="w-8 h-8 rounded-sm bg-white flex items-center justify-center text-navy mb-3">
                <Globe className="w-4 h-4" />
              </div>
              <h3 className="font-serif text-lg font-medium text-cool-900 mb-1.5">
                Cross-Border Synergy
              </h3>
              <p className="text-cool-500 text-xs font-light leading-relaxed">
                Seamless coordination between our London, Dubai, French Riviera, and Swiss partners to navigate multi-jurisdictional family office wealth.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Link to Team */}
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-16">
        <h3 className="font-serif text-2xl font-medium text-cool-900 mb-2">
          Meet Our Senior Brokerage Partners
        </h3>
        <p className="text-cool-500 text-xs font-light mb-6 max-w-md mx-auto">
          Learn more about our executive team and their specialized regional practice areas across prime international markets.
        </p>
        <Link
          to="/team"
          className="bg-navy hover:bg-navy-midnight text-white px-6 py-2.5 text-xs uppercase tracking-wider font-medium rounded-sm inline-flex items-center space-x-1.5 transition-colors"
        >
          <span>View Senior Leadership</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
};
