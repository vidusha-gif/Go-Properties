import React from 'react';
import { useRealEstate } from '../context/RealEstateContext';

export const PrivacyPage: React.FC = () => {
  const { siteSettings } = useRealEstate();

  return (
    <div className="min-h-screen bg-cool-50 pt-28 pb-20">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 bg-white border border-cool-200/80 rounded-sm p-6 sm:p-10 shadow-sm">
        <span className="text-[10px] uppercase tracking-[0.25em] text-cool-400 font-semibold block mb-1">
          Regulatory Compliance
        </span>
        <h1 className="font-serif text-2xl sm:text-4xl font-medium text-cool-900 mb-4">
          Privacy Policy & Client Data Protection
        </h1>
        <p className="text-xs text-cool-400 mb-6 pb-3 border-b border-cool-100">
          Last updated: November 2026 • Compliant with UK GDPR, EU GDPR, and DIFC Data Protection Regulations
        </p>

        <div className="text-xs sm:text-sm text-cool-600 font-light leading-relaxed space-y-5">
          <section>
            <h2 className="font-serif text-base sm:text-lg font-medium text-cool-900 mb-1.5">1. Commitment to Absolute Confidentiality</h2>
            <p>
              {siteSettings.companyName} operates as a bespoke real estate advisory practice. We recognize that high-net-worth clients, family offices, and institutional investors require rigorous confidentiality regarding identity, holdings, and communications.
            </p>
          </section>

          <section>
            <h2 className="font-serif text-base sm:text-lg font-medium text-cool-900 mb-1.5">2. Information We Collect</h2>
            <p>
              We collect information provided directly by you when submitting property inquiries, viewing requests, or listing instructions. This typically includes your name, email address, telephone number, and property preference parameters.
            </p>
          </section>

          <section>
            <h2 className="font-serif text-base sm:text-lg font-medium text-cool-900 mb-1.5">3. Non-Disclosure & Third-Party Restrictions</h2>
            <p>
              We do not sell, license, or syndicate client contact details to external marketing agencies or public brokers. Information is shared strictly on a confidential basis with certified notaries, conveyancers, and surveyors explicitly instructed on your transaction.
            </p>
          </section>

          <section>
            <h2 className="font-serif text-base sm:text-lg font-medium text-cool-900 mb-1.5">4. Your Statutory Rights</h2>
            <p>
              You maintain the absolute right to request an audit of data held under your name, request immediate redaction or deletion, or withdraw from communications by contacting our compliance office at <strong>{siteSettings.email}</strong>.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};
