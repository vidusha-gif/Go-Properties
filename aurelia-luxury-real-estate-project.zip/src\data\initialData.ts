import { Property, LocationItem, BlogPost, Testimonial, TeamMember, FAQItem, SiteSettings, InquiryLead } from '../types';

export const initialSiteSettings: SiteSettings = {
  companyName: "AURELIA ESTATES",
  tagline: "Curators of Exceptional Living & Architectural Distinction",
  logoText: "AURELIA",
  phone: "+44 (0) 20 7946 0888",
  whatsappNumber: "447946088800",
  whatsappDisplay: "+44 7946 088800",
  email: "privateclient@aureliaestates.com",
  address: "48 Berkeley Square, Mayfair, London W1J 5AT, United Kingdom",
  cityCountry: "London & Global Offices",
  currencySymbol: "$",
  currencyCode: "USD",
  businessHours: "Monday – Saturday: 08:30 – 19:30 GMT",
  heroHeadline: "Find a Property That Feels Like Home.",
  heroSubheadline: "Discover exceptional properties, prime international investments, and bespoke residences designed around the way you aspire to live.",
  heroImages: [
    "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=2400&q=85",
    "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=2400&q=85",
    "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=2400&q=85"
  ],
  socialLinks: {
    instagram: "https://instagram.com",
    linkedin: "https://linkedin.com",
    facebook: "https://facebook.com",
    youtube: "https://youtube.com"
  }
};

export const initialProperties: Property[] = [
  {
    id: "prop-1",
    referenceId: "AUE-8901",
    title: "The Glasshouse Promenade Villa",
    tagline: "Architectural masterpiece overlooking panoramic city and canyon views",
    description: "Conceived by an award-winning modernist architect, this tour-de-force private sanctuary fuses cantilevered structural concrete with floor-to-ceiling acoustic glass walls. Enjoy sweeping, uninterrupted twilight vistas stretching from the skyline to the Pacific horizon. Features an infinity-edge ozone pool, private wine cellar holding 1,200 bottles, dual Italian chef's kitchens by Boffi, and state-of-the-art Savant smart home automation.",
    purpose: "sale",
    type: "villa",
    status: "available",
    price: 18500000,
    currency: "$",
    pricePrefix: "Guide Price",
    isFeatured: true,
    isLuxury: true,
    isPriceReduced: false,
    location: {
      address: "1420 Loma Linda Drive",
      area: "Beverly Hills",
      city: "Los Angeles",
      state: "California",
      country: "United States",
      lat: 34.0900,
      lng: -118.4100,
      hideExactAddress: false
    },
    bedrooms: 6,
    bathrooms: 8,
    parkingSpaces: 5,
    floorAreaSqFt: 11400,
    landAreaSqFt: 38500,
    yearBuilt: 2023,
    furnishedStatus: "furnished",
    featuredImage: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1800&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600573472550-8090b5e0745e?auto=format&fit=crop&w=1800&q=85"
    ],
    floorPlanUrl: "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1200&q=80",
    videoTourUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    virtualTour3DUrl: "https://my.matterport.com/show/?m=sample",
    amenities: [
      "Infinity Swimming Pool",
      "Private Spa & Sauna",
      "1,200 Bottle Wine Cellar",
      "Private Cinema",
      "Boffi Italian Kitchen",
      "Savant Smart Home Automation",
      "Gated Motor Court",
      "Panoramic Skyline Views",
      "Staff Quarters",
      "Private Gymnasium"
    ],
    nearbyFacilities: [
      { name: "Rodeo Drive Luxury Boutiques", distance: "6 mins" },
      { name: "The Beverly Hills Hotel", distance: "4 mins" },
      { name: "Private Jet Center (Van Nuys)", distance: "18 mins" }
    ],
    createdAt: "2026-10-15T10:00:00Z",
    updatedAt: "2026-11-10T12:00:00Z",
    viewsCount: 3840
  },
  {
    id: "prop-2",
    referenceId: "AUE-9104",
    title: "The Azure Waterfront Estate",
    tagline: "Direct private beach access with unobstructed views of the Arabian Gulf",
    description: "Positioned on an elite frond of the iconic Palm Jumeirah, The Azure represents the pinnacle of beachfront opulence. Crafted with Turkish Travertine stone and bespoke bronze millwork, the estate spans over 13,800 interior square feet. Offering 7 sumptuous en-suite staterooms, a sunken fire pit lounge over the water, private yacht mooring berth, and rooftop observation terrace.",
    purpose: "sale",
    type: "villa",
    status: "available",
    price: 24750000,
    currency: "$",
    pricePrefix: "Price on Application",
    isFeatured: true,
    isLuxury: true,
    location: {
      address: "Frond J, Palm Jumeirah",
      area: "Palm Jumeirah",
      city: "Dubai",
      country: "United Arab Emirates",
      lat: 25.1180,
      lng: 55.1320,
      hideExactAddress: false
    },
    bedrooms: 7,
    bathrooms: 9,
    parkingSpaces: 6,
    floorAreaSqFt: 13800,
    landAreaSqFt: 22000,
    yearBuilt: 2024,
    furnishedStatus: "furnished",
    featuredImage: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1800&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600607687644-c7171b42498b?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1800&q=85"
    ],
    amenities: [
      "Private White Sand Beach",
      "Yacht Mooring Berth",
      "Rooftop Sunset Lounge",
      "Heated Olympic Length Pool",
      "Sunken Water Firepit",
      "Sub-Zero & Wolf Appliances",
      "Steam & Moroccan Hammam",
      "Security Biometric Access",
      "Separate Chauffeur & Maid Suites"
    ],
    createdAt: "2026-10-20T11:00:00Z",
    updatedAt: "2026-11-15T09:30:00Z",
    viewsCount: 5120
  },
  {
    id: "prop-3",
    referenceId: "AUE-4029",
    title: "The Mayfair Crown Duplex Penthouse",
    tagline: "Quintessential British grandeur paired with bespoke contemporary minimalism",
    description: "Commanding the highest two floors of an immaculate Portland stone building in the heart of Mayfair, this duplex penthouse is a collector's residence. Features direct key-coded lift entry, soaring double-height reception gallery with skylights, private south-facing wrap-around landscaped garden terrace with outdoor fireplace, and 24-hour uniformed concierge.",
    purpose: "sale",
    type: "penthouse",
    status: "available",
    price: 17800000,
    currency: "$",
    pricePrefix: "Guide Price",
    isFeatured: true,
    isLuxury: true,
    isPriceReduced: true,
    originalPrice: 19500000,
    location: {
      address: "12 Grosvenor Square",
      area: "Mayfair",
      city: "London",
      country: "United Kingdom",
      lat: 51.5115,
      lng: -0.1510,
      hideExactAddress: false
    },
    bedrooms: 4,
    bathrooms: 5,
    parkingSpaces: 2,
    floorAreaSqFt: 6200,
    yearBuilt: 2022,
    furnishedStatus: "furnished",
    featuredImage: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1800&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600210491892-03d54c0aaf87?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1800&q=85"
    ],
    amenities: [
      "Wrap-around Landscaped Terrace",
      "24-Hour Uniformed Concierge",
      "Direct Private Elevator Access",
      "Double-height Library with Fireplace",
      "Temperature-controlled Wine Room",
      "Valet Underground Parking",
      "Air Conditioning throughout",
      "Bespoke Minotti Furniture Included"
    ],
    createdAt: "2026-09-18T14:20:00Z",
    updatedAt: "2026-11-12T08:15:00Z",
    viewsCount: 2940
  },
  {
    id: "prop-4",
    referenceId: "AUE-3310",
    title: "Villa Belle Époque Cap d'Antibes",
    tagline: "A secluded Mediterranean haven nestled in mature private pine and olive groves",
    description: "Overlooking the azure waters of the Baie des Anges, this historic yet meticulously restored Belle Époque residence offers unmatched glamour and French Riviera tranquility. Boasting landscaped botanical gardens designed by Jean Mus, a heated 20-meter infinity pool, private tennis court, and separate guest lodge.",
    purpose: "sale",
    type: "villa",
    status: "available",
    price: 13500000,
    currency: "$",
    pricePrefix: "Guide Price",
    isFeatured: true,
    isLuxury: true,
    location: {
      address: "Boulevard de la Garoupe",
      area: "Cap d'Antibes",
      city: "Antibes",
      country: "France",
      lat: 43.5530,
      lng: 7.1270,
      hideExactAddress: false
    },
    bedrooms: 6,
    bathrooms: 7,
    parkingSpaces: 8,
    floorAreaSqFt: 8800,
    landAreaSqFt: 64000,
    yearBuilt: 1928,
    furnishedStatus: "furnished",
    featuredImage: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1800&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1512915922686-57c11dde9b6b?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&w=1800&q=85"
    ],
    amenities: [
      "Mediterranean Sea Panorama",
      "Championship Tennis Court",
      "Heated 20m Pool",
      "Botanical Gardens by Jean Mus",
      "Independent 2-Bedroom Guest Villa",
      "Helipad Landing Rights",
      "Wine Tasting Cellar",
      "CCTV Perimeter Security"
    ],
    createdAt: "2026-10-01T09:00:00Z",
    updatedAt: "2026-11-08T15:00:00Z",
    viewsCount: 4210
  },
  {
    id: "prop-5",
    referenceId: "AUE-6102",
    title: "The Knightsbridge Garden Duplex",
    tagline: "Exclusive garden residence with five-star hotel serviced amenities",
    description: "An extraordinary rental opportunity in one of London's most sought-after garden squares. This duplex apartment features double-height reception rooms opening onto a private manicured English garden, full hotel services including daily housekeeping, private gym, vitality pool, and secure subterranean parking.",
    purpose: "rent",
    type: "apartment",
    status: "available",
    price: 32000,
    currency: "$",
    rentalPeriod: "month",
    pricePrefix: "Per Month",
    isFeatured: true,
    isLuxury: true,
    location: {
      address: "Egerton Gardens",
      area: "Knightsbridge",
      city: "London",
      country: "United Kingdom",
      lat: 51.4960,
      lng: -0.1660,
      hideExactAddress: false
    },
    bedrooms: 3,
    bathrooms: 4,
    parkingSpaces: 2,
    floorAreaSqFt: 3850,
    yearBuilt: 2021,
    furnishedStatus: "furnished",
    featuredImage: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1800&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1800&q=85"
    ],
    amenities: [
      "Private Manicured Garden",
      "24/7 Concierge & Valet",
      "Indoor Vitality Pool & Spa",
      "Daily Housekeeping Included",
      "Private Wine Storage",
      "Direct Harrods Delivery Service"
    ],
    createdAt: "2026-11-01T10:00:00Z",
    updatedAt: "2026-11-18T16:00:00Z",
    viewsCount: 1890
  },
  {
    id: "prop-6",
    referenceId: "AUE-7209",
    title: "Tribeca Cast-Iron Architectural Loft",
    tagline: "Authentic historic loft with museum-quality art walls and soaring timber ceilings",
    description: "Spread over 4,500 square feet in a landmarked 19th-century cast-iron building, this rental residence features 14-foot beamed ceilings, fluted Corinthian columns, a bespoke blackened steel and marble kitchen, gas fireplace, and a soundproof recording and cinema suite.",
    purpose: "rent",
    type: "apartment",
    status: "available",
    price: 38000,
    currency: "$",
    rentalPeriod: "month",
    pricePrefix: "Per Month",
    isFeatured: false,
    isLuxury: true,
    location: {
      address: "68 Franklin Street",
      area: "Tribeca",
      city: "New York",
      state: "New York",
      country: "United States",
      lat: 40.7180,
      lng: -74.0040,
      hideExactAddress: false
    },
    bedrooms: 3,
    bathrooms: 3,
    parkingSpaces: 1,
    floorAreaSqFt: 4500,
    yearBuilt: 1895,
    furnishedStatus: "furnished",
    featuredImage: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1800&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1800&q=85"
    ],
    amenities: [
      "14ft Timber Beamed Ceilings",
      "Private Keyed Elevator",
      "Original Cast-Iron Columns",
      "Gas Linear Fireplace",
      "Soundproof Cinema Suite",
      "Custom Italian Molteni Wardrobes"
    ],
    createdAt: "2026-10-12T11:15:00Z",
    updatedAt: "2026-11-14T09:00:00Z",
    viewsCount: 2210
  },
  {
    id: "prop-7",
    referenceId: "AUE-5481",
    title: "The Coral Cove Coastal Sanctuary",
    tagline: "Modern organic architecture directly on Venetian Islands open bay",
    description: "Designed for seamless indoor-outdoor tropical entertaining, this modern residence features floor-to-ceiling telescoping glass doors, private 100ft deepwater dock suited for a superyacht, rooftop jacuzzi lounge, and natural limestone finishes throughout.",
    purpose: "sale",
    type: "villa",
    status: "available",
    price: 16900000,
    currency: "$",
    pricePrefix: "Guide Price",
    isFeatured: true,
    isLuxury: true,
    location: {
      address: "320 San Marino Drive",
      area: "Venetian Islands",
      city: "Miami",
      state: "Florida",
      country: "United States",
      lat: 25.7910,
      lng: -80.1580,
      hideExactAddress: false
    },
    bedrooms: 5,
    bathrooms: 6,
    parkingSpaces: 4,
    floorAreaSqFt: 7900,
    landAreaSqFt: 14200,
    yearBuilt: 2024,
    furnishedStatus: "furnished",
    featuredImage: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1800&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1800&q=85"
    ],
    amenities: [
      "100ft Deepwater Yacht Dock",
      "Saltwater Infinity Pool",
      "Rooftop Sunset Lounge & Jacuzzi",
      "Outdoor Summer Kitchen & Grill",
      "Crestron Smart Automation",
      "Motorized Privacy Louvers"
    ],
    createdAt: "2026-10-25T14:00:00Z",
    updatedAt: "2026-11-17T11:45:00Z",
    viewsCount: 3180
  },
  {
    id: "prop-8",
    referenceId: "AUE-1192",
    title: "The Financial Centre Trophy Office Floor",
    tagline: "Fully leased high-yield institutional grade commercial asset",
    description: "An exceptional opportunity to acquire a contiguous full floor within DIFC's most prestigious commercial tower. Leased to an international private equity firm on a long-term triple-net lease yielding 7.2% net. Features LEED Platinum certification, state-of-the-art HVAC, and 12 allocated executive parking bays.",
    purpose: "sale",
    type: "commercial",
    status: "available",
    price: 11500000,
    currency: "$",
    pricePrefix: "Guide Price",
    isFeatured: false,
    isLuxury: true,
    location: {
      address: "Gate Precinct 4, DIFC",
      area: "DIFC",
      city: "Dubai",
      country: "United Arab Emirates",
      lat: 25.2120,
      lng: 55.2810,
      hideExactAddress: false
    },
    bedrooms: 0,
    bathrooms: 6,
    parkingSpaces: 12,
    floorAreaSqFt: 10500,
    yearBuilt: 2021,
    furnishedStatus: "furnished",
    featuredImage: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1800&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1800&q=85"
    ],
    amenities: [
      "Full Commercial Floorplate",
      "LEED Platinum Certified",
      "7.2% Triple Net Yield",
      "12 Executive Underground Bays",
      "Dedicated High-Speed Elevators",
      "Fiber Redundant Infrastructure"
    ],
    createdAt: "2026-09-28T09:30:00Z",
    updatedAt: "2026-11-05T14:10:00Z",
    viewsCount: 1420
  },
  {
    id: "prop-9",
    referenceId: "AUE-2201",
    title: "Cap d'Antibes Coastal Development Plot",
    tagline: "Rare prime sea-view parcel with planning permissions for a luxury villa",
    description: "One of the final remaining prime development plots on Cap d'Antibes. Fully approved architectural planning consent for an 850 sqm contemporary villa with subterranean wellness spa, 8-car gallery garage, and 25m swimming pool. Elevated topography offers panoramic views across the Mediterranean.",
    purpose: "sale",
    type: "land",
    status: "available",
    price: 7900000,
    currency: "$",
    pricePrefix: "Offers in Excess",
    isFeatured: false,
    isLuxury: true,
    location: {
      address: "Chemin des Sables",
      area: "Cap d'Antibes",
      city: "Antibes",
      country: "France",
      lat: 43.5580,
      lng: 7.1210,
      hideExactAddress: false
    },
    bedrooms: 0,
    bathrooms: 0,
    parkingSpaces: 0,
    floorAreaSqFt: 0,
    landAreaSqFt: 48000,
    yearBuilt: undefined,
    furnishedStatus: "unfurnished",
    featuredImage: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1800&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1800&q=85"
    ],
    amenities: [
      "Full Building Permits Approved",
      "Unobstructed Mediterranean Views",
      "Water & Electric Utilities on Site",
      "Direct Private Road Access",
      "Secluded Natural Pine Setting"
    ],
    createdAt: "2026-10-05T16:00:00Z",
    updatedAt: "2026-11-16T12:00:00Z",
    viewsCount: 1980
  },
  {
    id: "prop-10",
    referenceId: "AUE-3908",
    title: "Belgravia Regency Townhouse & Mews",
    tagline: "Grade II listed family residence with separate guest mews house",
    description: "An ambassadorial white stucco residence on one of London's most iconic private squares. Completely restored under the guidance of heritage conservators, incorporating contemporary comforts including a passenger lift servicing all six floors, air conditioning, private garage, passenger mews house, and access to private square tennis courts.",
    purpose: "sale",
    type: "house",
    status: "reserved",
    price: 15500000,
    currency: "$",
    pricePrefix: "Guide Price",
    isFeatured: true,
    isLuxury: true,
    location: {
      address: "18 Chester Square",
      area: "Belgravia",
      city: "London",
      country: "United Kingdom",
      lat: 51.4940,
      lng: -0.1490,
      hideExactAddress: false
    },
    bedrooms: 5,
    bathrooms: 6,
    parkingSpaces: 2,
    floorAreaSqFt: 6900,
    yearBuilt: 1845,
    furnishedStatus: "furnished",
    featuredImage: "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1800&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1800&q=85"
    ],
    amenities: [
      "Grade II Listed Heritage",
      "Independent 2-Bed Mews House",
      "Passenger Elevator to all 6 Floors",
      "Private Chester Square Garden Access",
      "Wine Cellar & Tasting Room",
      "Integral Garage Parking"
    ],
    createdAt: "2026-09-10T11:00:00Z",
    updatedAt: "2026-11-19T10:00:00Z",
    viewsCount: 4600
  },
  {
    id: "prop-11",
    referenceId: "AUE-7722",
    title: "Zurichberg Luxury Lakeside Villa",
    tagline: "Swiss precision engineering nestled on the Goldcoast of Lake Zurich",
    description: "Overlooking the tranquil waters of Lake Zurich with backdrop views of the Glarus Alps, this bespoke modernist villa features geothermic heating, private boathouse, indoor heated swimming pool, security panic room, and minimalist Scandinavian interior architecture.",
    purpose: "sale",
    type: "villa",
    status: "available",
    price: 14200000,
    currency: "$",
    pricePrefix: "Guide Price",
    isFeatured: true,
    isLuxury: true,
    location: {
      address: "Seestrasse 142",
      area: "Zurichberg / Kusnacht",
      city: "Zurich",
      country: "Switzerland",
      lat: 47.3320,
      lng: 8.5830,
      hideExactAddress: false
    },
    bedrooms: 5,
    bathrooms: 6,
    parkingSpaces: 4,
    floorAreaSqFt: 7200,
    landAreaSqFt: 21500,
    yearBuilt: 2022,
    furnishedStatus: "unfurnished",
    featuredImage: "https://images.unsplash.com/photo-1600573472550-8090b5e0745e?auto=format&fit=crop&w=1800&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1600573472550-8090b5e0745e?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1800&q=85"
    ],
    amenities: [
      "Lake Zurich Boathouse & Pier",
      "Indoor Heated Lap Pool",
      "Geothermal Eco-Heating",
      "Alps Mountain Panorama",
      "Triple Glazed Acoustic Glass",
      "Underground 4-Car Turntable Garage"
    ],
    createdAt: "2026-10-18T13:00:00Z",
    updatedAt: "2026-11-17T14:30:00Z",
    viewsCount: 2650
  },
  {
    id: "prop-12",
    referenceId: "AUE-4190",
    title: "The Mayfair Commercial Flagship",
    tagline: "Prime luxury retail and private salon asset on Mount Street",
    description: "A marquee boutique building on prime Mount Street. Currently leased to an internationally renowned haute joaillerie house. Features classic Edwardian red terracotta facade, high ceilings, security vaults, and luxury boutique fitout across ground, basement, and first floors.",
    purpose: "sale",
    type: "commercial",
    status: "available",
    price: 19800000,
    currency: "$",
    pricePrefix: "Guide Price",
    isFeatured: false,
    isLuxury: true,
    location: {
      address: "94 Mount Street",
      area: "Mayfair",
      city: "London",
      country: "United Kingdom",
      lat: 51.5090,
      lng: -0.1500,
      hideExactAddress: false
    },
    bedrooms: 0,
    bathrooms: 4,
    parkingSpaces: 0,
    floorAreaSqFt: 5800,
    yearBuilt: 1904,
    furnishedStatus: "furnished",
    featuredImage: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1800&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1800&q=85",
      "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1800&q=85"
    ],
    amenities: [
      "Prime Mount Street Footfall",
      "Edwardian Heritage Facade",
      "High-Security Vault Facilities",
      "Long-term Bluechip Tenant",
      "Dual Street Display Windows"
    ],
    createdAt: "2026-09-15T15:00:00Z",
    updatedAt: "2026-11-15T11:00:00Z",
    viewsCount: 2130
  }
];

export const initialLocations: LocationItem[] = [
  {
    id: "loc-1",
    name: "London",
    slug: "london",
    region: "Greater London",
    country: "United Kingdom",
    image: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=1200&q=80",
    description: "Mayfair, Knightsbridge, Belgravia, Kensington, and Regent's Park prime estates.",
    featured: true,
    order: 1
  },
  {
    id: "loc-2",
    name: "Dubai",
    slug: "dubai",
    region: "Emirate of Dubai",
    country: "United Arab Emirates",
    image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1200&q=80",
    description: "Palm Jumeirah villas, Downtown luxury penthouses, Emirates Hills mansions, and DIFC commercial hubs.",
    featured: true,
    order: 2
  },
  {
    id: "loc-3",
    name: "Los Angeles",
    slug: "los-angeles",
    region: "California",
    country: "United States",
    image: "https://images.unsplash.com/photo-1580655653885-65763b2597d0?auto=format&fit=crop&w=1200&q=80",
    description: "Beverly Hills trophy compounds, Bel Air estates, Malibu beachfronts, and Hollywood Hills moderns.",
    featured: true,
    order: 3
  },
  {
    id: "loc-4",
    name: "French Riviera",
    slug: "french-riviera",
    region: "Côte d'Azur",
    country: "France",
    image: "https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=1200&q=80",
    description: "Cap d'Antibes, Saint-Jean-Cap-Ferrat, Cannes Croisette, and Saint-Tropez coastal sanctuaries.",
    featured: true,
    order: 4
  },
  {
    id: "loc-5",
    name: "Miami",
    slug: "miami",
    region: "Florida",
    country: "United States",
    image: "https://images.unsplash.com/photo-1506929562872-bb421503ef21?auto=format&fit=crop&w=1200&q=80",
    description: "Venetian Islands, Star Island, Fisher Island, and Brickell waterfront architectural towers.",
    featured: true,
    order: 5
  },
  {
    id: "loc-6",
    name: "Zurich",
    slug: "zurich",
    region: "Canton of Zurich",
    country: "Switzerland",
    image: "https://images.unsplash.com/photo-1515488764276-beab7607c1e6?auto=format&fit=crop&w=1200&q=80",
    description: "Lake Zurich Goldcoast villas, Zurichberg private parks, and Alpine tax-optimized residences.",
    featured: true,
    order: 6
  }
];

export const initialTestimonials: Testimonial[] = [
  {
    id: "test-1",
    clientName: "Lord Arthur Pendelton",
    clientTitle: "Family Office Principal",
    location: "London, UK",
    propertyType: "Mayfair Penthouse Acquisition",
    quote: "Aurelia Estates handled the acquisition of our Grosvenor Square residence with discretion, forensic market precision, and absolute integrity. Their private off-market access is second to none.",
    rating: 5,
    date: "October 2026"
  },
  {
    id: "test-2",
    clientName: "Elena Rostova",
    clientTitle: "Private Investor",
    location: "Geneva & Dubai",
    propertyType: "Palm Jumeirah Waterfront Villa",
    quote: "The advisory team navigated our international transaction seamlessly. From bespoke viewing schedules via yacht to tax-efficient closing advisory, their standard of service matches the world's finest private banks.",
    rating: 5,
    date: "September 2026"
  },
  {
    id: "test-3",
    clientName: "Marcus & Vivienne Vance",
    clientTitle: "Architecture Patrons",
    location: "Los Angeles, CA",
    propertyType: "Beverly Hills Modernist Estate",
    quote: "Selling a unique architectural residence requires storytellers who understand design value. Aurelia matched us with a discerning European buyer within 3 weeks of private listing.",
    rating: 5,
    date: "August 2026"
  }
];

export const initialBlogPosts: BlogPost[] = [
  {
    id: "blog-1",
    slug: "navigating-global-prime-real-estate-trends-2027",
    title: "Navigating Prime Global Real Estate: The Flight to Architectural Rarity",
    excerpt: "Discerning family offices and ultra-high-net-worth investors are prioritizing trophy status, biometric privacy, and enduring architectural legacy over mere square footage.",
    content: `
# Navigating Prime Global Real Estate: The Flight to Architectural Rarity

In prime global property markets — from London's historic Mayfair and Belgravia to Dubai's Palm Jumeirah and the sun-drenched cliffs of Cap d'Antibes — a notable paradigm shift has matured. Wealthy collectors are no longer simply seeking high square footage; they are curating architectural masterworks with immutable scarcity.

### The Rise of Branded Architectural Signatures

Recent transaction telemetry across Geneva, London, and New York reveals that properties conceived by Pritzker Prize laureates and celebrated interior ateliers command up to a 34% premium over standard high-spec luxury homes. Discerning buyers perceive architectural provenance not merely as living space, but as investable fine art.

### Privacy and Discreet Infrastructure

Security protocols have evolved beyond standard gated entry. Today's trophy residences incorporate:
- Dedicated private subterranean motor courts with car turntables
- Discreet biometric access elevators directly into owner suites
- Self-sufficient geothermic energy reserves and HEPA-filtered clean-air systems
- Integrated staff quarters with dedicated service circulation corridors

### Looking Ahead to Global Wealth Allocations

As sovereign monetary dynamics shift, prime bricks and mortar in rule-of-law jurisdictions continue to act as the preeminent hedge against monetary volatility. Aurelia Estates continues to monitor private off-market liquidity across the world's premier capitals.
    `,
    category: "Market Insights",
    readTime: "6 min read",
    author: {
      name: "Julian St. Claire",
      role: "Head of Private Client Advisory",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80"
    },
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1400&q=80",
    publishedAt: "2026-11-04",
    tags: ["Market Insights", "Wealth Advisory", "Luxury Architecture"]
  },
  {
    id: "blog-2",
    slug: "essential-guide-buying-prime-property-french-riviera",
    title: "The Connoisseur’s Guide to Acquiring Coastal Estates on the French Riviera",
    excerpt: "From notarial due diligence to coastal zoning protections (Loi Littoral), how to secure prime estates along Cap d’Antibes and Saint-Jean-Cap-Ferrat.",
    content: `
# The Connoisseur’s Guide to Acquiring Coastal Estates on the French Riviera

The French Riviera represents an evergreen bastion of European glamour. Yet, acquiring trophy real estate along the Mediterranean coastline requires nuanced legal and architectural mastery.

### Deciphering the Loi Littoral

France's strict coastal preservation laws safeguard natural shorelines from over-commercialization, which preserves the value of grandfathered seafront estates. Understanding what expansions are legally feasible before contract execution is paramount.

### The Role of French Notaries and Escrow Security

Every French property acquisition is certified by a state-appointed Notaire, providing institutional security for global capital. Our advisory practice collaborates with the most esteemed notarial offices in Nice and Cannes to structure confidential acquisitions via SCI or trust entities.
    `,
    category: "Property Guides",
    readTime: "8 min read",
    author: {
      name: "Camille de Montmirail",
      role: "Partner, Southern Europe",
      avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80"
    },
    image: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1400&q=80",
    publishedAt: "2026-10-22",
    tags: ["France", "Cap d'Antibes", "Buying Guide"]
  },
  {
    id: "blog-3",
    slug: "tax-efficient-property-ownership-uk-dubai",
    title: "Cross-Border Wealth Structuring: London & Dubai Real Estate Synergy",
    excerpt: "Analyzing the complimentary advantages of prime London freehold assets and Dubai Golden Visa zero-tax residential holdings.",
    content: `
# Cross-Border Wealth Structuring: London & Dubai Real Estate Synergy

For international families managing multi-jurisdictional portfolios, the strategic pairing of prime central London assets with Dubai waterfront properties offers the ideal balance of historic capital preservation and dynamic economic yields.

### London: Capital Preservation & Legal Certainty

Mayfair, Belgravia, and Knightsbridge retain an unmatched legal bedrock under English common law. Long-term appreciation and generational wealth transfer remain the anchor for international estates.

### Dubai: High Rental Yields & Tax Optimization

With zero personal income and capital gains tax, paired with 10-year investor Golden Visas for real estate acquisitions above AED 2 million, Dubai delivers immediate operational returns and lifestyle dynamism.
    `,
    category: "Investment Advisory",
    readTime: "5 min read",
    author: {
      name: "Tariq Al-Mansoor",
      role: "Managing Director, Middle East",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80"
    },
    image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1400&q=80",
    publishedAt: "2026-10-08",
    tags: ["Tax Advisory", "London", "Dubai", "Investment"]
  }
];

export const initialTeamMembers: TeamMember[] = [
  {
    id: "team-1",
    name: "Julian St. Claire",
    role: "Founding Partner & Chief Executive",
    bio: "Over 22 years of senior leadership in international prime real estate, having overseen more than $3.5B in transactions across London, New York, and Geneva.",
    photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=80",
    email: "j.stclaire@aureliaestates.com",
    phone: "+44 (0) 20 7946 0881",
    languages: ["English", "French"],
    specialty: "Trophy Asset Acquisitions & Discreet Off-Market Mandates"
  },
  {
    id: "team-2",
    name: "Camille de Montmirail",
    role: "Senior Partner, Southern Europe & Mediterranean",
    bio: "Specializing in Cap d'Antibes, Saint-Jean-Cap-Ferrat, and Monaco waterfront estates, Camille advises leading European families and international collectors.",
    photo: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80",
    email: "c.montmirail@aureliaestates.com",
    phone: "+33 4 93 34 50 00",
    languages: ["French", "English", "Italian"],
    specialty: "Riviera Waterfont Villas & Historic Châteaux"
  },
  {
    id: "team-3",
    name: "Tariq Al-Mansoor",
    role: "Managing Director, Middle East & Gulf",
    bio: "A trusted advisor to regional royal families and international sovereign investors across Palm Jumeirah, Downtown Dubai, and Abu Dhabi private islands.",
    photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=800&q=80",
    email: "t.almansoor@aureliaestates.com",
    phone: "+971 4 388 9000",
    languages: ["Arabic", "English"],
    specialty: "Palm Jumeirah Mansions & DIFC Commercial Portfolios"
  },
  {
    id: "team-4",
    name: "Genevieve Sterling",
    role: "Director of Private Client Services",
    bio: "Former luxury hospitality director in Mayfair, Genevieve orchestrates bespoke private client viewing itineraries, helicopter transfers, and concierge relocation services.",
    photo: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=800&q=80",
    email: "g.sterling@aureliaestates.com",
    phone: "+44 (0) 20 7946 0884",
    languages: ["English", "German", "Spanish"],
    specialty: "Private Viewings, Relocation & Family Office Relations"
  }
];

export const initialFAQs: FAQItem[] = [
  {
    id: "faq-1",
    category: "buying",
    question: "What is your approach to handling confidential or off-market property acquisitions?",
    answer: "A significant percentage of the world's most prestigious residences are never advertised publicly. Through our confidential Private Client division, we represent vetted buyers under strict Non-Disclosure Agreements (NDAs), granting direct access to private seller networks, family office estates, and discreet institutional portfolios."
  },
  {
    id: "faq-2",
    category: "buying",
    question: "How do you coordinate international viewings for global clients?",
    answer: "We offer end-to-end bespoke viewing curation. This includes private airport transfers, coordinated yacht or helicopter access for waterfront or remote estates, comprehensive neighborhood dossiers, and private in-person or live-guided 4K virtual tours."
  },
  {
    id: "faq-3",
    category: "selling",
    question: "How will my property be marketed to qualified international buyers?",
    answer: "We deploy an editorial-grade marketing strategy: bespoke architectural photography, cinematic video production, architectural monographs, targeted private exhibitions in Zurich, London, and Dubai, and discreet outreach to our pre-qualified global buyer registry."
  },
  {
    id: "faq-4",
    category: "selling",
    question: "What fees or commission structures do you operate under?",
    answer: "Our fees are aligned with prime international industry standards and are tailored depending on whether you engage us on an Exclusive Master Agency basis or a Confidential Off-Market Mandate. We outline all terms transparently prior to instruction."
  },
  {
    id: "faq-5",
    category: "renting",
    question: "Do you manage long-term luxury tenancies and executive relocations?",
    answer: "Yes. Our luxury lettings team handles corporate and private tenancies for prime apartments, townhouses, and country estates, including full vetting, tenancy deposit management, and five-star property caretaking."
  },
  {
    id: "faq-6",
    category: "investment",
    question: "Can you assist with commercial property acquisitions and development land?",
    answer: "Yes. In addition to residential estates, our commercial desk structures acquisitions of high-yield boutique office assets, prime retail flagships, and development land with planning consents across major financial hubs."
  }
];

export const initialLeads: InquiryLead[] = [
  {
    id: "lead-1",
    type: "property_viewing",
    propertyId: "prop-1",
    propertyTitle: "The Glasshouse Promenade Villa",
    propertyRef: "AUE-8901",
    customerName: "Sebastian Thorne",
    email: "s.thorne@thornecapital.com",
    phone: "+1 310 555 0192",
    message: "Interested in arranging a private twilight viewing this Friday afternoon. We are arriving via private flight into Van Nuys.",
    preferredDate: "2026-11-28",
    preferredTime: "16:30",
    status: "Viewing Scheduled",
    notes: "Client represents a private tech founder family office. Confirmed with Julian St. Claire.",
    assignedTo: "Julian St. Claire",
    createdAt: "2026-11-18T14:22:00Z",
    source: "Property Detail Page"
  },
  {
    id: "lead-2",
    type: "property_inquiry",
    propertyId: "prop-2",
    propertyTitle: "The Azure Waterfront Estate",
    propertyRef: "AUE-9104",
    customerName: "Dr. Alistair Sterling",
    email: "a.sterling@mediswiss.ch",
    phone: "+41 22 555 9811",
    message: "Please send full legal monograph, floor plans, and confirmation of yacht mooring depth for a 45m vessel.",
    status: "Contacted",
    notes: "Emailed floor plans and maritime mooring schematics.",
    assignedTo: "Tariq Al-Mansoor",
    createdAt: "2026-11-19T08:15:00Z",
    source: "WhatsApp Direct Link"
  },
  {
    id: "lead-3",
    type: "general",
    customerName: "Helena Vane",
    email: "helena.vane@artemispartners.co.uk",
    phone: "+44 7700 900822",
    message: "Seeking a confidential search mandate for a freehold townhouse in Mayfair or Belgravia with private garden and budget up to £15M.",
    status: "New",
    notes: "Requires initial advisory call.",
    assignedTo: "Genevieve Sterling",
    createdAt: "2026-11-19T10:45:00Z",
    source: "Contact Page Form"
  }
];
